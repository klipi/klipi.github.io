package com.msa.chotudada_fakecall.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.applovin.adview.AppLovinInterstitialAd;
import com.applovin.adview.AppLovinInterstitialAdDialog;
import com.applovin.sdk.AppLovinAd;
import com.msa.chotudada_fakecall.activity.MulaiActivity;
import com.msa.chotudada_fakecall.model.Video;
import com.msa.chotudada_fakecall.activity.ActivityChat;
import com.msa.chotudada_fakecall.R;
import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
 
import com.startapp.sdk.adsbase.StartAppAd;
import com.startapp.sdk.adsbase.adlisteners.VideoListener;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

import static android.content.ContentValues.TAG;
import static com.msa.chotudada_fakecall.config.Settings.ADMOB_INTER;
import static com.msa.chotudada_fakecall.config.Settings.BACKUP_MODE;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_BACKUP_ADS;
import static com.msa.chotudada_fakecall.config.Settings.COUNTER;
import static com.msa.chotudada_fakecall.config.Settings.FAN_INTER;
import static com.msa.chotudada_fakecall.config.Settings.INTERVAL;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_INTER;

@SuppressWarnings("unchecked")
public class ContactAdapter extends RecyclerView.Adapter {

    public static ArrayList<Video> webLists;
    public static ArrayList<Video> mFilteredList;
    public Context context;
    public static String posisi;
    public static String judul;
    public static String gambar;
    public static InterstitialAd mInterstitialAd;
    public static AdRequest adRequest ;
    public static AppLovinInterstitialAdDialog interstitialAdlovin;
    public static AppLovinAd loadedAd;
    public StartAppAd startAppAd = new StartAppAd((Activity)(context));

    public static com.facebook.ads.InterstitialAd interstitialAdfb;
    public ContactAdapter(ArrayList<Video> webLists, Context context) {
        this.mFilteredList = webLists;
        this.webLists = webLists;
        this.context = context;

    }

    public class ViewHolder extends RecyclerView.ViewHolder  {
        public TextView judul_vid;
        public TextView deskrispi;
        public CircleImageView avatar_url;
        public RelativeLayout layVid;

        public ViewHolder(View itemView) {
            super(itemView);
            judul_vid = (TextView) itemView.findViewById(R.id.txtJudul);
            deskrispi = (TextView) itemView.findViewById(R.id.txtDes);
            avatar_url = (CircleImageView) itemView.findViewById(R.id.gbrvideo);
            layVid = itemView.findViewById(R.id.layvid);
            switch (SELECT_INTER) {
                case "ADMOB":
                    if (MulaiActivity.mInterstitialAd == null) {
                        InterstitialAd.load(((Activity)(context)), ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                            @Override
                            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                                MulaiActivity.mInterstitialAd = interstitialAd;
                                Log.i(TAG, "onAdLoaded");
                            }

                            @Override
                            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                MulaiActivity.mInterstitialAd = null;
                            }
                        });
                    }
                    break;
                case "STARTAPP":
                    startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                    break;


            }
        }

    }







    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.list_contact, parent, false);
            return new ViewHolder(v);
    }


    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, final int position) {

                if (holder instanceof ViewHolder) {
                    final Video webList = mFilteredList.get(position);
                    ((ViewHolder)holder).judul_vid.setText(webList.getJudul_url());
                    ((ViewHolder)holder).deskrispi.setText(webList.getDes_vid());

                    Glide.with(context).load(webList.getGambar_url())
                            .centerCrop().into( ((ViewHolder)holder).avatar_url);

                    ((ViewHolder)holder).layVid.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            posisi = webList.getVideo_url();
                            judul = webList.getJudul_url();
                            gambar = webList.getGambar_url();
                            Intent intent = new Intent(context, ActivityChat.class);
                            intent.putExtra("position", position);
                            context.startActivity(intent);

                            if (COUNTER>=INTERVAL){
                                munculinterbaru();
                                COUNTER=0;
                            } else
                            {
                                COUNTER++;
                            }
                        }
                    });

                }
    }

    @Override

    public int getItemCount() {
        return mFilteredList.size();
    }

    public Filter getFilter() {

        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {

                String charString = charSequence.toString();

                if (charString.isEmpty()) {

                    mFilteredList = webLists;
                } else {

                    ArrayList<Video> filteredList = new ArrayList<>();

                    for (Video androidVersion : mFilteredList) {

                        if (androidVersion.getJudul_url().toLowerCase().contains(charString) || androidVersion.getDes_vid().toLowerCase().contains(charString)) {

                            filteredList.add(androidVersion);
                        }
                    }

                    mFilteredList = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = mFilteredList;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                mFilteredList = (ArrayList<Video>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

    private void munculinterbaru() {
        switch (SELECT_INTER) {
            case "ADMOB":
                if (MulaiActivity.mInterstitialAd != null) {
                    MulaiActivity.mInterstitialAd.show(((Activity)(context)));
                    InterstitialAd.load(((Activity)(context)), ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            MulaiActivity.mInterstitialAd = interstitialAd;
                            Log.i(TAG, "onAdLoaded");
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            MulaiActivity.mInterstitialAd = null;
                        }
                    });
                } else {
                    InterstitialAd.load(((Activity)(context)), ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            MulaiActivity.mInterstitialAd = interstitialAd;
                            Log.i(TAG, "onAdLoaded");
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                            MulaiActivity.mInterstitialAd = null;
                        }
                    });
                    if (BACKUP_MODE.equals("YES")) {
                        switch (SELECT_BACKUP_ADS) {
                            case "STARTAPP":
                                final StartAppAd rewardedVideo = new StartAppAd((Activity)(context));
                                rewardedVideo.showAd();
                                break;
                            case "APPLOVIN":
                                if (MulaiActivity.interstitialAd.isReady()) {
                                    MulaiActivity.interstitialAd.showAd();
                                } else {
                                    MulaiActivity.interstitialAd.loadAd();
                                }
                                break;
                            case "MOPUB":
                                if (MulaiActivity.mInterstitial.isReady()) {
                                    MulaiActivity.mInterstitial.show();
                                    MulaiActivity.mInterstitial.load();
                                } else {
                                    MulaiActivity.mInterstitial.load();
                                }
                                break;
                        }
                    }
                }
                break;
            case "APPLOVIN":
                if (MulaiActivity.interstitialAd.isReady()) {
                    MulaiActivity.interstitialAd.showAd();
                } else {
                    MulaiActivity.interstitialAd.loadAd();
                }
                break;
            case "STARTAPP":
                final StartAppAd rewardedVideo = new StartAppAd((Activity)(context));
                rewardedVideo.showAd();
                break;
            case "MOPUB":
                if (MulaiActivity.mInterstitial.isReady()) {
                    MulaiActivity.mInterstitial.show();
                    MulaiActivity.mInterstitial.load();
                } else {
                    MulaiActivity.mInterstitial.load();
                }
                break;
        }
    }



}

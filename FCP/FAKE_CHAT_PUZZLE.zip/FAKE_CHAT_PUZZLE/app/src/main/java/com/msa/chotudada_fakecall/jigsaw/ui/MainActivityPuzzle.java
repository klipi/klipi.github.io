package com.msa.chotudada_fakecall.jigsaw.ui;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.applovin.mediation.ads.MaxAdView;
import com.applovin.sdk.AppLovinMediationProvider;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkUtils;
import com.facebook.ads.AdSettings;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.ump.ConsentForm;
import com.google.android.ump.ConsentInformation;
import com.mopub.common.SdkConfiguration;
import com.mopub.mobileads.FacebookBanner;
import com.mopub.mobileads.MoPubView;
import com.msa.chotudada_fakecall.BuildConfig;
import com.msa.chotudada_fakecall.R;
import com.msa.chotudada_fakecall.activity.MainActivity;
import com.msa.chotudada_fakecall.activity.MulaiActivity;
import com.msa.chotudada_fakecall.config.Settings;
import com.startapp.sdk.ads.banner.banner3d.Banner3D;
import com.startapp.sdk.adsbase.Ad;
import com.startapp.sdk.adsbase.StartAppAd;
import com.startapp.sdk.adsbase.adlisteners.AdEventListener;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static com.google.android.gms.ads.RequestConfiguration.TAG_FOR_CHILD_DIRECTED_TREATMENT_TRUE;
import static com.google.android.play.core.install.model.ActivityResult.RESULT_IN_APP_UPDATE_FAILED;
import static com.msa.chotudada_fakecall.config.Settings.ADMOB_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.ADMOB_NATIVE_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.APPLOVIN_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.BACKUP_MODE;
import static com.msa.chotudada_fakecall.config.Settings.BANNER_MOPUB;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_BACKUP_ADS;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_BANNER;

public class MainActivityPuzzle extends AppCompatActivity {
    private ConsentInformation consentInformation;
    private ConsentForm consentForm;


    String mCurrentPhotoPath;
    private static final int REQUEST_PERMISSION_WRITE_EXTERNAL_STORAGE = 2;
    private static final int REQUEST_IMAGE_CAPTURE = 1;
    static final int REQUEST_PERMISSION_READ_EXTERNAL_STORAGE = 3;
    static final int REQUEST_IMAGE_GALLERY = 4;
    public static MediaPlayer mp;
    private RadioGroup list_action;

    /*
    Cottume level nember
     */
    public static int  sum = 12; // 4 x 3
    public static int  row = 4;
    public static int  col = 3;

    private FrameLayout adContainerView;
    private AdView adView;
    private CardView sound;
    public static int numsound=1;
    public StartAppAd startAppAd = new StartAppAd(this);
    RelativeLayout mainLayout;
    private RelativeLayout layAds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_puzzle);

        mp = MediaPlayer.create(this, R.raw.click);
        sound = findViewById(R.id.cdsound);
        final ImageView imgsound = findViewById(R.id.imgsound);
        sound.setTag("gray");
        sound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String tag = sound.getTag().toString();
                if (tag.equalsIgnoreCase("gray")) {
                    sound.setTag("red");
                    imgsound.setBackground(getResources().getDrawable(R.drawable.ic_baseline_volume_off_24));
                    numsound =0;

                } else {
                    sound.setTag("gray");
                    imgsound.setBackground(getResources().getDrawable(R.drawable.ic_baseline_volume_up_24));
                    numsound =1;
                }
            }
        });
        list_action = findViewById(R.id.list_action);
        list_action.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int id) {
                switch (id){
                    case R.id.rd_12:
                        sum = 12;
                        row = 4;
                        col = 3;
                        break;
                    case R.id.rd_20:
                        sum = 20;
                        row = 5;
                        col = 4;
                        break;
                    case R.id.rd_30:
                        sum = 30;
                        row = 6;
                        col = 5;
                        break;
                }
            }
        });

        mainLayout = (RelativeLayout) findViewById(R.id.layAds);
        switch (SELECT_BANNER) {
            case "ADMOB":
                if (Settings.BANNER_APA_NATIVE.equals("NATIVE")){
                    nativeadmob();
                } else {
                    adView = new AdView(this);
                    adView.setAdUnitId(ADMOB_BANNER);
                    mainLayout.addView(adView);
                    loadBanner();
                }
                break;
            case "APPLOVIN":
                MaxAdView adView;
                adView = new MaxAdView(APPLOVIN_BANNER, (Activity) MainActivityPuzzle.this);
                //AppLovinAdView adView = new AppLovinAdView(AppLovinAdSize.BANNER, context);
                final boolean isTablet = AppLovinSdkUtils.isTablet(MainActivityPuzzle.this);
                final int heightPx = AppLovinSdkUtils.dpToPx(MainActivityPuzzle.this, isTablet ? 90 : 50);
                adView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, heightPx));
                mainLayout.addView(adView);
                adView.loadAd();
                break;
            case "STARTAPP":
                Banner3D startAppBanner = new Banner3D(MainActivityPuzzle.this);
                RelativeLayout.LayoutParams bannerParameters =
                        new RelativeLayout.LayoutParams(
                                RelativeLayout.LayoutParams.WRAP_CONTENT,
                                RelativeLayout.LayoutParams.WRAP_CONTENT);
                bannerParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);
                mainLayout.addView(startAppBanner, bannerParameters);
                break;
            case "MOPUB":
               MoPubView moPubView;
                moPubView = new MoPubView(this);
                moPubView.setAdUnitId(BANNER_MOPUB);
                mainLayout.addView(moPubView);
                moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_50);
                moPubView.loadAd();
                break;
        }






    }

    public void onImageFromCameraClick(View view) {
        mp.start();
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) != null) {
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException e) {
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG);
            }

            if (photoFile != null) {
                Uri photoUri = FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".fileprovider", photoFile);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);
            }
        }
    }

    public void onImageList(View view) {
        mp.start();
        Intent intent = new Intent(getApplicationContext(), ListActivityPuzzle.class);
        startActivity(intent);
    }

    private File createImageFile() throws IOException {
        mp.start();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // permission not granted, initiate request
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_PERMISSION_WRITE_EXTERNAL_STORAGE);
        } else {
            // Create an image file name
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String imageFileName = "JPEG_" + timeStamp + "_";
            File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
            File image = File.createTempFile(
                    imageFileName,  /* prefix */
                    ".jpg",         /* suffix */
                    storageDir      /* directory */
            );
            mCurrentPhotoPath = image.getAbsolutePath(); // save this to use in the intent

            return image;
        }

        return null;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Intent intent = new Intent(this, PuzzleActivity.class);
            intent.putExtra("mCurrentPhotoPath", mCurrentPhotoPath);
            startActivity(intent);
        }
        if (requestCode == REQUEST_IMAGE_GALLERY && resultCode == RESULT_OK) {
            Uri uri = data.getData();

            Intent intent = new Intent(this, PuzzleActivity.class);
            intent.putExtra("mCurrentPhotoUri", uri.toString());
            startActivity(intent);
        }

        if (requestCode == MY_REQUEST_CODE){
            switch (resultCode){
                case Activity.RESULT_OK:
                    if(resultCode != RESULT_OK){
                        Toast.makeText(this,"RESULT_OK" +resultCode, Toast.LENGTH_LONG).show();
                        Log.d("RESULT_OK  :",""+resultCode);
                    }
                    break;
                case Activity.RESULT_CANCELED:

                    if (resultCode != RESULT_CANCELED){
                        Toast.makeText(this,"RESULT_CANCELED" +resultCode, Toast.LENGTH_LONG).show();
                        Log.d("RESULT_CANCELED  :",""+resultCode);
                    }
                    break;
                case RESULT_IN_APP_UPDATE_FAILED:

                    if (resultCode != RESULT_IN_APP_UPDATE_FAILED){

                        Toast.makeText(this,"RESULT_IN_APP_UPDATE_FAILED" +resultCode, Toast.LENGTH_LONG).show();
                        Log.d("RESULT_IN_APP_FAILED:",""+resultCode);
                    }
            }
        }
    }

    public void onImageFromGalleryClick(View view) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_PERMISSION_READ_EXTERNAL_STORAGE);
        } else {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            startActivityForResult(intent, REQUEST_IMAGE_GALLERY);
        }
    }

    public void onRateClick(View view) {
        String str = "https://play.google.com/store/apps/details?id="
                + BuildConfig.APPLICATION_ID;
        startActivity(new Intent(Intent.ACTION_VIEW,
                Uri.parse(str)));
    }

    public void onSharClick(View view) {
        String shareLink = "https://play.google.com/store/apps/details?id="
                + BuildConfig.APPLICATION_ID;
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT,
                getResources().getString(R.string.shareit)+" "
                        + shareLink);
        sendIntent.setType("text/plain");
        startActivity(sendIntent);
    }



    private static final int MY_REQUEST_CODE = 17326;


    private NativeAd nativeAd;
    private void nativeadmob() {
        refreshAd();
    }

    private void populateNativeAdView(NativeAd nativeAd, NativeAdView adView) {
        adView.setMediaView((MediaView) adView.findViewById(R.id.ad_media));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));
        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        adView.getMediaView().setMediaContent(nativeAd.getMediaContent());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getPrice() == null) {
            adView.getPriceView().setVisibility(View.INVISIBLE);
        } else {
            adView.getPriceView().setVisibility(View.VISIBLE);
            ((TextView) adView.getPriceView()).setText(nativeAd.getPrice());
        }

        if (nativeAd.getStore() == null) {
            adView.getStoreView().setVisibility(View.INVISIBLE);
        } else {
            adView.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) adView.getStoreView()).setText(nativeAd.getStore());
        }

        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.INVISIBLE);
        } else {
            ((TextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.VISIBLE);
        }
        adView.setNativeAd(nativeAd);
    }

    private void refreshAd() {

        AdLoader.Builder builder = new AdLoader.Builder(this, ADMOB_NATIVE_BANNER);

        builder.forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {
            @Override
            public void onNativeAdLoaded(@NonNull com.google.android.gms.ads.nativead.NativeAd nativeAds) {

                if (nativeAd != null) {
                    nativeAd.destroy();
                }

                nativeAd = nativeAds;
                FrameLayout frameLayout =
                        findViewById(R.id.fl_adplaceholder);
                NativeAdView adView = (NativeAdView) getLayoutInflater()
                        .inflate(R.layout.admob_native, null);
                populateNativeAdView(nativeAds, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });

        VideoOptions videoOptions = new VideoOptions.Builder()
                .build();

        com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader =
                builder
                        .withAdListener(
                                new AdListener() {
                                    @Override
                                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                                        if (BACKUP_MODE.equals("YES")){

                                            switch (SELECT_BACKUP_ADS) {
                                                case "STARTAPP":
                                                    Banner3D startAppBanner = new Banner3D(MainActivityPuzzle.this);
                                                    RelativeLayout.LayoutParams bannerParameters =
                                                            new RelativeLayout.LayoutParams(
                                                                    RelativeLayout.LayoutParams.WRAP_CONTENT,
                                                                    RelativeLayout.LayoutParams.WRAP_CONTENT);
                                                    bannerParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);
                                                    mainLayout.addView(startAppBanner, bannerParameters);
                                                    startAppAd.loadAd (new AdEventListener() {
                                                        @Override
                                                        public void onReceiveAd(com.startapp.sdk.adsbase.Ad ad) {

                                                        }

                                                        @Override
                                                        public void onFailedToReceiveAd(Ad ad) {
                                                        }
                                                    });
                                                    break;
                                                case "APPLOVIN":
                                                    MaxAdView adView;
                                                    adView = new MaxAdView(APPLOVIN_BANNER, (Activity) MainActivityPuzzle.this);
                                                    //AppLovinAdView adView = new AppLovinAdView(AppLovinAdSize.BANNER, context);
                                                    final boolean isTablet = AppLovinSdkUtils.isTablet(MainActivityPuzzle.this);
                                                    final int heightPx = AppLovinSdkUtils.dpToPx(MainActivityPuzzle.this, isTablet ? 90 : 50);
                                                    adView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, heightPx));
                                                    mainLayout.addView(adView);
                                                    adView.loadAd();
                                                    break;
                                                case "MOPUB":
                                                    MoPubView moPubView;
                                                    moPubView = new MoPubView(MainActivityPuzzle.this);
                                                    moPubView.setAdUnitId(BANNER_MOPUB);
                                                    mainLayout.addView(moPubView);
                                                    moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_50);
                                                    moPubView.setBannerAdListener((MoPubView.BannerAdListener) MainActivityPuzzle.this);
                                                    // Sent when the banner has failed to retrieve an ad. You can use the MoPubErrorCode value to diagnose the cause of failure.
                                                    break;
                                            }
                                        }
                                    }
                                })
                        .build();
        adLoader.loadAd(MulaiActivity.request);

    }








    private void loadBanner() {
        AdSize adSize = getAdSize();
        adView.setAdSize(adSize);
        adView.loadAd(MulaiActivity.request);
        adView.setAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                if (BACKUP_MODE.equals("YES")){

                    switch (SELECT_BACKUP_ADS) {
                        case "STARTAPP":
                            Banner3D startAppBanner = new Banner3D(MainActivityPuzzle.this);
                            RelativeLayout.LayoutParams bannerParameters =
                                    new RelativeLayout.LayoutParams(
                                            RelativeLayout.LayoutParams.WRAP_CONTENT,
                                            RelativeLayout.LayoutParams.WRAP_CONTENT);
                            bannerParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);
                            mainLayout.addView(startAppBanner, bannerParameters);
                            startAppAd.loadAd (new AdEventListener() {
                                @Override
                                public void onReceiveAd(Ad ad) {

                                }

                                @Override
                                public void onFailedToReceiveAd(Ad ad) {
                                }
                            });
                            break;
                        case "APPLOVIN":
                            MaxAdView adView;
                            adView = new MaxAdView(APPLOVIN_BANNER, MainActivityPuzzle.this);
                            //AppLovinAdView adView = new AppLovinAdView(AppLovinAdSize.BANNER, context);
                            final boolean isTablet = AppLovinSdkUtils.isTablet(MainActivityPuzzle.this);
                            final int heightPx = AppLovinSdkUtils.dpToPx(MainActivityPuzzle.this, isTablet ? 90 : 50);
                            adView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, heightPx));
                            mainLayout.addView(adView);
                            adView.loadAd();
                            break;
                        case "MOPUB":
                            Map<String, String> facebookBanner = new HashMap<>();
                            facebookBanner.put("native_banner", "true");
                            SdkConfiguration.Builder configBuilder = new SdkConfiguration.Builder(BANNER_MOPUB);
                            configBuilder.withMediatedNetworkConfiguration(FacebookBanner.class.getName(), facebookBanner);
                            MoPubView moPubView;
                            moPubView = new MoPubView(MainActivityPuzzle.this);
                            moPubView.setAdUnitId(BANNER_MOPUB);
                            mainLayout.addView(moPubView);
                            moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_50);
                            moPubView.loadAd();
                            // Sent when the banner has failed to retrieve an ad. You can use the MoPubErrorCode value to diagnose the cause of failure.
                            break;
                    }
                }
            }
        });


    }
    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

}

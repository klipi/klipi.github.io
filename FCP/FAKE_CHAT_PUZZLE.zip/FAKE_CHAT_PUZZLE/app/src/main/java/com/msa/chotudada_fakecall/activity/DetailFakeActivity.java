package com.msa.chotudada_fakecall.activity;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.ads.MaxAdView;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.mopub.mobileads.MoPubView;
import com.msa.chotudada_fakecall.R;
import com.msa.chotudada_fakecall.config.Settings;
import com.applovin.adview.AppLovinAdView;
import com.msa.chotudada_fakecall.util.AppReceiver;
import com.applovin.sdk.AppLovinAdSize;
import com.applovin.sdk.AppLovinSdkUtils;
import com.facebook.ads.AdError;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.MediaView;
import com.facebook.ads.MediaViewListener;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdBase;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.google.ads.mediation.facebook.FacebookAdapter;
import com.google.ads.mediation.facebook.FacebookExtras;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.squareup.picasso.Picasso;
import com.startapp.sdk.ads.banner.Mrec;
import com.startapp.sdk.ads.banner.banner3d.Banner3D;
import com.startapp.sdk.adsbase.Ad;
import com.startapp.sdk.adsbase.StartAppAd;
import com.startapp.sdk.adsbase.adlisteners.AdEventListener;
import com.startapp.sdk.adsbase.adlisteners.VideoListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.msa.chotudada_fakecall.adapter.FakeAdapter.gambar;
import static com.msa.chotudada_fakecall.adapter.FakeAdapter.judul;
import static com.msa.chotudada_fakecall.config.Settings.ADMOB_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.ADMOB_INTER;
import static com.msa.chotudada_fakecall.config.Settings.ADMOB_NATIV;
import static com.msa.chotudada_fakecall.config.Settings.ADMOB_NATIVE_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.APPLOVIN_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.BACKUP_MODE;
import static com.msa.chotudada_fakecall.config.Settings.BANNER_MOPUB;
import static com.msa.chotudada_fakecall.config.Settings.INTERVAL2;
import static com.msa.chotudada_fakecall.config.Settings.MREC_MOPUB;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_BACKUP_ADS;
import static com.msa.chotudada_fakecall.config.Settings.FAN_NATIVE;
import static com.msa.chotudada_fakecall.config.Settings.INTERVAL;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_INTER;
import static com.msa.chotudada_fakecall.config.Settings.TIMER_A;
import static com.msa.chotudada_fakecall.config.Settings.TIMER_B;
import static com.msa.chotudada_fakecall.config.Settings.TIMER_C;
import static com.msa.chotudada_fakecall.config.Settings.TIMER_D;
import static com.msa.chotudada_fakecall.config.Settings.COUNTER;

public class DetailFakeActivity extends AppCompatActivity {
    private int NOTIFICATION_ID = 1;
    private PendingIntent pendingIntent;
    private static final int ALARM_REQUEST_CODE = 134;
    private RadioGroup list_action, list_form, list_time;
    protected static final String TAG = DetailFakeActivity.class.getSimpleName();
    public static int rd_vid =1;
    public static int rd_form =1;
    public static int rd_time =1;
    public static String status_time="Wait for 2 seconds";
    RelativeLayout mainLayout;
    private StartAppAd startAppAd = new StartAppAd(this);
    private RelativeLayout layAds;
    private AdView adView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_fake_activity);
        layAds = findViewById(R.id.layAds);
        if (COUNTER>INTERVAL2){
            switch (SELECT_INTER) {
                case "ADMOB":
                    if (MulaiActivity.mInterstitialAd != null) {
                        MulaiActivity.mInterstitialAd.show(DetailFakeActivity.this);
                        InterstitialAd.load(DetailFakeActivity.this, ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                            @Override
                            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                                MulaiActivity.mInterstitialAd = interstitialAd;
                                Log.i(TAG, "onAdLoaded");
                            }

                            @Override
                            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                MulaiActivity.mInterstitialAd = null;
                            }
                        });
                    } else {
                        InterstitialAd.load(DetailFakeActivity.this, ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                            @Override
                            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                                MulaiActivity.mInterstitialAd = interstitialAd;
                                Log.i(TAG, "onAdLoaded");
                            }

                            @Override
                            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                                MulaiActivity.mInterstitialAd = null;
                            }
                        });
                        if (BACKUP_MODE.equals("YES")) {
                            switch (SELECT_BACKUP_ADS) {
                                case "STARTAPP":
                                    startAppAd.showAd();
                                    startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                                    break;
                                case "APPLOVIN":
                                    if (MulaiActivity.interstitialAd.isReady()) {
                                        MulaiActivity.interstitialAd.showAd();
                                    } else {
                                        MulaiActivity.interstitialAd.loadAd();
                                    }
                                    break;
                                case "MOPUB":
                                    if (MulaiActivity.mInterstitial.isReady()) {
                                        MulaiActivity.mInterstitial.show();
                                        MulaiActivity.mInterstitial.load();
                                    } else {
                                        MulaiActivity.mInterstitial.load();
                                    }
                                    break;
                            }
                        }
                    }
                    break;
                case "APPLOVIN":
                    if (MulaiActivity.interstitialAd.isReady()) {
                        MulaiActivity.interstitialAd.showAd();
                    } else {
                        MulaiActivity.interstitialAd.loadAd();
                    }
                    break;
                case "STARTAPP":
                    startAppAd.showAd();
                    startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                    break;
                case "MOPUB":
                    if (MulaiActivity.mInterstitial.isReady()) {
                        MulaiActivity.mInterstitial.show();
                        MulaiActivity.mInterstitial.load();
                    } else {
                        MulaiActivity.mInterstitial.load();
                    }
                    break;
            }
            COUNTER=0;
        } else {
            COUNTER++;
        }

        TextView judulH = findViewById(R.id.txtjudul);
        mainLayout = (RelativeLayout) findViewById(R.id.mainLayout);
        switch (SELECT_BANNER) {
            case "ADMOB":
                if (com.msa.chotudada_fakecall.config.Settings.BANNER_APA_NATIVE.equals("NATIVE")){
                    nativeadmob();
                } else {
                    adView = new AdView(this);
                    adView.setAdUnitId(ADMOB_BANNER);
                    layAds.addView(adView);
                    loadBanner();
                }
                break;
            case "STARTAPP":
                Mrec startAppBanner = new Mrec(DetailFakeActivity.this);
                RelativeLayout.LayoutParams bannerParameters =
                        new RelativeLayout.LayoutParams(
                                RelativeLayout.LayoutParams.WRAP_CONTENT,
                                RelativeLayout.LayoutParams.WRAP_CONTENT);
                bannerParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);
                mainLayout.addView(startAppBanner, bannerParameters);
                startAppAd.loadAd (new AdEventListener() {
                    @Override
                    public void onReceiveAd(Ad ad) {

                    }

                    @Override
                    public void onFailedToReceiveAd(Ad ad) {
                    }
                });
                break;
            case "APPLOVIN":
                MaxAdView adView;
                //adView = new MaxAdView(APPLOVIN_BANNER, (Activity) MainActivity.this);
                adView = new MaxAdView( APPLOVIN_BANNER, MaxAdFormat.MREC, DetailFakeActivity.this);
                //AppLovinAdView adView = new AppLovinAdView(AppLovinAdSize.BANNER, context);
                final int widthPx = AppLovinSdkUtils.dpToPx( DetailFakeActivity.this, 300 );
                final int heightPx = AppLovinSdkUtils.dpToPx( DetailFakeActivity.this, 250 );
                adView.setLayoutParams( new ConstraintLayout.LayoutParams( widthPx, heightPx ) );
                mainLayout.addView(adView);
                adView.loadAd();
                break;
            case "MOPUB":
                MoPubView moPubView;
                moPubView = new MoPubView(DetailFakeActivity.this);
                moPubView.setAdUnitId(MREC_MOPUB);
                moPubView.setAdSize(MoPubView.MoPubAdSize.HEIGHT_250);
                mainLayout.addView(moPubView);
                moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_250);
                moPubView.loadAd();
                // Sent when the banner has failed to retrieve an ad. You can use the MoPubErrorCode value to diagnose the cause of failure.
                break;
        }

        list_action = findViewById(R.id.list_action);
        list_action.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int id) {
                switch (id){
                    case R.id.rd_vid:
                        rd_vid = 1;
                        break;
                    case R.id.rd_voic:
                        rd_vid = 2;
                        break;

                }
            }
        });

        list_form = findViewById(R.id.lict_form);
        list_form.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int id) {
                switch (id){
                    case R.id.rdwa:
                        rd_form = 1;
                        break;
                    case R.id.rdfb:
                        rd_form = 2;
                        break;
                    case R.id.rdduo:
                        rd_form = 3;
                        break;
                }
            }
        });

        list_time = findViewById(R.id.list_time);
        list_time.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int id) {
                switch (id){
                    case R.id.rd1:
                        rd_time = 1;
                        status_time = "Wait for 2 seconds";
                        break;
                    case R.id.rd10:
                        rd_time = TIMER_A ;
                        status_time = "Wait for 10 seconds";
                        break;
                    case R.id.rd30:
                        rd_time = TIMER_B ;
                        status_time = "Wait for 30 seconds";
                        break;
                    case R.id.rd60:
                        rd_time = TIMER_C;
                        status_time = "Wait for 1 minutes";
                        break;
                    case R.id.rd300:
                        rd_time = TIMER_D;
                        status_time = "Wait for 5 minutes";
                        break;
                }
            }
        });

        judulH.setText(judul);
        CircleImageView gambrH = findViewById(R.id.imageheader);
        Picasso.get()
                .load(gambar)
                .into(gambrH);

        Intent alarmIntent = new Intent(this, AppReceiver.class);
        pendingIntent = PendingIntent.getBroadcast(this, ALARM_REQUEST_CODE, alarmIntent, 0);

        Button tbtutor = findViewById(R.id.tblstart);
        tbtutor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (rd_time==1) {
                    if (rd_form == 1) {
                        if (rd_vid == 2) {
                            Intent intent2 = new Intent(DetailFakeActivity.this, WAVoiceCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        } else if (rd_vid == 1) {
                            Intent intent2 = new Intent(DetailFakeActivity.this, WAVideoCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        } else {
                            Intent intent2 = new Intent(DetailFakeActivity.this, WAVideoCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        }
                    } else if (rd_form == 2) {
                        if (rd_vid == 2) {
                            Intent intent2 = new Intent(DetailFakeActivity.this, FBVoiceCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        } else if (rd_vid == 1) {
                            Intent intent2 = new Intent(DetailFakeActivity.this, FBVideoCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        } else {
                            Intent intent2 = new Intent(DetailFakeActivity.this, FBVideoCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        }
                    }else if (rd_form == 3) {
                        if (rd_vid == 2) {
                            Intent intent2 = new Intent(DetailFakeActivity.this, TeleVoiceCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        } else if (rd_vid == 1) {
                            Intent intent2 = new Intent(DetailFakeActivity.this, TeleVideoCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        } else {
                            Intent intent2 = new Intent(DetailFakeActivity.this, TeleVideoCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        }
                    }
                } else {
                    Calendar cal = Calendar.getInstance();
                    cal.add(Calendar.SECOND, rd_time);
                    AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                    manager.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pendingIntent);
                    Toast.makeText(DetailFakeActivity.this, status_time, Toast.LENGTH_SHORT).show();
                    finish();
                    MainActivity.fa.finish();
                }
            }
        });
    }



    private @Nullable
    TextView nativeAdStatus;
    private @Nullable
    LinearLayout adChoicesContainer;

    private @Nullable
    NativeAdLayout nativeAdLayout;
    private @Nullable
    NativeAd nativeAd;
    private @Nullable
    AdOptionsView adOptionsView;
    private MediaView nativeAdMedia;

    private int originalScreenOrientationFlag;

    private com.google.android.gms.ads.nativead.NativeAd nativeAd2;
    private void nativeadmob() {
        refreshAd();
    }

    private void populateNativeAdView(com.google.android.gms.ads.nativead.NativeAd nativeAd, NativeAdView adView) {
        adView.setMediaView((com.google.android.gms.ads.nativead.MediaView) adView.findViewById(R.id.ad_media));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));
        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        adView.getMediaView().setMediaContent(nativeAd.getMediaContent());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getPrice() == null) {
            adView.getPriceView().setVisibility(View.INVISIBLE);
        } else {
            adView.getPriceView().setVisibility(View.VISIBLE);
            ((TextView) adView.getPriceView()).setText(nativeAd.getPrice());
        }

        if (nativeAd.getStore() == null) {
            adView.getStoreView().setVisibility(View.INVISIBLE);
        } else {
            adView.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) adView.getStoreView()).setText(nativeAd.getStore());
        }

        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.INVISIBLE);
        } else {
            ((TextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.VISIBLE);
        }
        adView.setNativeAd(nativeAd);
    }

    private void refreshAd() {

        AdLoader.Builder builder = new AdLoader.Builder(this, ADMOB_NATIV);
        builder.forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {
            @Override
            public void onNativeAdLoaded(@NonNull com.google.android.gms.ads.nativead.NativeAd nativeAds) {

                if (nativeAd2 != null) {
                    nativeAd2.destroy();
                }

                nativeAd2 = nativeAds;
                FrameLayout frameLayout =
                        findViewById(R.id.fl_adplaceholder);
                NativeAdView adView = (NativeAdView) getLayoutInflater()
                        .inflate(R.layout.admob_native_big, null);
                populateNativeAdView(nativeAds, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });

        VideoOptions videoOptions = new VideoOptions.Builder()
                .build();

        com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader =
                builder
                        .withAdListener(
                                new AdListener() {
                                    @Override
                                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                                        if (BACKUP_MODE.equals("YES")){

                                            switch (SELECT_BACKUP_ADS) {
                                                case "STARTAPP":
                                                    Mrec startAppBanner = new Mrec(DetailFakeActivity.this);
                                                    RelativeLayout.LayoutParams bannerParameters =
                                                            new RelativeLayout.LayoutParams(
                                                                    RelativeLayout.LayoutParams.WRAP_CONTENT,
                                                                    RelativeLayout.LayoutParams.WRAP_CONTENT);
                                                    bannerParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);
                                                    mainLayout.addView(startAppBanner, bannerParameters);
                                                    startAppAd.loadAd (new AdEventListener() {
                                                        @Override
                                                        public void onReceiveAd(com.startapp.sdk.adsbase.Ad ad) {

                                                        }

                                                        @Override
                                                        public void onFailedToReceiveAd(com.startapp.sdk.adsbase.Ad ad) {
                                                        }
                                                    });
                                                    break;
                                                case "APPLOVIN":
                                                    MaxAdView adView;
                                                    //adView = new MaxAdView(APPLOVIN_BANNER, (Activity) MainActivity.this);
                                                    adView = new MaxAdView( APPLOVIN_BANNER, MaxAdFormat.MREC, DetailFakeActivity.this);
                                                    //AppLovinAdView adView = new AppLovinAdView(AppLovinAdSize.BANNER, context);
                                                    final int widthPx = AppLovinSdkUtils.dpToPx( DetailFakeActivity.this, 300 );
                                                    final int heightPx = AppLovinSdkUtils.dpToPx( DetailFakeActivity.this, 250 );
                                                    adView.setLayoutParams( new ConstraintLayout.LayoutParams( widthPx, heightPx ) );
                                                    mainLayout.addView(adView);
                                                    adView.loadAd();
                                                    break;
                                                case "MOPUB":
                                                    MoPubView moPubView;
                                                    moPubView = new MoPubView(DetailFakeActivity.this);
                                                    moPubView.setAdUnitId(MREC_MOPUB);
                                                    moPubView.setAdSize(MoPubView.MoPubAdSize.HEIGHT_250);
                                                    mainLayout.addView(moPubView);
                                                    moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_250);
                                                    moPubView.loadAd();
                                                    // Sent when the banner has failed to retrieve an ad. You can use the MoPubErrorCode value to diagnose the cause of failure.
                                                    break;
                                            }
                                        }
                                    }
                                })
                        .build();
        adLoader.loadAd(MulaiActivity.request);

    }

    @Override
    public void onBackPressed()
    {
        finish();
    }

    @Override
    protected void onDestroy() {
        if (nativeAdMedia != null) {
            nativeAdMedia.destroy();
        }

        if (nativeAd != null) {
            nativeAd.unregisterView();
            nativeAd.destroy();
        }
        super.onDestroy();
    }




    private void loadBanner() {
        adView.setAdSize(AdSize.MEDIUM_RECTANGLE);
        adView.loadAd(MulaiActivity.request);
        adView.setAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                if (BACKUP_MODE.equals("YES")){
                    switch (SELECT_BACKUP_ADS) {
                        case "STARTAPP":
                            Mrec startAppBanner = new Mrec(DetailFakeActivity.this);
                            RelativeLayout.LayoutParams bannerParameters =
                                    new RelativeLayout.LayoutParams(
                                            RelativeLayout.LayoutParams.WRAP_CONTENT,
                                            RelativeLayout.LayoutParams.WRAP_CONTENT);
                            bannerParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);
                            mainLayout.addView(startAppBanner, bannerParameters);
                            startAppAd.loadAd (new AdEventListener() {
                                @Override
                                public void onReceiveAd(com.startapp.sdk.adsbase.Ad ad) {

                                }

                                @Override
                                public void onFailedToReceiveAd(com.startapp.sdk.adsbase.Ad ad) {
                                }
                            });
                            break;
                        case "APPLOVIN":
                            MaxAdView adView;
                            //adView = new MaxAdView(APPLOVIN_BANNER, (Activity) MainActivity.this);
                            adView = new MaxAdView( APPLOVIN_BANNER, MaxAdFormat.MREC, DetailFakeActivity.this);
                            //AppLovinAdView adView = new AppLovinAdView(AppLovinAdSize.BANNER, context);
                            final int widthPx = AppLovinSdkUtils.dpToPx( DetailFakeActivity.this, 300 );
                            final int heightPx = AppLovinSdkUtils.dpToPx( DetailFakeActivity.this, 250 );
                            adView.setLayoutParams( new ConstraintLayout.LayoutParams( widthPx, heightPx ) );
                            mainLayout.addView(adView);
                            adView.loadAd();
                            break;
                        case "MOPUB":
                            MoPubView moPubView;
                            moPubView = new MoPubView(DetailFakeActivity.this);
                            moPubView.setAdUnitId(MREC_MOPUB);
                            moPubView.setAdSize(MoPubView.MoPubAdSize.HEIGHT_250);
                            mainLayout.addView(moPubView);
                            moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_250);
                            moPubView.loadAd();
                            // Sent when the banner has failed to retrieve an ad. You can use the MoPubErrorCode value to diagnose the cause of failure.
                            break;
                    }

                }
            }
        });


    }








}
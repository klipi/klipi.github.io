package com.msa.chotudada_fakecall.activity;

import android.annotation.TargetApi;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.hardware.Camera;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.applovin.adview.AppLovinInterstitialAdDialog;
import com.applovin.sdk.AppLovinAd;
import com.msa.chotudada_fakecall.BuildConfig;
import com.msa.chotudada_fakecall.R;
import com.msa.chotudada_fakecall.config.Settings;
import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import com.startapp.sdk.adsbase.Ad;
import com.startapp.sdk.adsbase.StartAppAd;

import de.hdodenhof.circleimageview.CircleImageView;

import static android.content.ContentValues.TAG;
import static com.msa.chotudada_fakecall.adapter.ContactAdapter.gambar;
import static com.msa.chotudada_fakecall.adapter.ContactAdapter.judul;
import static com.msa.chotudada_fakecall.adapter.ContactAdapter.posisi;
import static com.msa.chotudada_fakecall.config.Settings.ADMOB_INTER;
import static com.msa.chotudada_fakecall.config.Settings.BACKUP_MODE;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_BACKUP_ADS;
import static com.msa.chotudada_fakecall.config.Settings.FAN_INTER;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_INTER;

public class PanggilanKeluar extends AppCompatActivity implements SurfaceHolder.Callback {
    MediaPlayer mp;
    Camera camera;
    SurfaceView surfaceView,surfaceView2 ;
    SurfaceHolder surfaceHolder;
    VideoView videoView;

    private TextView calling, nameuser;
    private ImageView  adduser;
    private CircleImageView imguser;

    public static InterstitialAd mInterstitialAd;
    public static com.facebook.ads.InterstitialAd interstitialAdfb;
    private RelativeLayout cancel, terima, pesan, tolak;
    Handler handler;
    public static AdRequest adRequest ;
    public static AppLovinInterstitialAdDialog interstitialAdlovin;
    public static AppLovinAd loadedAd;

    private LinearLayout atas, bawah;
    public StartAppAd startAppAd = new StartAppAd(this);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.panggilan);
        switch (SELECT_INTER) {
            case "ADMOB":
                if (MulaiActivity.mInterstitialAd == null) {
                    InterstitialAd.load(PanggilanKeluar.this, ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            MulaiActivity.mInterstitialAd = interstitialAd;
                            Log.i(TAG, "onAdLoaded");
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            MulaiActivity.mInterstitialAd = null;
                        }
                    });
                }
                break;
            case "MOPUB":
                MulaiActivity.mInterstitial.load();
                break;
            case "STARTAPP":
                startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                break;


        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            if (!android.provider.Settings.canDrawOverlays(this)) {
                checkPermission();

            }
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            int LAYOUT_FLAG = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
            WindowManager.LayoutParams mWindowParams = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                    LAYOUT_FLAG, // Overlay over the other apps.
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE    // This flag will enable the back key press.
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, // make the window to deliver the focus to the BG window.
                    PixelFormat.TRANSPARENT);
        }

        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        mp = MediaPlayer.create(this, R.raw.ringing_tone);
        mp.start();
        mp.setLooping(true);

        atas = findViewById(R.id.atas);
        bawah = findViewById(R.id.bawah);
        videoView = findViewById(R.id.videoView);
        String uriPath = posisi;
        if (Settings.ON_OFF_DATA.equals("1")){
            Uri uri = Uri.parse(uriPath);
            videoView.setVideoURI(uri);
            videoView.requestFocus();
        } else if (Settings.ON_OFF_DATA.equals("0")){
            if (uriPath.startsWith("http")) {
                Uri uri = Uri.parse(uriPath);
                videoView.setVideoURI(uri);
                videoView.requestFocus();
            } else {
                String fileName = "android.resource://"+  BuildConfig.APPLICATION_ID + "/raw/"+posisi;
                videoView.setVideoURI(Uri.parse(fileName));
                videoView.requestFocus();
            }

        }

        surfaceView = findViewById(R.id.surfaceView);
        surfaceView2 = findViewById(R.id.surfaceView2);
        surfaceView2.setVisibility(View.GONE);
        surfaceHolder = surfaceView.getHolder();
        surfaceHolder.addCallback(this);
        surfaceHolder.setFormat(PixelFormat.OPAQUE);
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_NORMAL);
        handler = new Handler() ;


        calling = findViewById(R.id.txtcall);
        nameuser = findViewById(R.id.txtname);
        imguser = findViewById(R.id.imguser);
        adduser = findViewById(R.id.adduser);
        adduser.setVisibility(View.INVISIBLE);
        cancel = findViewById(R.id.layclose2);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PanggilanKeluar.this, MenuActivity.class);
                startActivity(intent);
                finish();
                mp.stop();
                    munculinterbaru();
            }
        });

        pesan = findViewById(R.id.laypesan);
        pesan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PanggilanKeluar.this, MenuActivity.class);
                startActivity(intent);
                finish();
                mp.stop();
                munculinterbaru();

            }
        });

        tolak = findViewById(R.id.layclose);
        tolak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PanggilanKeluar.this, MenuActivity.class);
                startActivity(intent);
                finish();
                mp.stop();
                munculinterbaru();
            }
        });

        terima = findViewById(R.id.layterima);
        terima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.stop();
                mp.stop();
                calling.setVisibility(View.GONE);
                nameuser.setVisibility(View.GONE);
                imguser.setVisibility(View.GONE);
                adduser.setVisibility(View.VISIBLE);
                surfaceView.setVisibility(View.GONE);
                surfaceView2.setVisibility(View.VISIBLE);
                surfaceHolder = surfaceView2.getHolder();
                surfaceHolder.addCallback(PanggilanKeluar.this);
                surfaceHolder.setFormat(PixelFormat.OPAQUE);
                surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_NORMAL);

                videoView.start();
                atas.setVisibility(View.GONE);
                bawah.setVisibility(View.VISIBLE);
                tolak.setVisibility(View.VISIBLE);

            }
        });


        /** Creates a count down timer, which will be expired after 5000 milliseconds */
        new CountDownTimer(10000, 1000) {

            /** This method will be invoked on finishing or expiring the timer */
            @Override
            public void onFinish() {
                mp.stop();
                mp.stop();
                calling.setVisibility(View.GONE);
                nameuser.setVisibility(View.GONE);
                imguser.setVisibility(View.GONE);
                adduser.setVisibility(View.VISIBLE);
                surfaceView.setVisibility(View.GONE);
                surfaceView2.setVisibility(View.VISIBLE);
                surfaceHolder = surfaceView2.getHolder();
                surfaceHolder.addCallback(PanggilanKeluar.this);
                surfaceHolder.setFormat(PixelFormat.OPAQUE);
                surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_NORMAL);

                videoView.start();
                atas.setVisibility(View.GONE);
                bawah.setVisibility(View.VISIBLE);
                tolak.setVisibility(View.VISIBLE);
            }

            @Override
            public void onTick(long millisUntilFinished) {

            }
        }.start();

        imguser = findViewById(R.id.imguser);
        Glide.with(this).load(gambar)
                .centerCrop().into(imguser);
        nameuser.setText(judul);

    }









    public void surfaceCreated(SurfaceHolder surfaceHolder ) {

        camera = Camera.open(1);
        Camera.Parameters parameters;
        parameters = camera.getParameters();
        camera.setParameters(parameters);
        camera.setDisplayOrientation(90);
        try {
            camera.setPreviewDisplay(surfaceHolder);
            camera.startPreview();
        }catch (Exception e){
        }

    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int i, int i1, int i2) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        camera.stopPreview();
        camera.release();
        camera=null;

    }
    public void call2(){
        new CountDownTimer(7000, 1000) {
            @Override
            public void onFinish() {
                mp.stop();
                calling.setVisibility(View.GONE);
                nameuser.setVisibility(View.GONE);
                imguser.setVisibility(View.GONE);
                adduser.setVisibility(View.VISIBLE);
                surfaceView.setVisibility(View.GONE);
                surfaceView2.setVisibility(View.VISIBLE);
                videoView.start();
            }
            @Override
            public void onTick(long millisUntilFinished) {
                surfaceHolder = surfaceView2.getHolder();
                surfaceHolder.addCallback(PanggilanKeluar.this);
                surfaceHolder.setFormat(PixelFormat.OPAQUE);
                surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_NORMAL);

            }
        }.start();
    }
    public void onBackPressed(){
        mp.stop();
        Intent intent = new Intent(PanggilanKeluar.this, MenuActivity.class);
        startActivity(intent);
        finish();
       munculinterbaru();
    }

    public static int ACTION_MANAGE_OVERLAY_PERMISSION_REQUEST_CODE = 5469;
    @TargetApi(Build.VERSION_CODES.M)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ACTION_MANAGE_OVERLAY_PERMISSION_REQUEST_CODE) {
            if (!android.provider.Settings.canDrawOverlays(this)) {
                // You don't have permission
                checkPermission();
            } else {
                // Do as per your logic
            }

        }

    }

    public void checkPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!android.provider.Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, ACTION_MANAGE_OVERLAY_PERMISSION_REQUEST_CODE);
            }
        }
    }
    private void munculinterbaru() {
        switch (SELECT_INTER) {
            case "ADMOB":
                if (MulaiActivity.mInterstitialAd != null) {
                    MulaiActivity.mInterstitialAd.show(PanggilanKeluar.this);
                    InterstitialAd.load(PanggilanKeluar.this, ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            MulaiActivity.mInterstitialAd = interstitialAd;
                            Log.i(TAG, "onAdLoaded");
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            MulaiActivity.mInterstitialAd = null;
                        }
                    });
                } else {
                    InterstitialAd.load(PanggilanKeluar.this, ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            MulaiActivity.mInterstitialAd = interstitialAd;
                            Log.i(TAG, "onAdLoaded");
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                            MulaiActivity.mInterstitialAd = null;
                        }
                    });
                    if (BACKUP_MODE.equals("YES")) {
                        switch (SELECT_BACKUP_ADS) {
                            case "STARTAPP":
                                startAppAd.showAd();
                                startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                                break;
                            case "APPLOVIN":
                                if (MulaiActivity.interstitialAd.isReady()) {
                                    MulaiActivity.interstitialAd.showAd();
                                } else {
                                    MulaiActivity.interstitialAd.loadAd();
                                }
                                break;
                            case "MOPUB":
                                if (MulaiActivity.mInterstitial.isReady()) {
                                    MulaiActivity.mInterstitial.show();
                                    MulaiActivity.mInterstitial.load();
                                } else {
                                    MulaiActivity.mInterstitial.load();
                                }
                                break;
                        }
                    }
                }
                break;
            case "APPLOVIN":
                if (MulaiActivity.interstitialAd.isReady()) {
                    MulaiActivity.interstitialAd.showAd();
                } else {
                    MulaiActivity.interstitialAd.loadAd();
                }
                break;
            case "STARTAPP":
                startAppAd.showAd();
                startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                break;
            case "MOPUB":
                if (MulaiActivity.mInterstitial.isReady()) {
                    MulaiActivity.mInterstitial.show();
                    MulaiActivity.mInterstitial.load();
                } else {
                    MulaiActivity.mInterstitial.load();
                }
                break;
        }
    }




}
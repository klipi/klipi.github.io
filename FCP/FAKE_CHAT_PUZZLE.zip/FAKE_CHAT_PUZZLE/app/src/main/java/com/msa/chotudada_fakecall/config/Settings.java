package com.msa.chotudada_fakecall.config;


import com.msa.chotudada_fakecall.BuildConfig;

public class Settings {

    public static String INITIAL_ADMOB = "NO";
    public static String INITIAL_MOPUB = "NO";
    public static String INITIAL_STARTAPP = "NO";
    public static String INITIAL_APPLOVIN = "NO";



    public static String ON_OFF_ADS ="1";
    public static String ON_OFF_DATA ="0";



    public static String SELECT_INTER="XADMOB";
    public static String SELECT_BANNER="XSTARTAPP";
    public static String SELECT_REWARD="XAPPLOVIN";
    public static String SELECT_BACKUP_REWARD ="XADMOB";
    public static String SELECT_BACKUP_ADS ="XSTARTAPP";
    public static String BACKUP_MODE = "NO";
    public static String BANNER_APA_NATIVE = "BANNER";

    public static final String URL_DATA = "https://klipi.github.io/json3/01_chotu_dada.json";


    public static String ADMOB_BANNER = "Xca-app-pub-3940256099942544/6300978111";
    public static String ADMOB_INTER = "Xca-app-pub-3940256099942544/1033173712";
    public static String ADMOB_NATIV = "xca-app-pub-3940256099942544/2247696110";
    public static String ADMOB_NATIVE_BANNER = "xca-app-pub-3940256099942544/2247696110";
    public static String ADMOB_OPENADS = "XXca-aps-0101ST020102/sc4442322XX";
    public static String ADMOB_REWARD = "xca-app-pub-3940256099942544/5224354917";


    public static String FAN_INTER="YOUR_PLACEMENT_ID";
    public static String FAN_BANNER_NATIVE="YOUR_PLACEMENT_ID";
    public static String FAN_NATIVE="YOUR_PLACEMENT_ID";
    public static  boolean TESTMODE_FAN = false;

    /*
   ID Mopub
   */
    public static String BANNER_MOPUB = "b195f8dd8ded45fe847ad89ed1d016da" ;
    public static String INTER_MOPUB = "24534e1901884e398f1253216226017e" ;
    public static String MREC_MOPUB = "252412d5e9364a05ab77d9396346d73d";
    public static String REWARD_MOPUB = "252412d5e9364a05ab77d9396346d73d";

    /*
    Applovin ID for MAX
    Please fill SDK Key on string.xml
     */
    public static String APPLOVIN_BANNER = "db4d5e8718b97d78";
    public static String APPLOVIN_INTER = "518cd97722c60b52";
    public static String APPLOVIN_REWARD = "518cd97722c60b52";


    public static String STARTAPPID="205147161";
    public static int AGE1 =10;
    public static int AGE2 =25;

    public static String Guide_app="file:///android_asset/guide.html";
    public static String Privacy_police="file:///android_asset/privacy_policy.html";

    public static int COUNTER =0;
    public static int INTERVAL =4;
    public static int INTERVAL2 =2;

    public static String KEY_PACK = BuildConfig.APPLICATION_ID;

    public static int TIMER_A = 10; // 10 second
    public static int TIMER_B = 30; // 30 second
    public static int TIMER_C = 60; // 1 minute
    public static int TIMER_D = 300; // 5 minute



    public static String STATUS_APP = "0";
    public static String LINK_REDIRECT = "https://play.google.com/store/apps/details?id=com.alquranterjemahanindonesia.guruandroid";






}


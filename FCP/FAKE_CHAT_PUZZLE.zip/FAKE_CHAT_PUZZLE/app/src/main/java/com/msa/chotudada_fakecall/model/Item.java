package com.msa.chotudada_fakecall.model;

public class Item {
    public int Id;
    public String namefake;
    public String image_url;
    public String viode_url;
    public String voice_url;

    public String getImage_url() {
        return image_url;
    }
    public String getViode_url() {
        return viode_url;
    }

    public String getNamefake() {
        return namefake;
    }


    public String getVoice_url() {
        return voice_url;
    }
}

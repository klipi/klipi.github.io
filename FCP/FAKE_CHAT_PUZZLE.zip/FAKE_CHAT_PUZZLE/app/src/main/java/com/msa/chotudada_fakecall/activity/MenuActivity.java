package com.msa.chotudada_fakecall.activity;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import com.applovin.adview.AppLovinInterstitialAd;
import com.applovin.adview.AppLovinInterstitialAdDialog;
import com.applovin.mediation.ads.MaxAdView;
import com.applovin.sdk.AppLovinAdSize;
import com.applovin.sdk.AppLovinMediationProvider;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkUtils;
import com.facebook.ads.AdSettings;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.mopub.common.SdkConfiguration;
import com.mopub.mobileads.FacebookBanner;
import com.mopub.mobileads.MoPubView;
import com.msa.chotudada_fakecall.Fragment.ContactFragment;
import com.msa.chotudada_fakecall.Fragment.WallpaperFragment;
import com.msa.chotudada_fakecall.adapter.MainFragmentPagerAdapter;
import com.msa.chotudada_fakecall.BuildConfig;
import com.msa.chotudada_fakecall.R;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.material.tabs.TabLayout;
import com.startapp.sdk.ads.banner.Banner;
import com.startapp.sdk.ads.banner.banner3d.Banner3D;
import com.startapp.sdk.adsbase.Ad;
import com.startapp.sdk.adsbase.StartAppAd;
import com.startapp.sdk.adsbase.adlisteners.AdEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.msa.chotudada_fakecall.config.Settings.ADMOB_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.ADMOB_NATIVE_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.APPLOVIN_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.BACKUP_MODE;
import static com.msa.chotudada_fakecall.config.Settings.BANNER_MOPUB;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_BACKUP_ADS;

public class MenuActivity extends AppCompatActivity{
    ViewPager viewPager;
    TabLayout tabLayout;
    MainFragmentPagerAdapter mainFragmentPagerAdapter;
    public StartAppAd startAppAd = new StartAppAd(MenuActivity.this);
    public static Activity fa;
    RelativeLayout mainLayout;
    private RelativeLayout layAds;
    private AdView adView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.CAMERA}, 1);
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            if (!Settings.canDrawOverlays(this)) {
                checkPermission();

            }
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            int LAYOUT_FLAG = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
            WindowManager.LayoutParams mWindowParams = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                    LAYOUT_FLAG, // Overlay over the other apps.
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE    // This flag will enable the back key press.
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, // make the window to deliver the focus to the BG window.
                    PixelFormat.TRANSPARENT);
        }

        viewPager = findViewById(R.id.viewPager);
        setupViewPager(viewPager);
        tabLayout = findViewById(R.id.tabLayout);
        tabLayout.setupWithViewPager(viewPager);

///load native
        layAds = findViewById(R.id.layAds);
        mainLayout = (RelativeLayout) findViewById(R.id.mainLayout);
        switch (com.msa.chotudada_fakecall.config.Settings.SELECT_BANNER) {
            case "ADMOB":
                if (com.msa.chotudada_fakecall.config.Settings.BANNER_APA_NATIVE.equals("NATIVE")){
                    nativeadmob();
                } else {
                    adView = new AdView(this);
                    adView.setAdUnitId(ADMOB_BANNER);
                    layAds.addView(adView);
                    loadBanner();
                }
                break;
            case "APPLOVIN":
                AdSettings.setDataProcessingOptions(new String[]{});
                AppLovinSdk.getInstance(MenuActivity.this).setMediationProvider(AppLovinMediationProvider.MAX);
                AppLovinSdk sdk = AppLovinSdk.getInstance(MenuActivity.this);
                sdk.getSettings().setMuted(!sdk.getSettings().isMuted());
                MaxAdView adView;
                adView = new MaxAdView(APPLOVIN_BANNER, (Activity) MenuActivity.this);
                //AppLovinAdView adView = new AppLovinAdView(AppLovinAdSize.BANNER, context);
                final boolean isTablet = AppLovinSdkUtils.isTablet(MenuActivity.this);
                final int heightPx = AppLovinSdkUtils.dpToPx(MenuActivity.this, isTablet ? 90 : 50);
                adView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, heightPx));
                mainLayout.addView(adView);
                adView.loadAd();
                break;
            case "STARTAPP":
                Banner3D startAppBanner = new Banner3D(MenuActivity.this);
                RelativeLayout.LayoutParams bannerParameters =
                        new RelativeLayout.LayoutParams(
                                RelativeLayout.LayoutParams.WRAP_CONTENT,
                                RelativeLayout.LayoutParams.WRAP_CONTENT);
                bannerParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);
                mainLayout.addView(startAppBanner, bannerParameters);
                break;
            case "MOPUB":
                Map<String, String> facebookBanner = new HashMap<>();
                facebookBanner.put("native_banner", "true");
                SdkConfiguration.Builder configBuilder = new SdkConfiguration.Builder(BANNER_MOPUB);
                configBuilder.withMediatedNetworkConfiguration(FacebookBanner.class.getName(), facebookBanner);
                MoPubView moPubView;
                moPubView = new MoPubView(this);
                moPubView.setAdUnitId(BANNER_MOPUB);
                mainLayout.addView(moPubView);
                moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_50);
                moPubView.loadAd();
                break;
        }



    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_share) {
            String shareLink = "https://play.google.com/store/apps/details?id="
                    + BuildConfig.APPLICATION_ID;
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT,
                    getResources().getString(R.string.shareit)+" "
                            + shareLink);
            sendIntent.setType("text/plain");
            startActivity(sendIntent);
            return true;
        } else if (id == R.id.menu_rate) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id="
                    + BuildConfig.APPLICATION_ID)));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void setupViewPager(ViewPager viewPager) {
        mainFragmentPagerAdapter = new MainFragmentPagerAdapter(getSupportFragmentManager());
        mainFragmentPagerAdapter.addFragment(new ContactFragment(), getString(R.string.contact));
        mainFragmentPagerAdapter.addFragment(new WallpaperFragment(), getString(R.string.wallpaper));
        viewPager.setAdapter(mainFragmentPagerAdapter);

    }

    public static int ACTION_MANAGE_OVERLAY_PERMISSION_REQUEST_CODE = 5469;
    @TargetApi(Build.VERSION_CODES.M)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ACTION_MANAGE_OVERLAY_PERMISSION_REQUEST_CODE) {
            if (!Settings.canDrawOverlays(this)) {
                // You don't have permission
                checkPermission();
            } else {
                // Do as per your logic
            }

        }


    }

    public void checkPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, ACTION_MANAGE_OVERLAY_PERMISSION_REQUEST_CODE);
            }
        }
    }



    private NativeAd nativeAd;
    private void nativeadmob() {
        refreshAd();
    }

    private void populateNativeAdView(NativeAd nativeAd, NativeAdView adView) {
        adView.setMediaView((MediaView) adView.findViewById(R.id.ad_media));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));
        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        adView.getMediaView().setMediaContent(nativeAd.getMediaContent());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getPrice() == null) {
            adView.getPriceView().setVisibility(View.INVISIBLE);
        } else {
            adView.getPriceView().setVisibility(View.VISIBLE);
            ((TextView) adView.getPriceView()).setText(nativeAd.getPrice());
        }

        if (nativeAd.getStore() == null) {
            adView.getStoreView().setVisibility(View.INVISIBLE);
        } else {
            adView.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) adView.getStoreView()).setText(nativeAd.getStore());
        }

        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.INVISIBLE);
        } else {
            ((TextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.VISIBLE);
        }
        adView.setNativeAd(nativeAd);
    }

    private void refreshAd() {

        AdLoader.Builder builder = new AdLoader.Builder(this, ADMOB_NATIVE_BANNER);

        builder.forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {
            @Override
            public void onNativeAdLoaded(@NonNull com.google.android.gms.ads.nativead.NativeAd nativeAds) {

                if (nativeAd != null) {
                    nativeAd.destroy();
                }

                nativeAd = nativeAds;
                FrameLayout frameLayout =
                        findViewById(R.id.fl_adplaceholder);
                NativeAdView adView = (NativeAdView) getLayoutInflater()
                        .inflate(R.layout.admob_kecil, null);
                populateNativeAdView(nativeAds, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });

        VideoOptions videoOptions = new VideoOptions.Builder()
                .build();

        com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader =
                builder
                        .withAdListener(
                                new AdListener() {
                                    @Override
                                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                                        if (BACKUP_MODE.equals("YES")){

                                            switch (SELECT_BACKUP_ADS) {
                                                case "STARTAPP":
                                                    Banner3D startAppBanner = new Banner3D(MenuActivity.this);
                                                    RelativeLayout.LayoutParams bannerParameters =
                                                            new RelativeLayout.LayoutParams(
                                                                    RelativeLayout.LayoutParams.WRAP_CONTENT,
                                                                    RelativeLayout.LayoutParams.WRAP_CONTENT);
                                                    bannerParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);
                                                    mainLayout.addView(startAppBanner, bannerParameters);
                                                    startAppAd.loadAd (new AdEventListener() {
                                                        @Override
                                                        public void onReceiveAd(com.startapp.sdk.adsbase.Ad ad) {

                                                        }

                                                        @Override
                                                        public void onFailedToReceiveAd(com.startapp.sdk.adsbase.Ad ad) {
                                                        }
                                                    });
                                                    break;
                                                case "APPLOVIN":
                                                    MaxAdView adView;
                                                    adView = new MaxAdView(APPLOVIN_BANNER, (Activity) MenuActivity.this);
                                                    //AppLovinAdView adView = new AppLovinAdView(AppLovinAdSize.BANNER, context);
                                                    final boolean isTablet = AppLovinSdkUtils.isTablet(MenuActivity.this);
                                                    final int heightPx = AppLovinSdkUtils.dpToPx(MenuActivity.this, isTablet ? 90 : 50);
                                                    adView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, heightPx));
                                                    mainLayout.addView(adView);
                                                    adView.loadAd();
                                                    break;
                                                case "MOPUB":
                                                    MoPubView moPubView;
                                                    moPubView = new MoPubView(MenuActivity.this);
                                                    moPubView.setAdUnitId(BANNER_MOPUB);
                                                    mainLayout.addView(moPubView);
                                                    moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_50);
                                                    moPubView.setBannerAdListener((MoPubView.BannerAdListener) MenuActivity.this);
                                                    // Sent when the banner has failed to retrieve an ad. You can use the MoPubErrorCode value to diagnose the cause of failure.
                                                    break;
                                            }
                                        }
                                    }
                                })
                        .build();
        adLoader.loadAd(MulaiActivity.request);

    }


    private void loadBanner() {
        AdSize adSize = getAdSize();
        adView.setAdSize(adSize);
        adView.loadAd(MulaiActivity.request);
        adView.setAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                if (BACKUP_MODE.equals("YES")){

                    switch (SELECT_BACKUP_ADS) {
                        case "STARTAPP":
                            Banner3D startAppBanner = new Banner3D(MenuActivity.this);
                            RelativeLayout.LayoutParams bannerParameters =
                                    new RelativeLayout.LayoutParams(
                                            RelativeLayout.LayoutParams.WRAP_CONTENT,
                                            RelativeLayout.LayoutParams.WRAP_CONTENT);
                            bannerParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);
                            mainLayout.addView(startAppBanner, bannerParameters);
                            startAppAd.loadAd (new AdEventListener() {
                                @Override
                                public void onReceiveAd(Ad ad) {

                                }

                                @Override
                                public void onFailedToReceiveAd(Ad ad) {
                                }
                            });
                            break;
                        case "APPLOVIN":
                            MaxAdView adView;
                            adView = new MaxAdView(APPLOVIN_BANNER, (Activity) MenuActivity.this);
                            //AppLovinAdView adView = new AppLovinAdView(AppLovinAdSize.BANNER, context);
                            final boolean isTablet = AppLovinSdkUtils.isTablet(MenuActivity.this);
                            final int heightPx = AppLovinSdkUtils.dpToPx(MenuActivity.this, isTablet ? 90 : 50);
                            adView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, heightPx));
                            mainLayout.addView(adView);
                            adView.loadAd();
                            break;
                        case "MOPUB":
                            Map<String, String> facebookBanner = new HashMap<>();
                            facebookBanner.put("native_banner", "true");
                            SdkConfiguration.Builder configBuilder = new SdkConfiguration.Builder(BANNER_MOPUB);
                            configBuilder.withMediatedNetworkConfiguration(FacebookBanner.class.getName(), facebookBanner);
                            MoPubView moPubView;
                            moPubView = new MoPubView(MenuActivity.this);
                            moPubView.setAdUnitId(BANNER_MOPUB);
                            mainLayout.addView(moPubView);
                            moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_50);
                            moPubView.loadAd();
                            // Sent when the banner has failed to retrieve an ad. You can use the MoPubErrorCode value to diagnose the cause of failure.
                            break;
                    }
                }
            }
        });


    }
    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

}
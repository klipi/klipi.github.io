package com.msa.chotudada_fakecall.model;

public class Wallpaper {

    private int login;
    private String avatar_url;
    private String html_url;

    public int getLogin() {
        return login;
    }

    public String getAvatar_url() {
        return avatar_url;
    }

    public String getHtml_url() {
        return html_url;
    }

    public Wallpaper(int id, String jdl, String img) {
        this.login = id;
        this.html_url = jdl;
        this.avatar_url = img;
    }


}

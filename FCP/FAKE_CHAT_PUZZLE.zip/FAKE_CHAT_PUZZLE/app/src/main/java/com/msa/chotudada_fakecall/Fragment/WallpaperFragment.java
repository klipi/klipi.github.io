package com.msa.chotudada_fakecall.Fragment;

import android.app.Activity;
import android.app.ProgressDialog;
import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.msa.chotudada_fakecall.activity.MulaiActivity;
import com.msa.chotudada_fakecall.R;
import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdRequest;

import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.startapp.sdk.adsbase.StartAppAd;

import java.io.IOException;

import static android.content.ContentValues.TAG;
import static com.msa.chotudada_fakecall.config.Settings.ADMOB_INTER;
import static com.msa.chotudada_fakecall.config.Settings.BACKUP_MODE;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_BACKUP_ADS;
import static com.msa.chotudada_fakecall.config.Settings.COUNTER;
import static com.msa.chotudada_fakecall.config.Settings.INTERVAL;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_INTER;

public class WallpaperFragment extends Fragment {

    private TextView txtjdl;
    private ImageView imggbr, imgback, imgnext;
    private Button setwall;
    int pos =0;
    public Context context;
    public static AdRequest adRequest ;
    public StartAppAd startAppAd = new StartAppAd (getContext());
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_wallpaper, container, false);


        txtjdl = view.findViewById(R.id.txtimgwall);
        imggbr = view.findViewById(R.id.imgwall);
        setwall = view.findViewById(R.id.btwall);

        Glide.with(this).load(MulaiActivity.webLists.get(pos).getAvatar_url())
                .centerCrop().into(imggbr);
        txtjdl.setText(MulaiActivity.webLists.get(pos).getHtml_url());
        setHasOptionsMenu(true);

        imgback = view.findViewById(R.id.imgback);
        imgnext= view.findViewById(R.id.imgnext);

        setwall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bitmap bitmap = ((BitmapDrawable)imggbr.getDrawable()).getBitmap();
                try {
                    WallpaperManager myWallpaperManager
                            = WallpaperManager.getInstance(getActivity().getApplicationContext());
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        myWallpaperManager.setBitmap(bitmap, null, true, WallpaperManager.FLAG_SYSTEM);
                    }
                    Toast.makeText(getActivity(), "Wallpaper set Home Screen",
                            Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    Toast.makeText(getActivity(),
                            "Error setting wallpaper", Toast.LENGTH_SHORT)
                            .show();
                }

            }
        });
        switch (SELECT_INTER) {
            case "ADMOB":
                if (MulaiActivity.mInterstitialAd == null) {
                    InterstitialAd.load(getContext(), ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            MulaiActivity.mInterstitialAd = interstitialAd;
                            Log.i(TAG, "onAdLoaded");
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            MulaiActivity.mInterstitialAd = null;
                        }
                    });
                }
                break;
            case "STARTAPP" :
                startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                break;

        }

        imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pos--;
                pos = (pos + MulaiActivity.webLists.size()) % MulaiActivity.webLists.size();
                Glide.with(getActivity()).load(MulaiActivity.webLists.get(pos).getAvatar_url())
                        .centerCrop().into(imggbr);
                txtjdl.setText(MulaiActivity.webLists.get(pos).getHtml_url());
                if (COUNTER>=INTERVAL){
                   munculinterbaru();
                    COUNTER=0;
                } else {

                    COUNTER++;
                }

            }
        });

        imgnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pos++;
                pos = pos % MulaiActivity.webLists.size();
                Glide.with(getActivity()).load(MulaiActivity.webLists.get(pos).getAvatar_url())
                        .centerCrop().into(imggbr);
                txtjdl.setText(MulaiActivity.webLists.get(pos).getHtml_url());
                if (COUNTER>=INTERVAL){
                    switch (SELECT_INTER) {
                        case "ADMOB":
                            munculinterbaru();
                    }
                    COUNTER=0;
                } else {
                    switch (SELECT_INTER) {
                        case "ADMOB":
                            if (MulaiActivity.mInterstitialAd == null) {
                                InterstitialAd.load(getContext(), ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                                    @Override
                                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                                        MulaiActivity.mInterstitialAd = interstitialAd;
                                        Log.i(TAG, "onAdLoaded");
                                    }

                                    @Override
                                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                        MulaiActivity.mInterstitialAd = null;
                                    }
                                });
                            }
                            break;
                        case "STARTAPP" :
                            startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                            break;

                    }
                    COUNTER++;
                }
            }
        });
        return view;
    }
    private void munculinterbaru() {
        switch (SELECT_INTER) {
            case "ADMOB":
                final ProgressDialog progressDialog = new ProgressDialog(getActivity());
                progressDialog.setMessage("Loading ads...");
                progressDialog.setCancelable(true);
                progressDialog.show();
                new CountDownTimer(3000, 1000) {
                    @Override
                    public void onFinish() {
                        progressDialog.dismiss();

                        if (MulaiActivity.mInterstitialAd != null) {
                            MulaiActivity.mInterstitialAd.show((Activity)(context));
                            InterstitialAd.load( getContext(), ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                                @Override
                                public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                                    MulaiActivity.mInterstitialAd = interstitialAd;
                                    Log.i(TAG, "onAdLoaded");
                                }

                                @Override
                                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                    MulaiActivity.mInterstitialAd = null;
                                }
                            });
                        } else {
                            InterstitialAd.load( getContext(), ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                                @Override
                                public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                                    MulaiActivity.mInterstitialAd = interstitialAd;
                                    Log.i(TAG, "onAdLoaded");
                                }

                                @Override
                                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                    MulaiActivity.mInterstitialAd = null;
                                }
                            });
                            if (BACKUP_MODE.equals("YES")) {
                                switch (SELECT_BACKUP_ADS) {
                                    case "STARTAPP":
                                        startAppAd.showAd(getContext());
                                        startAppAd.loadAd(StartAppAd.AdMode.VIDEO);

                                        break;
                                    case "APPLOVIN":
                                        if (MulaiActivity.interstitialAd.isReady()) {
                                            MulaiActivity.interstitialAd.showAd();
                                        } else {
                                            MulaiActivity.interstitialAd.loadAd();
                                        }
                                        break;
                                    case "MOPUB":
                                        if (MulaiActivity.mInterstitial.isReady()) {
                                            MulaiActivity.mInterstitial.show();
                                            MulaiActivity.mInterstitial.load();
                                        } else {
                                            MulaiActivity.mInterstitial.load();
                                        }
                                        break;
                                }
                            }
                        }
                    }

                    @Override
                    public void onTick(long millisUntilFinished) {

                    }
                }.start();


                break;
            case "APPLOVIN":
                if (MulaiActivity.interstitialAd.isReady()) {
                    MulaiActivity.interstitialAd.showAd();
                } else {
                    MulaiActivity.interstitialAd.loadAd();
                }
                break;
            case "STARTAPP":
                StartAppAd.showAd(getContext());
                startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                break;
            case "MOPUB":
                if (MulaiActivity.mInterstitial.isReady()) {
                    MulaiActivity.mInterstitial.show();
                    MulaiActivity.mInterstitial.load();
                } else {
                    MulaiActivity.mInterstitial.load();
                }
                break;
        }
    }



}
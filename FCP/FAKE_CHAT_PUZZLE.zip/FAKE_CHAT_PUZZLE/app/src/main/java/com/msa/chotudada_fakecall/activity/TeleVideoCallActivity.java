package com.msa.chotudada_fakecall.activity;

import android.content.Intent;
import android.graphics.PixelFormat;
import android.hardware.Camera;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.msa.chotudada_fakecall.BuildConfig;
import com.msa.chotudada_fakecall.R;
import com.msa.chotudada_fakecall.config.Settings;
import com.applovin.adview.AppLovinInterstitialAd;
import com.applovin.adview.AppLovinInterstitialAdDialog;
import com.applovin.sdk.AppLovinAd;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.squareup.picasso.Picasso;
import com.startapp.sdk.adsbase.Ad;
import com.startapp.sdk.adsbase.StartAppAd;

import de.hdodenhof.circleimageview.CircleImageView;

import static android.content.ContentValues.TAG;
import static com.msa.chotudada_fakecall.adapter.FakeAdapter.gambar;
import static com.msa.chotudada_fakecall.adapter.FakeAdapter.judul;
import static com.msa.chotudada_fakecall.adapter.FakeAdapter.video;
import static com.msa.chotudada_fakecall.config.Settings.ADMOB_INTER;
import static com.msa.chotudada_fakecall.config.Settings.BACKUP_MODE;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_BACKUP_ADS;
import static com.msa.chotudada_fakecall.config.Settings.FAN_INTER;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_INTER;


public class TeleVideoCallActivity extends AppCompatActivity implements SurfaceHolder.Callback {
    MediaPlayer mp;
    Camera camera;
    SurfaceView surfaceView,surfaceView2 ;
    SurfaceHolder surfaceHolder;
    VideoView videoView;

    private TextView calling, nameuser;
    private ImageView  adduser;
    private CircleImageView imguser;

    private RelativeLayout cancel, terima, pesan, tolak;
    Handler handler;
    private LinearLayout atas, bawah;
    private com.facebook.ads.InterstitialAd interstitialAdfb;
    private AppLovinInterstitialAdDialog interstitialAdlovin;
    private AppLovinAd loadedAd;

    public static InterstitialAd mInterstitialAd;
    public static AdRequest adRequest ;
    public StartAppAd startAppAd = new StartAppAd(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tele_video_call);

        switch (SELECT_INTER) {
            case "ADMOB":
                if (MulaiActivity.mInterstitialAd == null) {
                    InterstitialAd.load(TeleVideoCallActivity.this, ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            MulaiActivity.mInterstitialAd = interstitialAd;
                            Log.i(TAG, "onAdLoaded");
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            MulaiActivity.mInterstitialAd = null;
                        }
                    });
                }
                break;
            case "STARTAPP":
                startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                break;

        }

        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        mp = MediaPlayer.create(getApplicationContext(), notification);
        mp.start();
        mp.setLooping(true);

        atas = findViewById(R.id.atas);
        bawah = findViewById(R.id.bawah);
        videoView = findViewById(R.id.videoView);

        String uriPath = video;
        if (Settings.ON_OFF_DATA.equals("1")){
            Uri uri = Uri.parse(uriPath);
            videoView.setVideoURI(uri);
            videoView.requestFocus();
        } else if (Settings.ON_OFF_DATA.equals("0")){
            String fileName = "android.resource://"+  BuildConfig.APPLICATION_ID + "/raw/"+video;
            videoView.setVideoURI(Uri.parse(fileName));
            videoView.requestFocus();
            if (uriPath.startsWith("http")) {
                Uri uri = Uri.parse(uriPath);
                videoView.setVideoURI(uri);
            }
        }

        surfaceView = findViewById(R.id.surfaceView);
        surfaceView2 = findViewById(R.id.surfaceView2);
        surfaceView2.setVisibility(View.GONE);
        surfaceHolder = surfaceView.getHolder();
        surfaceHolder.addCallback(this);
        surfaceHolder.setFormat(PixelFormat.OPAQUE);
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_NORMAL);
        handler = new Handler() ;

        calling = findViewById(R.id.txtcall);
        nameuser = findViewById(R.id.txtname);
        imguser = findViewById(R.id.imguser);
        adduser = findViewById(R.id.adduser);
        adduser.setVisibility(View.INVISIBLE);
        cancel = findViewById(R.id.layclose2);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TeleVideoCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                mp.stop();
                munculinterbaru();
            }
        });

        pesan = findViewById(R.id.laypesan);
        pesan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TeleVideoCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                mp.stop();
                munculinterbaru();
            }
        });

        tolak = findViewById(R.id.layclose);
        tolak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TeleVideoCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                mp.stop();
                munculinterbaru();
            }
        });

        terima = findViewById(R.id.layterima);
        terima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.stop();
                mp.stop();
                calling.setVisibility(View.GONE);
                nameuser.setVisibility(View.GONE);
                imguser.setVisibility(View.GONE);
                adduser.setVisibility(View.VISIBLE);
                surfaceView.setVisibility(View.GONE);
                surfaceView2.setVisibility(View.VISIBLE);
                surfaceHolder = surfaceView2.getHolder();
                surfaceHolder.addCallback(TeleVideoCallActivity.this);
                surfaceHolder.setFormat(PixelFormat.OPAQUE);
                surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_NORMAL);

                videoView.start();
                atas.setVisibility(View.GONE);
                bawah.setVisibility(View.VISIBLE);
                tolak.setVisibility(View.VISIBLE);

            }
        });

        imguser = findViewById(R.id.imguser);
        Picasso.get()
                .load(gambar)
                .into(imguser);
        nameuser.setText(judul);

    }






    public void surfaceCreated(SurfaceHolder surfaceHolder ) {
        camera = Camera.open(1);
        Camera.Parameters parameters;
        parameters = camera.getParameters();
        camera.setParameters(parameters);
        camera.setDisplayOrientation(90);
        try {
            camera.setPreviewDisplay(surfaceHolder);
            camera.startPreview();

        }catch (Exception e){
        }

    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int i, int i1, int i2) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        camera.stopPreview();
        camera.release();
        camera=null;

    }

    public void onBackPressed(){
        mp.stop();
        Intent intent = new Intent(TeleVideoCallActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
        mp.stop();
        munculinterbaru();
    }


    private void munculinterbaru() {
        switch (SELECT_INTER) {
            case "ADMOB":
                if (MulaiActivity.mInterstitialAd != null) {
                    MulaiActivity.mInterstitialAd.show(TeleVideoCallActivity.this);
                    InterstitialAd.load(TeleVideoCallActivity.this, ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            MulaiActivity.mInterstitialAd = interstitialAd;
                            Log.i(TAG, "onAdLoaded");
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            MulaiActivity.mInterstitialAd = null;
                        }
                    });
                } else {
                    InterstitialAd.load(TeleVideoCallActivity.this, ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            MulaiActivity.mInterstitialAd = interstitialAd;
                            Log.i(TAG, "onAdLoaded");
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                            MulaiActivity.mInterstitialAd = null;
                        }
                    });
                    if (BACKUP_MODE.equals("YES")) {
                        switch (SELECT_BACKUP_ADS) {
                            case "STARTAPP":
                                startAppAd.showAd();
                                startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                                break;
                            case "APPLOVIN":
                                if (MulaiActivity.interstitialAd.isReady()) {
                                    MulaiActivity.interstitialAd.showAd();
                                } else {
                                    MulaiActivity.interstitialAd.loadAd();
                                }
                                break;
                            case "MOPUB":
                                if (MulaiActivity.mInterstitial.isReady()) {
                                    MulaiActivity.mInterstitial.show();
                                    MulaiActivity.mInterstitial.load();
                                } else {
                                    MulaiActivity.mInterstitial.load();
                                }
                                break;
                        }
                    }
                }
                break;
            case "APPLOVIN":
                if (MulaiActivity.interstitialAd.isReady()) {
                    MulaiActivity.interstitialAd.showAd();
                } else {
                    MulaiActivity.interstitialAd.loadAd();
                }
                break;
            case "STARTAPP":
                startAppAd.showAd();
                startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                break;
            case "MOPUB":
                if (MulaiActivity.mInterstitial.isReady()) {
                    MulaiActivity.mInterstitial.show();
                    MulaiActivity.mInterstitial.load();
                } else {
                    MulaiActivity.mInterstitial.load();
                }
                break;
        }
    }

}
package com.msa.chotudada_fakecall.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.msa.chotudada_fakecall.R;
import com.applovin.adview.AppLovinInterstitialAd;
import com.applovin.adview.AppLovinInterstitialAdDialog;
import com.applovin.sdk.AppLovinAd;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.squareup.picasso.Picasso;
import com.startapp.sdk.adsbase.Ad;
import com.startapp.sdk.adsbase.StartAppAd;

import java.io.IOException;

import de.hdodenhof.circleimageview.CircleImageView;

import static android.content.ContentValues.TAG;
import static com.msa.chotudada_fakecall.adapter.FakeAdapter.gambar;
import static com.msa.chotudada_fakecall.adapter.FakeAdapter.judul;
import static com.msa.chotudada_fakecall.adapter.FakeAdapter.voice;
import static com.msa.chotudada_fakecall.config.Settings.ADMOB_INTER;
import static com.msa.chotudada_fakecall.config.Settings.BACKUP_MODE;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_BACKUP_ADS;
import static com.msa.chotudada_fakecall.config.Settings.FAN_INTER;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_INTER;

public class WAVoiceCallActivity extends AppCompatActivity {
    MediaPlayer mp;
    private RelativeLayout cancel, terima, pesan, tolak;
    private LinearLayout atas, bawah;
    int Seconds, Minutes, MilliSeconds, hours ;
    long MillisecondTime, StartTime, TimeBuff, UpdateTime = 0L ;
    Handler handler;
    private TextView calling, nameuser;
    private ImageView imguser,  imguser2, adduser;
    CircleImageView gambrH;

    private com.facebook.ads.InterstitialAd interstitialAdfb;
    private AppLovinInterstitialAdDialog interstitialAdlovin;
    private AppLovinAd loadedAd;
    public static InterstitialAd mInterstitialAd;
    public static AdRequest adRequest ;
    public StartAppAd startAppAd = new StartAppAd(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voice_call);
        switch (SELECT_INTER) {
            case "ADMOB":
                if (MulaiActivity.mInterstitialAd == null) {
                    InterstitialAd.load(WAVoiceCallActivity.this, ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            MulaiActivity.mInterstitialAd = interstitialAd;
                            Log.i(TAG, "onAdLoaded");
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            MulaiActivity.mInterstitialAd = null;
                        }
                    });
                }
                break;
            case "STARTAPP":
                startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                break;


        }

        atas = findViewById(R.id.atas);
        bawah = findViewById(R.id.bawah);
        calling = findViewById(R.id.txtcall);
        imguser2 = findViewById(R.id.imguser2);
        adduser = findViewById(R.id.adduser);
        adduser.setVisibility(View.INVISIBLE);
        cancel = findViewById(R.id.layclose2);
        tolak = findViewById(R.id.layclose);
        pesan = findViewById(R.id.laypesan);
        pesan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.stop();
                Intent intent = new Intent(WAVoiceCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();

            }
        });
        handler = new Handler() ;
        tolak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.stop();
                Intent intent = new Intent(WAVoiceCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                munculinterbaru();

            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.stop();
                Intent intent = new Intent(WAVoiceCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
               munculinterbaru();
            }
        });

        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        mp = MediaPlayer.create(getApplicationContext(), notification);
        mp.start();
        mp.setLooping(true);
        TextView judulH = findViewById(R.id.txtname);
        judulH.setText(judul);

        gambrH = findViewById(R.id.imguser);
        Picasso.get()
                .load(gambar)
                .into(gambrH);

        terima = findViewById(R.id.layterima);
        terima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                atas.setVisibility(View.GONE);
                tolak.setVisibility(View.VISIBLE);
                bawah.setVisibility(View.VISIBLE);
                imguser2.setVisibility(View.VISIBLE);
                StartTime = SystemClock.uptimeMillis();
                handler.postDelayed(runnable, 0);
                Picasso.get()
                        .load(gambar)
                        .into(imguser2);

                String url = voice;
                     mp.stop();
                    try {

                        mp = new MediaPlayer();
                        if (url.startsWith("http")) {
                            mp.setDataSource(url);
                            mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
                        } else {
                            AssetFileDescriptor descriptor;
                            descriptor = getAssets().openFd(url);
                            mp.setDataSource(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength());
                            descriptor.close();
                            mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
                        }
                        mp.prepareAsync();
                        mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                            @Override
                            public void onPrepared(MediaPlayer mp) {
                                mp.start();
                            }
                        });

                    } catch (IllegalArgumentException | IllegalStateException | IOException e) {
                        e.printStackTrace();
                    }
            }
        });


    }






    public void onBackPressed(){
     mp.stop();
        Intent intent = new Intent(WAVoiceCallActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
        munculinterbaru();
    }

    public Runnable runnable = new Runnable() {

        @SuppressLint({"DefaultLocale", "SetTextI18n"})
        public void run() {
            MillisecondTime = SystemClock.uptimeMillis() - StartTime;
            UpdateTime = TimeBuff + MillisecondTime;
            Seconds = (int) (UpdateTime / 1000);
            Minutes = Seconds / 60;
            Seconds = Seconds % 60;
            hours = Minutes/60;
            MilliSeconds = (int) (UpdateTime % 1000);
            calling.setText(String.format("%02d", hours) +":"+ String.format("%02d", Minutes) + ":"
                    + String.format("%02d", Seconds));
            handler.postDelayed(this, 0);
        }

    };



    private void munculinterbaru() {
        switch (SELECT_INTER) {
            case "ADMOB":
                if (MulaiActivity.mInterstitialAd != null) {
                    MulaiActivity.mInterstitialAd.show(WAVoiceCallActivity.this);
                    InterstitialAd.load(WAVoiceCallActivity.this, ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            MulaiActivity.mInterstitialAd = interstitialAd;
                            Log.i(TAG, "onAdLoaded");
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            MulaiActivity.mInterstitialAd = null;
                        }
                    });
                } else {
                    InterstitialAd.load(WAVoiceCallActivity.this, ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            MulaiActivity.mInterstitialAd = interstitialAd;
                            Log.i(TAG, "onAdLoaded");
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                            MulaiActivity.mInterstitialAd = null;
                        }
                    });
                    if (BACKUP_MODE.equals("YES")) {
                        switch (SELECT_BACKUP_ADS) {
                            case "STARTAPP":
                                startAppAd.showAd();
                                startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                                break;
                            case "APPLOVIN":
                                if (MulaiActivity.interstitialAd.isReady()) {
                                    MulaiActivity.interstitialAd.showAd();
                                } else {
                                    MulaiActivity.interstitialAd.loadAd();
                                }
                                break;
                            case "MOPUB":
                                if (MulaiActivity.mInterstitial.isReady()) {
                                    MulaiActivity.mInterstitial.show();
                                    MulaiActivity.mInterstitial.load();
                                } else {
                                    MulaiActivity.mInterstitial.load();
                                }
                                break;
                        }
                    }
                }
                break;
            case "APPLOVIN":
                if (MulaiActivity.interstitialAd.isReady()) {
                    MulaiActivity.interstitialAd.showAd();
                } else {
                    MulaiActivity.interstitialAd.loadAd();
                }
                break;
            case "STARTAPP":
                startAppAd.showAd();
                startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                break;
            case "MOPUB":
                if (MulaiActivity.mInterstitial.isReady()) {
                    MulaiActivity.mInterstitial.show();
                    MulaiActivity.mInterstitial.load();
                } else {
                    MulaiActivity.mInterstitial.load();
                }
                break;
        }
    }

}
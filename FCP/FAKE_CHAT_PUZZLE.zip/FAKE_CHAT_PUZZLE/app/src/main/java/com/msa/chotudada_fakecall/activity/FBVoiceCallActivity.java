package com.msa.chotudada_fakecall.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.msa.chotudada_fakecall.R;
import com.applovin.adview.AppLovinInterstitialAd;
import com.applovin.adview.AppLovinInterstitialAdDialog;
import com.applovin.sdk.AppLovinAd;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.squareup.picasso.Picasso;
import com.startapp.sdk.adsbase.Ad;
import com.startapp.sdk.adsbase.StartAppAd;

import java.io.IOException;

import de.hdodenhof.circleimageview.CircleImageView;

import static android.content.ContentValues.TAG;
import static com.msa.chotudada_fakecall.adapter.FakeAdapter.gambar;
import static com.msa.chotudada_fakecall.adapter.FakeAdapter.judul;
import static com.msa.chotudada_fakecall.adapter.FakeAdapter.voice;
import static com.msa.chotudada_fakecall.config.Settings.ADMOB_INTER;
import static com.msa.chotudada_fakecall.config.Settings.BACKUP_MODE;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_BACKUP_ADS;
import static com.msa.chotudada_fakecall.config.Settings.FAN_INTER;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_INTER;


public class FBVoiceCallActivity extends AppCompatActivity {
    CircleImageView gambrH;
    ImageView gambrB, imgback;
    MediaPlayer mp;
    RelativeLayout terima, tolak, tolak2;
    LinearLayout atas, bawah;
    int Seconds, Minutes, MilliSeconds, hours ;
    long MillisecondTime, StartTime, TimeBuff, UpdateTime = 0L ;
    Handler handler;
    TextView calling;
    public static InterstitialAd mInterstitialAd;
    public static AdRequest adRequest ;
    public static com.facebook.ads.InterstitialAd interstitialAdfb;
    public static AppLovinInterstitialAdDialog interstitialAdlovin;
    public static AppLovinAd loadedAd;
    public StartAppAd startAppAd = new StartAppAd(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_f_b_voice_call);
        switch (SELECT_INTER) {
            case "ADMOB":
                if (MulaiActivity.mInterstitialAd == null) {
                    InterstitialAd.load(FBVoiceCallActivity.this, ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            MulaiActivity.mInterstitialAd = interstitialAd;
                            Log.i(TAG, "onAdLoaded");
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            MulaiActivity.mInterstitialAd = null;
                        }
                    });
                }
                break;
            case "STARTAPP":
                startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                break;

        }

        handler = new Handler() ;
        atas = findViewById(R.id.laybawah1);
        bawah = findViewById(R.id.laybawah2);
        calling = findViewById(R.id.txtwaktu);

        mp = MediaPlayer.create(this, R.raw.facebook);
        mp.start();
        mp.setLooping(true);

        tolak = findViewById(R.id.laytolak);
        tolak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FBVoiceCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                mp.stop();
               munculinterbaru();

            }
        });

        imgback = findViewById(R.id.imgback2);
        imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FBVoiceCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                mp.stop();
               munculinterbaru();
            }
        });
        tolak2 = findViewById(R.id.laytolak2);
        tolak2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FBVoiceCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                mp.stop();
                munculinterbaru();
            }
        });

        terima = findViewById(R.id.layterima);
        terima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StartTime = SystemClock.uptimeMillis();
                handler.postDelayed(runnable, 0);
                atas.setVisibility(View.GONE);
                bawah.setVisibility(View.VISIBLE);
                String url = voice;
                mp.stop();
                try {
                    mp = new MediaPlayer();
                    if (url.startsWith("http")) {
                        mp.setDataSource(url);
                        mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
                    } else {
                        AssetFileDescriptor descriptor;
                        descriptor = getAssets().openFd(url);
                        mp.setDataSource(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength());
                        descriptor.close();
                        mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
                    }
                    mp.prepareAsync();
                    mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                        @Override
                        public void onPrepared(MediaPlayer mp) {
                            mp.start();
                        }
                    });

                } catch (IllegalArgumentException | IllegalStateException | IOException e) {
                    e.printStackTrace();
                }
            }
        });

        TextView judulH = findViewById(R.id.txtfbname);
        judulH.setText(judul);

        gambrH = findViewById(R.id.fbimguser);
        gambrB = findViewById(R.id.imgback);

        Picasso.get()
                .load(gambar)
                .into(gambrH);
        Picasso.get()
                .load(gambar)
                .into(gambrB);
    }






    public Runnable runnable = new Runnable() {

        @SuppressLint({"DefaultLocale", "SetTextI18n"})
        public void run() {
            MillisecondTime = SystemClock.uptimeMillis() - StartTime;
            UpdateTime = TimeBuff + MillisecondTime;
            Seconds = (int) (UpdateTime / 1000);
            Minutes = Seconds / 60;
            Seconds = Seconds % 60;
            hours = Minutes/60;
            MilliSeconds = (int) (UpdateTime % 1000);
            calling.setText(String.format("%02d", hours) +":"+ String.format("%02d", Minutes) + ":"
                    + String.format("%02d", Seconds));

            handler.postDelayed(this, 0);
        }

    };

    public void onBackPressed(){
        mp.stop();
        Intent intent = new Intent(FBVoiceCallActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
        munculinterbaru();
    }







    private void munculinterbaru() {
        switch (SELECT_INTER) {
            case "ADMOB":
                if (MulaiActivity.mInterstitialAd != null) {
                    MulaiActivity.mInterstitialAd.show(FBVoiceCallActivity.this);
                    InterstitialAd.load(FBVoiceCallActivity.this, ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            MulaiActivity.mInterstitialAd = interstitialAd;
                            Log.i(TAG, "onAdLoaded");
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            MulaiActivity.mInterstitialAd = null;
                        }
                    });
                } else {
                    InterstitialAd.load(FBVoiceCallActivity.this, ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            MulaiActivity.mInterstitialAd = interstitialAd;
                            Log.i(TAG, "onAdLoaded");
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                            MulaiActivity.mInterstitialAd = null;
                        }
                    });
                    if (BACKUP_MODE.equals("YES")) {
                        switch (SELECT_BACKUP_ADS) {
                            case "STARTAPP":
                                startAppAd.showAd();
                                startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                                break;
                            case "APPLOVIN":
                                if (MulaiActivity.interstitialAd.isReady()) {
                                    MulaiActivity.interstitialAd.showAd();
                                } else {
                                    MulaiActivity.interstitialAd.loadAd();
                                }
                                break;
                            case "MOPUB":
                                if (MulaiActivity.mInterstitial.isReady()) {
                                    MulaiActivity.mInterstitial.show();
                                    MulaiActivity.mInterstitial.load();
                                } else {
                                    MulaiActivity.mInterstitial.load();
                                }
                                break;
                        }
                    }
                }
                break;
            case "APPLOVIN":
                if (MulaiActivity.interstitialAd.isReady()) {
                    MulaiActivity.interstitialAd.showAd();
                } else {
                    MulaiActivity.interstitialAd.loadAd();
                }
                break;
            case "STARTAPP":
                startAppAd.showAd();
                startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                break;
            case "MOPUB":
                if (MulaiActivity.mInterstitial.isReady()) {
                    MulaiActivity.mInterstitial.show();
                    MulaiActivity.mInterstitial.load();
                } else {
                    MulaiActivity.mInterstitial.load();
                }
                break;
        }
    }

}
package com.msa.chotudada_fakecall.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.msa.chotudada_fakecall.activity.DetailFakeActivity;
import com.msa.chotudada_fakecall.R;
import com.msa.chotudada_fakecall.model.Item;
import com.squareup.picasso.Picasso;

import java.util.List;


public class FakeAdapter extends RecyclerView.Adapter {


    public static String judul ;
    public static String gambar ;
    public static String voice;
    public static String video;
    public static List<Item> webLists;
    public Context context;

    public FakeAdapter(List<Item> webLists, Context context) {
        FakeAdapter.webLists = webLists;
        this.context = context;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder  {
        public ImageView avatar_url;
        public RelativeLayout linearLayout;

        public ViewHolder(View itemView) {
            super(itemView);
            avatar_url = (ImageView) itemView.findViewById(R.id.img_fake);
            linearLayout = itemView.findViewById(R.id.klik_fake);

        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fake_list, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, final int position) {

        if (holder instanceof ViewHolder) {
            final Item webList = webLists.get(position);
            Picasso.get()
                    .load(webList.getImage_url())
                    .into( ((ViewHolder)holder).avatar_url);

            ((ViewHolder)holder).linearLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    judul = webList.getNamefake();
                    gambar = webList.getImage_url();
                    voice = webList.getVoice_url();
                    video = webList.getViode_url();
                    Intent intent = new Intent(context, DetailFakeActivity.class);
                    context.startActivity(intent);
                }
            });

        }

    }

    public int getItemCount() {
        return webLists.size();
    }

}

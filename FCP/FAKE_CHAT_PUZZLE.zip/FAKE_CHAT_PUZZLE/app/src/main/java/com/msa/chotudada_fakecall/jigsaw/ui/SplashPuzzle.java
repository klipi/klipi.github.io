package com.msa.chotudada_fakecall.jigsaw.ui;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.applovin.adview.AppLovinInterstitialAdDialog;
import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdRevenueListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.MaxReward;
import com.applovin.mediation.MaxRewardedAdListener;
import com.applovin.mediation.ads.MaxAdView;
import com.applovin.mediation.ads.MaxRewardedAd;
import com.applovin.sdk.AppLovinAd;
import com.applovin.sdk.AppLovinSdkUtils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.mopub.common.MoPub;
import com.mopub.common.MoPubReward;
import com.mopub.common.SdkConfiguration;
import com.mopub.mobileads.FacebookBanner;
import com.mopub.mobileads.MoPubErrorCode;
import com.mopub.mobileads.MoPubRewardedAdListener;
import com.mopub.mobileads.MoPubRewardedAds;
import com.mopub.mobileads.MoPubView;
import com.msa.chotudada_fakecall.R;
import com.msa.chotudada_fakecall.activity.MulaiActivity;
import com.msa.chotudada_fakecall.config.Settings;
import com.startapp.sdk.ads.banner.banner3d.Banner3D;
import com.startapp.sdk.adsbase.Ad;
import com.startapp.sdk.adsbase.StartAppAd;
import com.startapp.sdk.adsbase.adlisteners.AdEventListener;
import com.startapp.sdk.adsbase.adlisteners.VideoListener;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import static com.msa.chotudada_fakecall.config.Settings.ADMOB_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.ADMOB_NATIVE_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.ADMOB_REWARD;
import static com.msa.chotudada_fakecall.config.Settings.APPLOVIN_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.APPLOVIN_REWARD;
import static com.msa.chotudada_fakecall.config.Settings.BACKUP_MODE;
import static com.msa.chotudada_fakecall.config.Settings.BANNER_MOPUB;
import static com.msa.chotudada_fakecall.config.Settings.REWARD_MOPUB;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_BACKUP_ADS;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_BACKUP_REWARD;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_REWARD;

public class SplashPuzzle extends AppCompatActivity implements MaxAdRevenueListener, MaxRewardedAdListener {
    private MaxRewardedAd MaxReward;
    private AdView adView;
    private MoPubRewardedAdListener rewardedAdListener;
    private TextView Text;
    public static AppLovinInterstitialAdDialog interstitialAdlovin;
    public static AppLovinAd loadedAd;
    public StartAppAd startAppAd = new StartAppAd(this);
    RelativeLayout mainLayout;
    RewardedAd Admobreward;
    final StartAppAd rewardedVideo = new StartAppAd(this);
    protected static final String TAG = SplashPuzzle.class.getSimpleName();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_puzzle);
        MoPub.onCreate(this);

        LoadReward();
        LoadReward2();
        Text = findViewById(R.id.TxtReward);
        TextView availableskin = (TextView) findViewById(R.id.TxtReward);
        availableskin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogpromo1();

            }
        });




        mainLayout = (RelativeLayout) findViewById(R.id.layAds);
        switch (SELECT_BANNER) {
            case "ADMOB":
                if (Settings.BANNER_APA_NATIVE.equals("NATIVE")){
                    nativeadmob();
                } else {
                    adView = new AdView(this);
                    adView.setAdUnitId(ADMOB_BANNER);
                    mainLayout.addView(adView);
                    loadBanner();
                }
                break;
            case "APPLOVIN":
                MaxAdView adView;
                adView = new MaxAdView(APPLOVIN_BANNER, (Activity) SplashPuzzle.this);
                //AppLovinAdView adView = new AppLovinAdView(AppLovinAdSize.BANNER, context);
                final boolean isTablet = AppLovinSdkUtils.isTablet(SplashPuzzle.this);
                final int heightPx = AppLovinSdkUtils.dpToPx(SplashPuzzle.this, isTablet ? 90 : 50);
                adView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, heightPx));
                mainLayout.addView(adView);
                adView.loadAd();
                break;
            case "STARTAPP":
                Banner3D startAppBanner = new Banner3D(SplashPuzzle.this);
                RelativeLayout.LayoutParams bannerParameters =
                        new RelativeLayout.LayoutParams(
                                RelativeLayout.LayoutParams.WRAP_CONTENT,
                                RelativeLayout.LayoutParams.WRAP_CONTENT);
                bannerParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);
                mainLayout.addView(startAppBanner, bannerParameters);
                break;
            case "MOPUB":
                MoPubView moPubView;
                moPubView = new MoPubView(this);
                moPubView.setAdUnitId(BANNER_MOPUB);
                mainLayout.addView(moPubView);
                moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_50);
                moPubView.loadAd();
                break;
        }


    }


    private void dialogpromo1() {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setIcon(R.drawable.ic_send_button);
        builder.setTitle("Play Video Ads to continue");
        builder.setMessage("Internet Connection is required to play video");
        builder.setInverseBackgroundForced(true);
        builder.setPositiveButton("Yes Play Now",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which){
                Tampilreward();


            }
        });

        AlertDialog alert=builder.create();
        alert.show();
    }




    private void LoadReward() {
        switch (SELECT_REWARD) {
            case "ADMOB":
                if (Admobreward == null) {
                    Admobreward.load(this, ADMOB_REWARD,
                            MulaiActivity.request, new RewardedAdLoadCallback() {
                                @Override
                                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                    // Handle the error.
                                    Log.d(TAG, loadAdError.getMessage());
                                    Admobreward = null;
                                }

                                @Override
                                public void onAdLoaded(@NonNull RewardedAd rewardedAd) {
                                    Admobreward = rewardedAd;
                                    TextView versionName = findViewById(R.id.textreward);
                                    versionName.setText("VIDEO IS READY Tap (Play Now)");
                                    versionName.setTextColor(Color.parseColor("#FF4CE3D1"));
                                    Text = findViewById(R.id.TxtReward);
                                    Text.setTextColor(Color.parseColor("#FF4CE3D1"));
                                    Log.d(TAG, "Ad was loaded.");
                                }
                            });
                }
                break;

            case "APPLOVIN":
                MaxReward = MaxRewardedAd.getInstance( APPLOVIN_REWARD, this );
                MaxReward.setListener(SplashPuzzle.this);
                MaxReward.setRevenueListener( SplashPuzzle.this );
                MaxReward.loadAd();

                break;
            case "MOPUB":
                MoPubRewardedAds.loadRewardedAd(REWARD_MOPUB);

                break;
            case "STARTAPP":
                final StartAppAd rewardedVideo = new StartAppAd(this);
                rewardedVideo.loadAd(StartAppAd.AdMode.REWARDED_VIDEO);
                rewardedVideo.setVideoListener(new VideoListener() {
                    @Override
                    public void onVideoCompleted() {
                        Intent intent = new Intent(SplashPuzzle.this, MainActivityPuzzle.class);
                        startActivity(intent);
                    }
                });
                break;


        }
    }
    private void LoadReward2() {
        switch (SELECT_BACKUP_REWARD) {
            case "ADMOB":
                if (Admobreward == null) {
                    Admobreward.load(this, ADMOB_REWARD,
                            MulaiActivity.request, new RewardedAdLoadCallback() {
                                @Override
                                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                    // Handle the error.
                                    Log.d(TAG, loadAdError.getMessage());
                                    Admobreward = null;
                                }

                                @Override
                                public void onAdLoaded(@NonNull RewardedAd rewardedAd) {
                                    Admobreward = rewardedAd;
                                    TextView versionName = findViewById(R.id.textreward);
                                    versionName.setText("VIDEO IS READY Tap (Play Now)");
                                    versionName.setTextColor(Color.parseColor("#FF4CE3D1"));
                                    Text = findViewById(R.id.TxtReward);
                                    Text.setTextColor(Color.parseColor("#FF4CE3D1"));
                                    Log.d(TAG, "Ad was loaded.");
                                }
                            });
                }
                break;

            case "APPLOVIN":
                MaxReward = MaxRewardedAd.getInstance( APPLOVIN_REWARD, this );
                MaxReward.setListener(SplashPuzzle.this );
                MaxReward.setRevenueListener( SplashPuzzle.this );
                MaxReward.loadAd();

                break;
            case "MOPUB":
                MoPubRewardedAds.loadRewardedAd(REWARD_MOPUB);

                break;
            case "STARTAPP":
                final StartAppAd rewardedVideo = new StartAppAd(this);
                rewardedVideo.loadAd(StartAppAd.AdMode.REWARDED_VIDEO);
                rewardedVideo.setVideoListener(new VideoListener() {
                    @Override
                    public void onVideoCompleted() {
                        Intent intent = new Intent(SplashPuzzle.this, MainActivityPuzzle.class);
                        startActivity(intent);
                    }
                });


                break;


        }
    }


    @Override
    public void onAdLoaded(MaxAd ad) {
        TextView versionName = findViewById(R.id.textreward);
        versionName.setText("VIDEO IS READY Tap (Play Now)");
        versionName.setTextColor(Color.parseColor("#FF4CE3D1"));
        Text = findViewById(R.id.TxtReward);
        Text.setTextColor(Color.parseColor("#FF4CE3D1"));
    }

    @Override
    public void onAdDisplayed(MaxAd ad) {

    }

    @Override
    public void onAdHidden(MaxAd ad) {

    }

    @Override
    public void onAdClicked(MaxAd ad) {

    }

    @Override
    public void onAdLoadFailed(String adUnitId, MaxError error) {

    }

    @Override
    public void onAdDisplayFailed(MaxAd ad, MaxError error) {

    }

    @Override
    public void onAdRevenuePaid(MaxAd ad) {

    }

    @Override
    public void onRewardedVideoStarted(MaxAd ad) {

    }

    @Override
    public void onRewardedVideoCompleted(MaxAd ad) {

    }

    @Override
    public void onUserRewarded(MaxAd ad, com.applovin.mediation.MaxReward reward) {
        Intent intent = new Intent(SplashPuzzle.this, MainActivityPuzzle.class);
        startActivity(intent);

    }

    private  void  Tampilreward() {
        switch (SELECT_REWARD) {
            case "ADMOB":
                if (Admobreward != null) {
                    Activity activityContext = SplashPuzzle.this;
                    Admobreward.show(activityContext, new OnUserEarnedRewardListener() {
                        @Override
                        public void onUserEarnedReward(@NonNull RewardItem rewardItem) {
                            Intent intent = new Intent(SplashPuzzle.this, MainActivityPuzzle.class);
                            startActivity(intent);
                        }
                    });
                } else {
                    Backupreward();
                }
                break;
            case "APPLOVIN":

                if ( MaxReward.isReady() )
                {
                    MaxReward.showAd();
                }
                else
                    Backupreward();
                break;

            case "MOPUB":
                MoPubRewardedAds.showRewardedAd(REWARD_MOPUB);
                rewardedAdListener = new MoPubRewardedAdListener() {


                    @Override
                    public void onRewardedAdLoadSuccess(String adUnitId) {
                        TextView versionName = findViewById(R.id.textreward);
                        versionName.setText("VIDEO IS READY Tap (Play Now)");
                        versionName.setTextColor(Color.parseColor("#FF4CE3D1"));
                        Text = findViewById(R.id.TxtReward);
                        Text.setTextColor(Color.parseColor("#FF4CE3D1"));
                        // Called when the ad for the given adUnitId has loaded. At this point you should be able to call MoPubRewardedAds.showRewardedAd() to show the ad.
                    }
                    @Override
                    public void onRewardedAdLoadFailure(String adUnitId, MoPubErrorCode errorCode) {
                        // Called when the ad fails to load for the given adUnitId. The provided error code will provide more insight into the reason for the failure to load.
                    }

                    @Override
                    public void onRewardedAdStarted(String adUnitId) {
                        // Called when a rewarded ad starts playing.
                    }

                    @Override
                    public void onRewardedAdShowError(String adUnitId, MoPubErrorCode errorCode) {
                        Backupreward();
                        //  Called when there is an error while attempting to show the ad.
                    }

                    @Override
                    public void onRewardedAdClicked(@NonNull String adUnitId) {
                        //  Called when a rewarded ad is clicked.
                    }

                    @Override
                    public void onRewardedAdClosed(String adUnitId) {
                        // Called when a rewarded ad is closed. At this point your application should resume.
                    }

                    @Override
                    public void onRewardedAdCompleted(Set<String> adUnitIds, MoPubReward reward) {
                        Intent intent = new Intent(SplashPuzzle.this, MainActivityPuzzle.class);
                        startActivity(intent);
                        // Called when a rewarded ad is completed and the user should be rewarded.
                        // You can query the reward object with boolean isSuccessful(), String getLabel(), and int getAmount().
                    }
                };

                MoPubRewardedAds.setRewardedAdListener(rewardedAdListener);
                break;
            case "STARTAPP":
                rewardedVideo.showAd();
                rewardedVideo.setVideoListener(new VideoListener() {
                    @Override
                    public void onVideoCompleted() {
                        Intent intent = new Intent(SplashPuzzle.this, MainActivityPuzzle.class);
                        startActivity(intent);
                    }
                });
                break;

        }
    }

    private void Backupreward() {
        switch (SELECT_BACKUP_REWARD) {
            case "ADMOB":
                if (Admobreward != null) {
                    Activity activityContext = SplashPuzzle.this;
                    Admobreward.show(activityContext, new OnUserEarnedRewardListener() {
                        @Override
                        public void onUserEarnedReward(@NonNull RewardItem rewardItem) {
                            Intent intent = new Intent(SplashPuzzle.this, MainActivityPuzzle.class);
                            startActivity(intent);
                        }
                    });
                } else {
                    Log.d(TAG, "The rewarded ad wasn't ready yet.");
                }
                break;
            case "APPLOVIN":

                if ( MaxReward.isReady() )
                {
                    MaxReward.showAd();
                }
                break;

            case "MOPUB":
                MoPubRewardedAds.showRewardedAd(REWARD_MOPUB);
                rewardedAdListener = new MoPubRewardedAdListener() {
                    @Override
                    public void onRewardedAdLoadSuccess(String adUnitId) {
                        TextView versionName = findViewById(R.id.textreward);
                        versionName.setText("VIDEO IS READY Tap (Play Now)");
                        versionName.setTextColor(Color.parseColor("#FF4CE3D1"));
                        Text = findViewById(R.id.TxtReward);
                        Text.setTextColor(Color.parseColor("#FF4CE3D1"));
                        // Called when the ad for the given adUnitId has loaded. At this point you should be able to call MoPubRewardedAds.showRewardedAd() to show the ad.
                    }
                    @Override
                    public void onRewardedAdLoadFailure(String adUnitId, MoPubErrorCode errorCode) {
                        // Called when the ad fails to load for the given adUnitId. The provided error code will provide more insight into the reason for the failure to load.
                    }

                    @Override
                    public void onRewardedAdStarted(String adUnitId) {
                        // Called when a rewarded ad starts playing.
                    }

                    @Override
                    public void onRewardedAdShowError(String adUnitId, MoPubErrorCode errorCode) {
                        //  Called when there is an error while attempting to show the ad.
                    }

                    @Override
                    public void onRewardedAdClicked(@NonNull String adUnitId) {
                        //  Called when a rewarded ad is clicked.
                    }

                    @Override
                    public void onRewardedAdClosed(String adUnitId) {
                        // Called when a rewarded ad is closed. At this point your application should resume.
                    }

                    @Override
                    public void onRewardedAdCompleted(Set<String> adUnitIds, MoPubReward reward) {
                        Intent intent = new Intent(SplashPuzzle.this, MainActivityPuzzle.class);
                        startActivity(intent);
                        // Called when a rewarded ad is completed and the user should be rewarded.
                        // You can query the reward object with boolean isSuccessful(), String getLabel(), and int getAmount().
                    }
                };

                MoPubRewardedAds.setRewardedAdListener(rewardedAdListener);
                break;
            case "STARTAPP":
                rewardedVideo.showAd();
                break;

        }
    }


    private NativeAd nativeAd;
    private void nativeadmob() {
        refreshAd();
    }

    private void populateNativeAdView(NativeAd nativeAd, NativeAdView adView) {
        adView.setMediaView((MediaView) adView.findViewById(R.id.ad_media));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));
        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        adView.getMediaView().setMediaContent(nativeAd.getMediaContent());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getPrice() == null) {
            adView.getPriceView().setVisibility(View.INVISIBLE);
        } else {
            adView.getPriceView().setVisibility(View.VISIBLE);
            ((TextView) adView.getPriceView()).setText(nativeAd.getPrice());
        }

        if (nativeAd.getStore() == null) {
            adView.getStoreView().setVisibility(View.INVISIBLE);
        } else {
            adView.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) adView.getStoreView()).setText(nativeAd.getStore());
        }

        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.INVISIBLE);
        } else {
            ((TextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.VISIBLE);
        }
        adView.setNativeAd(nativeAd);
    }

    private void refreshAd() {

        AdLoader.Builder builder = new AdLoader.Builder(this, ADMOB_NATIVE_BANNER);

        builder.forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {
            @Override
            public void onNativeAdLoaded(@NonNull com.google.android.gms.ads.nativead.NativeAd nativeAds) {

                if (nativeAd != null) {
                    nativeAd.destroy();
                }

                nativeAd = nativeAds;
                FrameLayout frameLayout =
                        findViewById(R.id.fl_adplaceholder);
                NativeAdView adView = (NativeAdView) getLayoutInflater()
                        .inflate(R.layout.admob_kecil, null);
                populateNativeAdView(nativeAds, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });

        VideoOptions videoOptions = new VideoOptions.Builder()
                .build();

        com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader =
                builder
                        .withAdListener(
                                new AdListener() {
                                    @Override
                                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                                        if (BACKUP_MODE.equals("YES")){

                                            switch (SELECT_BACKUP_ADS) {
                                                case "STARTAPP":
                                                    Banner3D startAppBanner = new Banner3D(SplashPuzzle.this);
                                                    RelativeLayout.LayoutParams bannerParameters =
                                                            new RelativeLayout.LayoutParams(
                                                                    RelativeLayout.LayoutParams.WRAP_CONTENT,
                                                                    RelativeLayout.LayoutParams.WRAP_CONTENT);
                                                    bannerParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);
                                                    mainLayout.addView(startAppBanner, bannerParameters);
                                                    startAppAd.loadAd (new AdEventListener() {
                                                        @Override
                                                        public void onReceiveAd(com.startapp.sdk.adsbase.Ad ad) {

                                                        }

                                                        @Override
                                                        public void onFailedToReceiveAd(Ad ad) {
                                                        }
                                                    });
                                                    break;
                                                case "APPLOVIN":
                                                    MaxAdView adView;
                                                    adView = new MaxAdView(APPLOVIN_BANNER, (Activity) SplashPuzzle.this);
                                                    //AppLovinAdView adView = new AppLovinAdView(AppLovinAdSize.BANNER, context);
                                                    final boolean isTablet = AppLovinSdkUtils.isTablet(SplashPuzzle.this);
                                                    final int heightPx = AppLovinSdkUtils.dpToPx(SplashPuzzle.this, isTablet ? 90 : 50);
                                                    adView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, heightPx));
                                                    mainLayout.addView(adView);
                                                    adView.loadAd();
                                                    break;
                                                case "MOPUB":
                                                    MoPubView moPubView;
                                                    moPubView = new MoPubView(SplashPuzzle.this);
                                                    moPubView.setAdUnitId(BANNER_MOPUB);
                                                    mainLayout.addView(moPubView);
                                                    moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_50);
                                                    moPubView.setBannerAdListener((MoPubView.BannerAdListener) SplashPuzzle.this);
                                                    // Sent when the banner has failed to retrieve an ad. You can use the MoPubErrorCode value to diagnose the cause of failure.
                                                    break;
                                            }
                                        }
                                    }
                                })
                        .build();
        adLoader.loadAd(MulaiActivity.request);

    }








    private void loadBanner() {
        AdSize adSize = getAdSize();
        adView.setAdSize(adSize);
        adView.loadAd(MulaiActivity.request);
        adView.setAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                if (BACKUP_MODE.equals("YES")){

                    switch (SELECT_BACKUP_ADS) {
                        case "STARTAPP":
                            Banner3D startAppBanner = new Banner3D(SplashPuzzle.this);
                            RelativeLayout.LayoutParams bannerParameters =
                                    new RelativeLayout.LayoutParams(
                                            RelativeLayout.LayoutParams.WRAP_CONTENT,
                                            RelativeLayout.LayoutParams.WRAP_CONTENT);
                            bannerParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);
                            mainLayout.addView(startAppBanner, bannerParameters);
                            startAppAd.loadAd (new AdEventListener() {
                                @Override
                                public void onReceiveAd(Ad ad) {

                                }

                                @Override
                                public void onFailedToReceiveAd(Ad ad) {
                                }
                            });
                            break;
                        case "APPLOVIN":
                            MaxAdView adView;
                            adView = new MaxAdView(APPLOVIN_BANNER, SplashPuzzle.this);
                            //AppLovinAdView adView = new AppLovinAdView(AppLovinAdSize.BANNER, context);
                            final boolean isTablet = AppLovinSdkUtils.isTablet(SplashPuzzle.this);
                            final int heightPx = AppLovinSdkUtils.dpToPx(SplashPuzzle.this, isTablet ? 90 : 50);
                            adView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, heightPx));
                            mainLayout.addView(adView);
                            adView.loadAd();
                            break;
                        case "MOPUB":
                            Map<String, String> facebookBanner = new HashMap<>();
                            facebookBanner.put("native_banner", "true");
                            SdkConfiguration.Builder configBuilder = new SdkConfiguration.Builder(BANNER_MOPUB);
                            configBuilder.withMediatedNetworkConfiguration(FacebookBanner.class.getName(), facebookBanner);
                            MoPubView moPubView;
                            moPubView = new MoPubView(SplashPuzzle.this);
                            moPubView.setAdUnitId(BANNER_MOPUB);
                            mainLayout.addView(moPubView);
                            moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_50);
                            moPubView.loadAd();
                            // Sent when the banner has failed to retrieve an ad. You can use the MoPubErrorCode value to diagnose the cause of failure.
                            break;
                    }
                }
            }
        });


    }
    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

}
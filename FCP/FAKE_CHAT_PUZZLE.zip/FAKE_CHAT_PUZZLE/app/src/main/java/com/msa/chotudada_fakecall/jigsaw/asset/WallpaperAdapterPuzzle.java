package com.msa.chotudada_fakecall.jigsaw.asset;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.applovin.adview.AppLovinInterstitialAd;
import com.applovin.adview.AppLovinInterstitialAdDialog;
import com.applovin.sdk.AppLovinAd;
import com.applovin.sdk.AppLovinAdLoadListener;
import com.applovin.sdk.AppLovinAdSize;
import com.applovin.sdk.AppLovinSdk;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.msa.chotudada_fakecall.R;
import com.msa.chotudada_fakecall.activity.MulaiActivity;
import com.msa.chotudada_fakecall.activity.WAVideoCallActivity;
import com.msa.chotudada_fakecall.jigsaw.ui.MainActivityPuzzle;
import com.msa.chotudada_fakecall.jigsaw.ui.PuzzleActivity;
import com.squareup.picasso.Picasso;
import com.startapp.sdk.adsbase.StartAppAd;

import java.util.ArrayList;

import static android.content.ContentValues.TAG;
import static com.msa.chotudada_fakecall.config.Settings.ADMOB_INTER;
import static com.msa.chotudada_fakecall.config.Settings.BACKUP_MODE;
import static com.msa.chotudada_fakecall.config.Settings.COUNTER;
import static com.msa.chotudada_fakecall.config.Settings.INTERVAL;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_BACKUP_ADS;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_INTER;


public class WallpaperAdapterPuzzle extends RecyclerView.Adapter {
    private InterstitialAd mInterstitialAd;
    public static AppLovinInterstitialAdDialog interstitialAdlovin;
    public static AppLovinAd loadedAd;
    private final int VIEW_ITEM = 0;
    public static ArrayList<WallpaperPuzzle> webLists;
    public Context context;
    public static Intent intent;
    public StartAppAd startAppAd = new StartAppAd(context);

    public WallpaperAdapterPuzzle(ArrayList<WallpaperPuzzle> webLists, Context context) {
        this.webLists = webLists;
        this.context = context;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView html_url;
        public ImageView avatar_url;
        public RelativeLayout linearLayout;
        public Button favoriteImg;

        public ViewHolder(View itemView) {
            super(itemView);
            html_url = (TextView) itemView.findViewById(R.id.username);
            avatar_url = (ImageView) itemView.findViewById(R.id.imageView);
            linearLayout = (RelativeLayout) itemView.findViewById(R.id.linearLayout);

            switch (SELECT_INTER) {
                case "ADMOB":
                    if (MulaiActivity.mInterstitialAd == null) {
                        InterstitialAd.load(context, ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                            @Override
                            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                                MulaiActivity.mInterstitialAd = interstitialAd;
                                Log.i(TAG, "onAdLoaded");
                            }

                            @Override
                            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                MulaiActivity.mInterstitialAd = null;
                            }
                        });
                    }
                    break;

                case "MOPUB":
                    MulaiActivity.mInterstitial.load();
                    break;
                case "STARTAPP":
                    startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                    break;

            }
        }

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_ITEM) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.list_puzzle, parent, false);
            return new ViewHolder(v);

        } else {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_progressbar, parent, false);
            return new ProgressViewHolder(v);
        }

    }

    private static class ProgressViewHolder extends RecyclerView.ViewHolder {
        private static ProgressBar progressBar;

        private ProgressViewHolder(View v) {
            super(v);
            progressBar = v.findViewById(R.id.progressBar);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, final int position) {
        if (holder instanceof ViewHolder) {
            final WallpaperPuzzle webList = webLists.get(position);
            ((ViewHolder) holder).html_url.setText(webList.getHtml_url());

            Picasso.get()
                    .load(webList.getAvatar_url())
                    .into(((ViewHolder) holder).avatar_url);

            ((ViewHolder) holder).linearLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    MainActivityPuzzle.mp.start();
                    intent = new Intent(context, PuzzleActivity.class);
                    intent.putExtra("assetName", webList.getAvatar_url());
                    context.startActivity(intent);

                    if (COUNTER > INTERVAL) {
                        munculinterbaru();
                        COUNTER = 0;
                    } else {
                        COUNTER++;
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return webLists.size();
    }


    private void munculinterbaru() {
        switch (SELECT_INTER) {
            case "ADMOB":

                if (MulaiActivity.mInterstitialAd != null) {
                    MulaiActivity.mInterstitialAd.show((Activity) (context));
                    InterstitialAd.load(context, ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            MulaiActivity.mInterstitialAd = interstitialAd;
                            Log.i(TAG, "onAdLoaded");
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            MulaiActivity.mInterstitialAd = null;
                        }
                    });
                } else {
                    InterstitialAd.load(context, ADMOB_INTER, MulaiActivity.request, new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            MulaiActivity.mInterstitialAd = interstitialAd;
                            Log.i(TAG, "onAdLoaded");
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            MulaiActivity.mInterstitialAd = null;
                        }
                    });

                    if (BACKUP_MODE.equals("YES")) {
                        switch (SELECT_BACKUP_ADS) {
                            case "STARTAPP":
                                startAppAd.showAd(context);
                                startAppAd.loadAd(StartAppAd.AdMode.VIDEO);

                                break;
                            case "APPLOVIN":
                                if (MulaiActivity.interstitialAd.isReady()) {
                                    MulaiActivity.interstitialAd.showAd();
                                } else {
                                    MulaiActivity.interstitialAd.loadAd();
                                }
                                break;
                            case "MOPUB":
                                if (MulaiActivity.mInterstitial.isReady()) {
                                    MulaiActivity.mInterstitial.show();
                                    MulaiActivity.mInterstitial.load();
                                } else {
                                    MulaiActivity.mInterstitial.load();
                                }
                                break;
                        }
                    }

                }
                    break;
                    case "APPLOVIN":
                        if (MulaiActivity.interstitialAd.isReady()) {
                            MulaiActivity.interstitialAd.showAd();
                        } else {
                            MulaiActivity.interstitialAd.loadAd();
                        }
                        break;
                    case "STARTAPP":
                        StartAppAd.showAd(context);
                        startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                        break;
                    case "MOPUB":
                        if (MulaiActivity.mInterstitial.isReady()) {
                            MulaiActivity.mInterstitial.show();
                            MulaiActivity.mInterstitial.load();
                        } else {
                            MulaiActivity.mInterstitial.load();
                        }
                        break;

                }
        }
    }

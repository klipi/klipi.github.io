package com.msa.chotudada_fakecall.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Layout;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.applovin.mediation.ads.MaxAdView;
import com.applovin.mediation.ads.MaxInterstitialAd;
import com.applovin.sdk.AppLovinMediationProvider;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkUtils;
import com.facebook.ads.AdSettings;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.initialization.AdapterStatus;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.mopub.common.MoPub;
import com.mopub.common.SdkConfiguration;
import com.mopub.common.SdkInitializationListener;
import com.mopub.mobileads.FacebookBanner;
import com.mopub.mobileads.MoPubInterstitial;
import com.mopub.mobileads.MoPubView;
import com.msa.chotudada_fakecall.BuildConfig;
import com.msa.chotudada_fakecall.R;
import com.msa.chotudada_fakecall.config.Settings;
import com.msa.chotudada_fakecall.jigsaw.ui.MainActivityPuzzle;
import com.msa.chotudada_fakecall.jigsaw.ui.SplashPuzzle;
import com.msa.chotudada_fakecall.model.Wallpaper;
import com.google.ads.mediation.facebook.FacebookAdapter;
import com.google.ads.mediation.facebook.FacebookExtras;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.InstallState;
import com.google.android.play.core.install.InstallStateUpdatedListener;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.InstallStatus;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.google.android.play.core.tasks.OnCompleteListener;
import com.google.android.play.core.tasks.OnFailureListener;
import com.google.android.play.core.tasks.OnSuccessListener;
import com.google.android.play.core.tasks.Task;
import com.google.android.ump.ConsentForm;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.FormError;
import com.google.android.ump.UserMessagingPlatform;
import com.startapp.sdk.ads.banner.banner3d.Banner3D;
import com.startapp.sdk.adsbase.Ad;
import com.startapp.sdk.adsbase.SDKAdPreferences;
import com.startapp.sdk.adsbase.StartAppAd;
import com.startapp.sdk.adsbase.StartAppSDK;
import com.startapp.sdk.adsbase.adlisteners.AdEventListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.msa.chotudada_fakecall.config.Settings.ADMOB_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.ADMOB_INTER;
import static com.msa.chotudada_fakecall.config.Settings.ADMOB_NATIVE_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.AGE1;
import static com.msa.chotudada_fakecall.config.Settings.AGE2;
import static com.msa.chotudada_fakecall.config.Settings.APPLOVIN_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.APPLOVIN_INTER;
import static com.msa.chotudada_fakecall.config.Settings.BACKUP_MODE;
import static com.msa.chotudada_fakecall.config.Settings.BANNER_MOPUB;
import static com.msa.chotudada_fakecall.config.Settings.FAN_INTER;
import static com.msa.chotudada_fakecall.config.Settings.INITIAL_ADMOB;
import static com.msa.chotudada_fakecall.config.Settings.INITIAL_APPLOVIN;
import static com.msa.chotudada_fakecall.config.Settings.INITIAL_MOPUB;
import static com.msa.chotudada_fakecall.config.Settings.INITIAL_STARTAPP;
import static com.msa.chotudada_fakecall.config.Settings.INTER_MOPUB;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_BACKUP_ADS;
import static com.msa.chotudada_fakecall.config.Settings.FAN_BANNER_NATIVE;
import static com.msa.chotudada_fakecall.config.Settings.LINK_REDIRECT;
import static com.msa.chotudada_fakecall.config.Settings.ON_OFF_DATA;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_INTER;
import static com.msa.chotudada_fakecall.config.Settings.STARTAPPID;
import static com.msa.chotudada_fakecall.config.Settings.STATUS_APP;
import static com.google.android.play.core.install.model.AppUpdateType.FLEXIBLE;


public class MulaiActivity extends AppCompatActivity {
    ReviewInfo reviewInfo;
    ReviewManager manager;
    private static final int MY_REQUEST_CODE = 17326;
    private ConsentInformation consentInformation;
    private ConsentForm consentForm;
    private RelativeLayout layAds;
    public StartAppAd startAppAd = new StartAppAd(MulaiActivity.this);
    public static Activity fa;
    public static InterstitialAd mInterstitialAd;
    public static AdRequest adRequest ;
    public static ArrayList<Wallpaper> webLists;
    LinearLayout linearLayout;

    public static com.facebook.ads.InterstitialAd interstitialAdfb;
    public static MaxInterstitialAd interstitialAd;
    public static MoPubInterstitial mInterstitial;

    protected static final String TAG = MulaiActivity.class.getSimpleName();
    public static Bundle extras;
    public static AdRequest request;
    private AdView admobadview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mulai);
        {
            fa = this;
        }
        final ProgressDialog progressDialog = new ProgressDialog(MulaiActivity.this);
        progressDialog.setMessage("Loading Data");
        progressDialog.setCancelable(true);
        progressDialog.show();
        new CountDownTimer(3000, 1000) {
            @Override
            public void onFinish() {
                progressDialog.dismiss();
            }

            @Override
            public void onTick(long millisUntilFinished) {

            }
        }.start();

        webLists = new ArrayList<>();
        Review();
        if (STATUS_APP.equals("1")) {
            String str = LINK_REDIRECT;
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse(str)));
            finish();
        }
        if (ON_OFF_DATA.equals("0")){
            ambildatawall();
        }

        /*
        inisial
         */
        if (INITIAL_ADMOB.equals("YES")) {
            ConsentRequestParameters params = new ConsentRequestParameters.Builder().build();
            consentInformation = UserMessagingPlatform.getConsentInformation(this);
            consentInformation.requestConsentInfoUpdate(
                    this,
                    params,
                    new ConsentInformation.OnConsentInfoUpdateSuccessListener() {
                        @Override
                        public void onConsentInfoUpdateSuccess() {
                            if (consentInformation.isConsentFormAvailable()) {
                                loadForm();
                            }
                        }
                    },
                    new ConsentInformation.OnConsentInfoUpdateFailureListener() {
                        @Override
                        public void onConsentInfoUpdateFailure(FormError formError) {
                            // Handle the error.
                        }
                    });
            extras = new FacebookExtras()
                    .setNativeBanner(true)
                    .build();
            request = new AdRequest.Builder()
                    .addNetworkExtrasBundle(FacebookAdapter.class, extras)
                    .addKeyword("google adwords promo")
                    .addKeyword("google server hosting")
                    .build();
            MobileAds.initialize(this, new OnInitializationCompleteListener() {
                @Override
                public void onInitializationComplete(InitializationStatus initializationStatus) {
                    Map<String, AdapterStatus> statusMap = initializationStatus.getAdapterStatusMap();
                    for (String adapterClass : statusMap.keySet()) {
                        AdapterStatus status = statusMap.get(adapterClass);
                        Log.d("MyApp", String.format(
                                "Adapter name: %s, Description: %s, Latency: %d",
                                adapterClass, status.getDescription(), status.getLatency()));
                    }
                }
            });

        }

        if (INITIAL_APPLOVIN.equals("YES")) {
            AdSettings.setDataProcessingOptions(new String[]{});
            AppLovinSdk.getInstance(MulaiActivity.this).setMediationProvider(AppLovinMediationProvider.MAX);
            AppLovinSdk sdk = AppLovinSdk.getInstance(MulaiActivity.this);
            sdk.getSettings().setMuted(!sdk.getSettings().isMuted());
        }
        if (INITIAL_MOPUB.equals("YES")) {
            Map<String, String> facebookBanner = new HashMap<>();
            facebookBanner.put("banner", "true");
            SdkConfiguration.Builder configBuilder = new SdkConfiguration.Builder(BANNER_MOPUB);
            configBuilder.withMediatedNetworkConfiguration(FacebookBanner.class.getName(), facebookBanner);
            MoPub.initializeSdk(this, configBuilder.build(), initSdkListener());

        }
        if (INITIAL_STARTAPP.equals("YES")) {
            StartAppSDK.init(this, STARTAPPID, false);
            new SDKAdPreferences()
                    .setAge(AGE1)
                    .setAge(AGE2)
                    .setGender(SDKAdPreferences.Gender.FEMALE);
            StartAppAd.disableSplash();
        }


        //LOAD//
        layAds = (RelativeLayout) findViewById(R.id.layAds);
        switch (SELECT_BANNER) {
            case "ADMOB":
                ConsentRequestParameters params = new ConsentRequestParameters.Builder().build();
                consentInformation = UserMessagingPlatform.getConsentInformation(this);
                consentInformation.requestConsentInfoUpdate(
                        this,
                        params,
                        new ConsentInformation.OnConsentInfoUpdateSuccessListener() {
                            @Override
                            public void onConsentInfoUpdateSuccess() {
                                if (consentInformation.isConsentFormAvailable()) {
                                    loadForm();
                                }
                            }
                        },
                        new ConsentInformation.OnConsentInfoUpdateFailureListener() {
                            @Override
                            public void onConsentInfoUpdateFailure(FormError formError) {
                                // Handle the error.
                            }
                        });


                extras = new FacebookExtras()
                        .setNativeBanner(true)
                        .build();
                request = new AdRequest.Builder()
                        .addNetworkExtrasBundle(FacebookAdapter.class, extras)
                        .build();
                MobileAds.initialize(this, new OnInitializationCompleteListener() {
                    @Override
                    public void onInitializationComplete(InitializationStatus initializationStatus) {
                        Map<String, AdapterStatus> statusMap = initializationStatus.getAdapterStatusMap();
                        for (String adapterClass : statusMap.keySet()) {
                            AdapterStatus status = statusMap.get(adapterClass);
                            Log.d("MyApp", String.format(
                                    "Adapter name: %s, Description: %s, Latency: %d",
                                    adapterClass, status.getDescription(), status.getLatency()));
                        }
                    }
                });

                if (Settings.BANNER_APA_NATIVE.equals("NATIVE")){
                    nativeadmob();
                } else {
                    admobadview = new AdView(this);
                    admobadview.setAdUnitId(ADMOB_BANNER);
                    layAds.addView(admobadview);
                    loadBanner();
                }
                break;
            case "APPLOVIN":
                MaxAdView adView;
                adView = new MaxAdView(APPLOVIN_BANNER, (Activity) MulaiActivity.this);
                //AppLovinAdView adView = new AppLovinAdView(AppLovinAdSize.BANNER, context);
                final boolean isTablet = AppLovinSdkUtils.isTablet(MulaiActivity.this);
                final int heightPx = AppLovinSdkUtils.dpToPx(MulaiActivity.this, isTablet ? 90 : 50);
                adView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, heightPx));
                layAds.addView(adView);
                adView.loadAd();
                break;
            case "STARTAPP":
                Banner3D startAppBanner = new Banner3D(MulaiActivity.this);
                RelativeLayout.LayoutParams bannerParameters =
                        new RelativeLayout.LayoutParams(
                                RelativeLayout.LayoutParams.WRAP_CONTENT,
                                RelativeLayout.LayoutParams.WRAP_CONTENT);
                bannerParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);
                layAds.addView(startAppBanner, bannerParameters);
                break;
            case "MOPUB":
                MoPubView moPubView;
                moPubView = new MoPubView(this);
                moPubView.setAdUnitId(BANNER_MOPUB);
                layAds.addView(moPubView);
                moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_50);
                moPubView.loadAd();
                break;
            default:

        }

        switch (SELECT_INTER) {
            case "ADMOB":
                InterstitialAd.load(MulaiActivity.this, ADMOB_INTER, request, new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAd = interstitialAd;
                        Log.i(TAG, "onAdLoaded");
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        if (BACKUP_MODE.equals("YES")) {
                            switch (SELECT_BACKUP_ADS) {
                                case "APPLOVIN":
                                    interstitialAd = new MaxInterstitialAd(APPLOVIN_INTER, MulaiActivity.this);
                                    interstitialAd.loadAd();
                                    break;
                                case "MOPUB":
                                    mInterstitial = new MoPubInterstitial((Activity) MulaiActivity.this, INTER_MOPUB);
                                    mInterstitial.load();
                                    break;
                                case "STARTAPP":
                                    startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                                    break;
                            }

                        }
                        mInterstitialAd = null;
                    }
                });
                break;
            case "APPLOVIN":
                interstitialAd = new MaxInterstitialAd(APPLOVIN_INTER, MulaiActivity.this);
                interstitialAd.loadAd();
                break;
            case "MOPUB":
                mInterstitial = new MoPubInterstitial((Activity) MulaiActivity.this, INTER_MOPUB);
                mInterstitial.load();
                break;

            case "STARTAPP":
                startAppAd.loadAd(StartAppAd.AdMode.VIDEO);
                startAppAd.loadAd();


                break;


        }




        Button bt_chat = (Button) findViewById(R.id.chatnow);
        bt_chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MulaiActivity.this, MenuActivity.class);
                startActivity(intent);



            }
        });

        Button imgvideo = (Button) findViewById(R.id.videocall);
        imgvideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MulaiActivity.this, MainActivity.class);
                startActivity(intent);

            }
        });
        Button imgvoice = (Button) findViewById(R.id.voice);
        imgvoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MulaiActivity.this, SplashPuzzle.class);
                startActivity(intent);

            }
        });

        Button imgPrivacy = (Button) findViewById(R.id.pripasi);
        imgPrivacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MulaiActivity.this, PrivacyActivity.class);
                startActivity(intent);

            }
        });






    }




    private SdkInitializationListener initSdkListener() {
        return new SdkInitializationListener() {
            @Override
            public void onInitializationFinished() {
            }
        };
    }



    public void ambildatawall(){
        try {
            JSONObject jsonObject = new JSONObject(loadJSONFromAsset());
            JSONArray jsonArray = jsonObject.getJSONArray("Wallpaper");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonData = jsonArray.getJSONObject(i);
                Wallpaper developers = new Wallpaper(jsonData.getInt("id")
                        , jsonData.getString("title"),
                        jsonData.getString("image"));
                webLists.add(developers);


            }
        } catch (JSONException e) {
            Toast.makeText(MulaiActivity.this, e.toString(), Toast.LENGTH_LONG).show();
        }
    }

    public String loadJSONFromAsset() {
        String json = null;
        try {

            InputStream is = MulaiActivity.this.getAssets().open("fake_call.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");


        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;

    }

    public void loadForm(){
        UserMessagingPlatform.loadConsentForm(
                MulaiActivity.this,
                new UserMessagingPlatform.OnConsentFormLoadSuccessListener() {
                    @Override
                    public void onConsentFormLoadSuccess(ConsentForm consentForm) {
                        MulaiActivity.this.consentForm = consentForm;
                        if(consentInformation.getConsentStatus() == ConsentInformation.ConsentStatus.REQUIRED) {
                            consentForm.show(
                                    MulaiActivity.this,
                                    new ConsentForm.OnConsentFormDismissedListener() {
                                        @Override
                                        public void onConsentFormDismissed(@Nullable FormError formError) {
                                            // Handle dismissal by reloading form.
                                            loadForm();
                                        }
                                    });

                        }

                    }
                },
                new UserMessagingPlatform.OnConsentFormLoadFailureListener() {
                    @Override
                    public void onConsentFormLoadFailure(FormError formError) {
                        /// Handle Error.
                    }
                }
        );
    }

    private void exitapp() {
        AlertDialog.Builder builder=new AlertDialog.Builder(MulaiActivity.this);
        builder.setCancelable(true);
        builder.setIcon(R.drawable.ic_baseline_cancel_24);
        builder.setTitle("Exit App");
        builder.setMessage("Are you sure you want to leave the application?");
        builder.setInverseBackgroundForced(true);
        builder.setPositiveButton("Yes",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which){
                finish();

            }
        });

        builder.setNegativeButton("No",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which){
                dialog.dismiss();
            }
        });
        AlertDialog alert=builder.create();
        alert.show();
    }

    @Override
    public void onBackPressed()
    {
        exitapp();
    }




     /*
    In app review
     */

    private void Review(){
        manager = ReviewManagerFactory.create(this);
        manager.requestReviewFlow().addOnCompleteListener(new OnCompleteListener<ReviewInfo>() {
            @Override
            public void onComplete(@NonNull Task<ReviewInfo> task) {
                if(task.isSuccessful()){
                    reviewInfo = task.getResult();
                    manager.launchReviewFlow(MulaiActivity.this, reviewInfo).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(Exception e) {
                            //Toast.makeText(MainActivity.this, "Rating Failed", Toast.LENGTH_SHORT).show();
                        }
                    }).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            // Toast.makeText(MainActivity.this, "Review Completed, Thank You!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(Exception e) {
                Toast.makeText(MulaiActivity.this, "In-App Request Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /*
       In App Update
        */
    AppUpdateManager appUpdateManager;
    Task<AppUpdateInfo> appUpdateInfoTask;
    private void checkUpdate(){
        appUpdateManager = AppUpdateManagerFactory.create(this);
        appUpdateManager.registerListener(listener);

        appUpdateInfoTask = appUpdateManager.getAppUpdateInfo();
        appUpdateInfoTask.addOnSuccessListener(new OnSuccessListener<AppUpdateInfo>() {
            @SuppressLint("WrongConstant")
            @Override
            public void onSuccess(AppUpdateInfo appUpdateInfo) {
                Log.d("appUpdateInfo :", "packageName :"+appUpdateInfo.packageName()+ ", "+ "availableVersionCode :"+ appUpdateInfo.availableVersionCode() +", "+"updateAvailability :"+ appUpdateInfo.updateAvailability() +", "+ "installStatus :" + appUpdateInfo.installStatus() );

                if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                        && appUpdateInfo.isUpdateTypeAllowed(FLEXIBLE)){
                    requestUpdate(appUpdateInfo);
                    Log.d("UpdateAvailable","update is there ");
                }
                else if (appUpdateInfo.updateAvailability() == 3){
                    Log.d("Update","3");
                    notifyUser();
                }
                else
                {
                    Toast.makeText(MulaiActivity.this, "No Update Available", Toast.LENGTH_SHORT).show();
                    Log.d("NoUpdateAvailable","update is not there ");
                }
            }
        });
    }
    private void requestUpdate(AppUpdateInfo appUpdateInfo){
        try {
            appUpdateManager.startUpdateFlowForResult(appUpdateInfo, AppUpdateType.FLEXIBLE, MulaiActivity.this,MY_REQUEST_CODE);
            resume();
        } catch (IntentSender.SendIntentException e) {
            e.printStackTrace();
        }
    }

    InstallStateUpdatedListener listener = new InstallStateUpdatedListener() {
        @Override
        public void onStateUpdate(InstallState installState) {
            if (installState.installStatus() == InstallStatus.DOWNLOADED){
                Log.d("InstallDownloded","InstallStatus sucsses");
                notifyUser();
            }
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void notifyUser() {
        Snackbar snackbar =
                Snackbar.make(findViewById(R.id.frame_container),
                        "An update has just been downloaded.",
                        Snackbar.LENGTH_INDEFINITE);
        snackbar.setAction("RESTART", new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                appUpdateManager.completeUpdate();
            }
        });
        snackbar.setActionTextColor(
                getResources().getColor(R.color.browser_actions_bg_grey));
        snackbar.show();
    }

    private void resume(){
        appUpdateManager.getAppUpdateInfo().addOnSuccessListener(new OnSuccessListener<AppUpdateInfo>() {
            @Override
            public void onSuccess(AppUpdateInfo appUpdateInfo) {
                if (appUpdateInfo.installStatus() == InstallStatus.DOWNLOADED){
                    notifyUser();
                }

            }
        });
    }




    private NativeAd nativeAd;
    private void nativeadmob() {
        refreshAd();
    }

    private void populateNativeAdView(NativeAd nativeAd, NativeAdView adView) {
        adView.setMediaView((MediaView) adView.findViewById(R.id.ad_media));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));
        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        adView.getMediaView().setMediaContent(nativeAd.getMediaContent());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getPrice() == null) {
            adView.getPriceView().setVisibility(View.INVISIBLE);
        } else {
            adView.getPriceView().setVisibility(View.VISIBLE);
            ((TextView) adView.getPriceView()).setText(nativeAd.getPrice());
        }

        if (nativeAd.getStore() == null) {
            adView.getStoreView().setVisibility(View.INVISIBLE);
        } else {
            adView.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) adView.getStoreView()).setText(nativeAd.getStore());
        }

        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.INVISIBLE);
        } else {
            ((TextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.VISIBLE);
        }
        adView.setNativeAd(nativeAd);
    }

    private void refreshAd() {

        AdLoader.Builder builder = new AdLoader.Builder(this, ADMOB_NATIVE_BANNER);

        builder.forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {
            @Override
            public void onNativeAdLoaded(@NonNull com.google.android.gms.ads.nativead.NativeAd nativeAds) {

                if (nativeAd != null) {
                    nativeAd.destroy();
                }

                nativeAd = nativeAds;
                FrameLayout frameLayout =
                        findViewById(R.id.fl_adplaceholder);
                NativeAdView adView = (NativeAdView) getLayoutInflater()
                        .inflate(R.layout.admob_native, null);
                populateNativeAdView(nativeAds, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });

        VideoOptions videoOptions = new VideoOptions.Builder()
                .build();

        com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader =
                builder
                        .withAdListener(
                                new AdListener() {
                                    @Override
                                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                                        if (BACKUP_MODE.equals("YES")){

                                            switch (SELECT_BACKUP_ADS) {
                                                case "STARTAPP":
                                                    Banner3D startAppBanner = new Banner3D(MulaiActivity.this);
                                                    RelativeLayout.LayoutParams bannerParameters =
                                                            new RelativeLayout.LayoutParams(
                                                                    RelativeLayout.LayoutParams.WRAP_CONTENT,
                                                                    RelativeLayout.LayoutParams.WRAP_CONTENT);
                                                    bannerParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);
                                                    layAds.addView(startAppBanner, bannerParameters);
                                                    startAppAd.loadAd (new AdEventListener() {
                                                        @Override
                                                        public void onReceiveAd(Ad ad) {

                                                        }

                                                        @Override
                                                        public void onFailedToReceiveAd(Ad ad) {
                                                        }
                                                    });
                                                    break;
                                                case "APPLOVIN":
                                                    MaxAdView adView;
                                                    adView = new MaxAdView(APPLOVIN_BANNER, (Activity) MulaiActivity.this);
                                                    //AppLovinAdView adView = new AppLovinAdView(AppLovinAdSize.BANNER, context);
                                                    final boolean isTablet = AppLovinSdkUtils.isTablet(MulaiActivity.this);
                                                    final int heightPx = AppLovinSdkUtils.dpToPx(MulaiActivity.this, isTablet ? 90 : 50);
                                                    adView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, heightPx));
                                                    layAds.addView(adView);
                                                    adView.loadAd();
                                                    break;
                                                case "MOPUB":
                                                    Map<String, String> facebookBanner = new HashMap<>();
                                                    facebookBanner.put("native_banner", "true");
                                                    SdkConfiguration.Builder configBuilder = new SdkConfiguration.Builder(BANNER_MOPUB);
                                                    configBuilder.withMediatedNetworkConfiguration(FacebookBanner.class.getName(), facebookBanner);
                                                    MoPubView moPubView;
                                                    moPubView = new MoPubView(MulaiActivity.this);
                                                    moPubView.setAdUnitId(BANNER_MOPUB);
                                                    layAds.addView(moPubView);
                                                    moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_50);
                                                    moPubView.loadAd();
                                                    // Sent when the banner has failed to retrieve an ad. You can use the MoPubErrorCode value to diagnose the cause of failure.
                                                    break;
                                            }
                                        }
                                    }
                                })
                        .build();
        adLoader.loadAd(request);

    }







    private void loadBanner() {
        AdSize adSize = getAdSize();
        admobadview.setAdSize(adSize);
        admobadview.loadAd(request);
        admobadview.setAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                if (BACKUP_MODE.equals("YES")){

                    switch (SELECT_BACKUP_ADS) {
                        case "STARTAPP":
                            Banner3D startAppBanner = new Banner3D(MulaiActivity.this);
                            RelativeLayout.LayoutParams bannerParameters =
                                    new RelativeLayout.LayoutParams(
                                            RelativeLayout.LayoutParams.WRAP_CONTENT,
                                            RelativeLayout.LayoutParams.WRAP_CONTENT);
                            bannerParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);
                            layAds.addView(startAppBanner, bannerParameters);
                            startAppAd.loadAd (new AdEventListener() {
                                @Override
                                public void onReceiveAd(Ad ad) {

                                }

                                @Override
                                public void onFailedToReceiveAd(Ad ad) {
                                }
                            });
                            break;
                        case "APPLOVIN":
                            MaxAdView adView;
                            adView = new MaxAdView(APPLOVIN_BANNER, (Activity) MulaiActivity.this);
                            //AppLovinAdView adView = new AppLovinAdView(AppLovinAdSize.BANNER, context);
                            final boolean isTablet = AppLovinSdkUtils.isTablet(MulaiActivity.this);
                            final int heightPx = AppLovinSdkUtils.dpToPx(MulaiActivity.this, isTablet ? 90 : 50);
                            adView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, heightPx));
                            layAds.addView(adView);
                            adView.loadAd();
                            break;
                        case "MOPUB":
                            Map<String, String> facebookBanner = new HashMap<>();
                            facebookBanner.put("banner", "true");
                            SdkConfiguration.Builder configBuilder = new SdkConfiguration.Builder(BANNER_MOPUB);
                            configBuilder.withMediatedNetworkConfiguration(FacebookBanner.class.getName(), facebookBanner);
                            MoPubView moPubView;
                            moPubView = new MoPubView(MulaiActivity.this);
                            moPubView.setAdUnitId(BANNER_MOPUB);
                            layAds.addView(moPubView);
                            moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_50);
                            moPubView.loadAd();
                            // Sent when the banner has failed to retrieve an ad. You can use the MoPubErrorCode value to diagnose the cause of failure.
                            break;
                    }
                }
            }
        });


    }
    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

}


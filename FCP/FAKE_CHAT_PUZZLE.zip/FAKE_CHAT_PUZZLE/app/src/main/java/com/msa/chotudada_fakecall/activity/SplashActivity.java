package com.msa.chotudada_fakecall.activity;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.msa.chotudada_fakecall.BuildConfig;

import com.msa.chotudada_fakecall.R;
import com.msa.chotudada_fakecall.config.Settings;
import com.msa.chotudada_fakecall.model.Wallpaper;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.msa.chotudada_fakecall.util.AudienceNetworkInitializeHelper;
import com.facebook.ads.AdSettings;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import static com.msa.chotudada_fakecall.config.Settings.ADMOB_INTER;
import static com.msa.chotudada_fakecall.config.Settings.KEY_PACK;
import static com.msa.chotudada_fakecall.config.Settings.ON_OFF_ADS;
import static com.msa.chotudada_fakecall.config.Settings.ON_OFF_DATA;
import static com.msa.chotudada_fakecall.config.Settings.TESTMODE_FAN;
import static com.msa.chotudada_fakecall.config.Settings.URL_DATA;
import static com.facebook.ads.AdSettings.IntegrationErrorMode.INTEGRATION_ERROR_CRASH_DEBUG_MODE;



public class SplashActivity extends AppCompatActivity {
    public static int COUNTER = 0;

    public static ArrayList<Wallpaper> webLists;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        AudienceNetworkInitializeHelper.initialize(this);
        AdSettings.setTestMode(TESTMODE_FAN);
        AdSettings.setIntegrationErrorMode(INTEGRATION_ERROR_CRASH_DEBUG_MODE);
        setContentView(R.layout.splash_activity);
        webLists = new ArrayList<>();

        AudienceNetworkInitializeHelper.initialize(this);
        AdSettings.setTestMode(TESTMODE_FAN);
        AdSettings.setIntegrationErrorMode(INTEGRATION_ERROR_CRASH_DEBUG_MODE);
        setContentView(R.layout.splash_activity);
        if (checkConnectivity()){
            if (ON_OFF_ADS.equals("1")){
                loadUrlData();
            }
        }
         if (ON_OFF_DATA.equals("0")){
            ambildatawall();
        }


        new CountDownTimer(8000, 1000) {
            @Override
            public void onFinish() {
                if (ON_OFF_ADS.equals("1")) {
                    if (KEY_PACK.equals(BuildConfig.APPLICATION_ID)){
                        Intent intent = new Intent(getBaseContext(), MulaiActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        AlertDialog.Builder builder=new AlertDialog.Builder(SplashActivity.this);
                        builder.setCancelable(false);
                        builder.setIcon(R.drawable.ic_baseline_warning_24);
                        builder.setTitle("Attention");
                        builder.setMessage("Wrong applicationId, open json file and fill packagename with your applicationId");
                        builder.setInverseBackgroundForced(true);
                        builder.setNegativeButton("Close",new DialogInterface.OnClickListener(){

                            @Override
                            public void onClick(DialogInterface dialog, int which){
                                finish();
                            }
                        });
                        AlertDialog alert=builder.create();
                        alert.show();
                    }
                } else if (ON_OFF_ADS.equals("0")){
                    Intent intent = new Intent(getBaseContext(), MulaiActivity.class);
                    startActivity(intent);
                    finish();
                }

            }

            @Override
            public void onTick(long millisUntilFinished) {

            }
        }.start();

    }


    public String loadJSONFromAsset() {
        String json = null;
        try {

            InputStream is = SplashActivity.this.getAssets().open("fake_call.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");


        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;

    }

    public void ambildatawall(){
        try {
            JSONObject jsonObject = new JSONObject(loadJSONFromAsset());
            JSONArray jsonArray = jsonObject.getJSONArray("Wallpaper");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonData = jsonArray.getJSONObject(i);
                Wallpaper developers = new Wallpaper(jsonData.getInt("id")
                        , jsonData.getString("title"),
                        jsonData.getString("image"));
                webLists.add(developers);


            }
        } catch (JSONException e) {
            Toast.makeText(SplashActivity.this, e.toString(), Toast.LENGTH_LONG).show();
        }
    }

    private void loadUrlDatawall() {

        final ProgressDialog progressDialog = new ProgressDialog(SplashActivity.this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URL_DATA, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                try {

                    JSONObject jsonObject = new JSONObject(response);

                    JSONArray array = jsonObject.getJSONArray("Wallpaper");

                    for (int i = 0; i < array.length(); i++){
                        JSONObject jo = array.getJSONObject(i);
                        Wallpaper developers = new Wallpaper(jo.getInt("id")
                                , jo.getString("title"),
                                jo.getString("image"));
                        webLists.add(developers);

                    }
                } catch (JSONException e) {

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(SplashActivity.this, "Error" + error.toString(), Toast.LENGTH_SHORT).show();

            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(SplashActivity.this);
        requestQueue.add(stringRequest);
    }

    private void loadUrlData() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URL_DATA, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray array = jsonObject.getJSONArray("Ads");
                    for (int i = 0; i < array.length(); i++){
                        JSONObject c = array.getJSONObject(i);

                        Settings.STATUS_APP = c.getString("status_app");
                        Settings.LINK_REDIRECT = c.getString("link_redirect");

                        Settings.ADMOB_INTER = c.getString("admob_inter1");
                        Settings.ADMOB_NATIV= c.getString("admob_native");
                        Settings.ADMOB_NATIVE_BANNER= c.getString("admob_native_banner");
                        Settings.ADMOB_OPENADS = c.getString("admob_open");
                        Settings.ADMOB_BANNER = c.getString("admob_banner");
                        Settings.ADMOB_REWARD= c.getString("admob_reward");
                        Settings.BANNER_APA_NATIVE = c.getString("banner_apa_native");

                        Settings.SELECT_BANNER = c.getString("select_banner");
                        Settings.SELECT_INTER = c.getString("select_inter");
                        Settings.SELECT_REWARD = c.getString("select_reward");
                        Settings.SELECT_BACKUP_REWARD = c.getString("select_backup_reward");
                        Settings.SELECT_BACKUP_ADS = c.getString("select_backup_ads");
                        Settings.BACKUP_MODE = c.getString("backup_mode");

                        Settings.INITIAL_ADMOB = c.getString("initial_admob");
                        Settings.INITIAL_MOPUB = c.getString("initial_mopub");
                        Settings.INITIAL_APPLOVIN = c.getString("initial_applovin");
                        Settings.INITIAL_STARTAPP = c.getString("initial_startapp");

                        Settings.STARTAPPID = c.getString("startappid");
                        Settings.AGE1 = c.getInt("age1");
                        Settings.AGE2 = c.getInt("age2");
                        Settings.INTERVAL = c.getInt("interval");


                        Settings.BANNER_MOPUB = c.getString("mopub_banner");
                        Settings.INTER_MOPUB = c.getString("mopub_inter");
                        Settings.MREC_MOPUB = c.getString("mopub_mrec");
                        Settings.REWARD_MOPUB = c.getString("mopub_reward");


                        Settings.APPLOVIN_BANNER = c.getString("applovin_banner");
                        Settings.APPLOVIN_INTER = c.getString("applovin_inter");
                        Settings.APPLOVIN_REWARD = c.getString("applovin_reward");


                    }


                } catch (JSONException e) {

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(SplashActivity.this);
        requestQueue.add(stringRequest);
    }

    private boolean checkConnectivity() {
        ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = connectivityManager.getActiveNetworkInfo();
        if ((info == null || !info.isConnected() || !info.isAvailable())) {
              return false;
        } else {
            return true;
        }
    }

    private void nointernetp() {
        AlertDialog.Builder builder=new AlertDialog.Builder(SplashActivity.this);
        builder.setCancelable(true);
        builder.setIcon(R.drawable.ic_baseline_network_check_24);
        builder.setTitle("Bad Connection");
        builder.setMessage("No internet access, please activate the internet to use the app!");
        builder.setInverseBackgroundForced(true);
        builder.setPositiveButton("Close",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which){
                finish();
                Intent intent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        builder.setNegativeButton("Reload",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which){

                Intent intent = new Intent(getBaseContext(), MulaiActivity.class);
                startActivity(intent);
                finish();
            }
        });
        AlertDialog alert=builder.create();
        alert.show();
    }

}

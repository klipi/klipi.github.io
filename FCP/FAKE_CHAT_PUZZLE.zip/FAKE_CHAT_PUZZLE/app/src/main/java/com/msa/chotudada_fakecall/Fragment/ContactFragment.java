package com.msa.chotudada_fakecall.Fragment;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.msa.chotudada_fakecall.adapter.ContactAdapter;
import com.msa.chotudada_fakecall.R;
import com.msa.chotudada_fakecall.model.Video;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import static com.msa.chotudada_fakecall.config.Settings.ON_OFF_DATA;
import static com.msa.chotudada_fakecall.config.Settings.URL_DATA;

public class ContactFragment extends Fragment {
    private RecyclerView recyclerView;
    private ContactAdapter adapter;
    ArrayList<Video> ContactList;
    Activity activity;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = getActivity();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_contact, container, false);

        setHasOptionsMenu(true);
        recyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        ContactList = new ArrayList<>();
        activity = getActivity();
        if (ON_OFF_DATA.equals("1")){
            if (checkConnectivity()){
                loadUrlDataRecent();
            } else {
                dataRecentContact();
            }
        } else {
            dataRecentContact();
        }

        return view;
    }

    public String loadJSONFromAsset() {
        String json = null;
        try {

            InputStream is =getActivity().getAssets().open("fake_call.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");

        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    public void dataRecentContact(){
        try {
            JSONObject jsonObject = new JSONObject(loadJSONFromAsset());
            JSONArray array = jsonObject.getJSONArray("Item");

            for (int i = 0; i < array.length(); i++) {
                JSONObject jsonData = array.getJSONObject(i);
                Video dataUrl = new Video();
                dataUrl.id = jsonData.getInt("id");
                dataUrl.judul_vid = jsonData.getString("name");
                dataUrl.des_vid = jsonData.getString("description");
                dataUrl.gambar_url= jsonData.getString("image_url");
                dataUrl.video_url = jsonData.getString("video_url");
                ContactList.add(dataUrl);
            }
            adapter = new ContactAdapter(ContactList, getActivity());
            recyclerView.setAdapter(adapter);
        } catch (JSONException e) {
            Toast.makeText(getActivity(), e.toString(), Toast.LENGTH_LONG).show();
        }
    }

    private void loadUrlDataRecent() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URL_DATA, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray array = jsonObject.getJSONArray("Item");
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonData = array.getJSONObject(i);
                        Video dataUrl = new Video();
                        dataUrl.id = jsonData.getInt("id");
                        dataUrl.judul_vid = jsonData.getString("name");
                        dataUrl.des_vid = jsonData.getString("description");
                        dataUrl.gambar_url= jsonData.getString("image_url");
                        dataUrl.video_url = jsonData.getString("video_url");
                        ContactList.add(dataUrl);
                    }

                    adapter = new ContactAdapter(ContactList, getActivity());
                    recyclerView.setAdapter(adapter);
                } catch (JSONException e) {

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(stringRequest);
    }

    private boolean checkConnectivity() {
        boolean enabled = true;
        ConnectivityManager connectivityManager = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = connectivityManager.getActiveNetworkInfo();
        if ((info == null || !info.isConnected() || !info.isAvailable())) {
            return false;
        } else {
            return true;
        }
    }

}

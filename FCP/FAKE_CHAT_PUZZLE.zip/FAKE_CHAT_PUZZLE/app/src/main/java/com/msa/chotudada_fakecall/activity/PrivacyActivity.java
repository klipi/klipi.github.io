package com.msa.chotudada_fakecall.activity;

import android.os.Bundle;
import android.webkit.WebView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.msa.chotudada_fakecall.R;
import com.msa.chotudada_fakecall.config.Settings;


public class PrivacyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide);

        TextView txtjudul = findViewById(R.id.txtjudul);
        txtjudul.setText("Privacy Police");
        WebView webView = (WebView) findViewById(R.id.webview);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl(Settings.Privacy_police);
    }
    @Override
    public void onBackPressed()
    {
      finish();
    }

}
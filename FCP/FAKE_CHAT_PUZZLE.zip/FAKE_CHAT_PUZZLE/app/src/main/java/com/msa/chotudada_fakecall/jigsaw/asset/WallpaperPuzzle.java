package com.msa.chotudada_fakecall.jigsaw.asset;

public class WallpaperPuzzle {

    private String avatar_url;
    private String html_url;

    public WallpaperPuzzle() {

    }

    public String getAvatar_url() {
        return avatar_url;
    }

    public String getHtml_url() {
        return html_url;
    }

    public WallpaperPuzzle(String jdl, String img) {
        this.html_url = jdl;
        this.avatar_url = img;
    }


}

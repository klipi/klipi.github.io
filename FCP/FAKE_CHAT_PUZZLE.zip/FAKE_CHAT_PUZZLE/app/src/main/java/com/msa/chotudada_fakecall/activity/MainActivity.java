package com.msa.chotudada_fakecall.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;

import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.ads.MaxAdView;
import com.applovin.sdk.AppLovinMediationProvider;
import com.facebook.ads.AdSettings;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.mopub.common.MoPub;
import com.mopub.common.SdkConfiguration;
import com.mopub.mobileads.FacebookBanner;
import com.mopub.mobileads.MoPubView;
import com.msa.chotudada_fakecall.BuildConfig;
import com.msa.chotudada_fakecall.R;
import com.msa.chotudada_fakecall.config.Settings;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.applovin.adview.AppLovinInterstitialAdDialog;
import com.applovin.sdk.AppLovinAd;
import com.msa.chotudada_fakecall.adapter.FakeAdapter;
import com.msa.chotudada_fakecall.adapter.MoreAdapter;
import com.msa.chotudada_fakecall.model.Item;
import com.msa.chotudada_fakecall.model.MoreList;

import com.applovin.sdk.AppLovinAdSize;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkUtils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.InstallState;
import com.google.android.play.core.install.InstallStateUpdatedListener;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.InstallStatus;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.google.android.play.core.tasks.OnCompleteListener;
import com.google.android.play.core.tasks.OnFailureListener;
import com.google.android.play.core.tasks.OnSuccessListener;
import com.google.android.play.core.tasks.Task;
import com.google.android.ump.ConsentForm;
import com.google.android.ump.ConsentInformation;
import com.startapp.sdk.ads.banner.Banner;
import com.startapp.sdk.ads.banner.banner3d.Banner3D;
import com.startapp.sdk.adsbase.Ad;
import com.startapp.sdk.adsbase.StartAppAd;
import com.startapp.sdk.adsbase.StartAppSDK;
import com.startapp.sdk.adsbase.adlisteners.AdEventListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.msa.chotudada_fakecall.config.Settings.ADMOB_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.ADMOB_INTER;
import static com.msa.chotudada_fakecall.config.Settings.ADMOB_NATIVE_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.APPLOVIN_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.BACKUP_MODE;
import static com.msa.chotudada_fakecall.config.Settings.BANNER_MOPUB;
import static com.msa.chotudada_fakecall.config.Settings.LINK_REDIRECT;
import static com.msa.chotudada_fakecall.config.Settings.ON_OFF_DATA;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_BANNER;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_INTER;
import static com.msa.chotudada_fakecall.config.Settings.STATUS_APP;
import static com.msa.chotudada_fakecall.config.Settings.SELECT_BACKUP_ADS;
import static com.msa.chotudada_fakecall.config.Settings.URL_DATA;
import static com.google.android.play.core.install.model.ActivityResult.RESULT_IN_APP_UPDATE_FAILED;
import static com.google.android.play.core.install.model.AppUpdateType.FLEXIBLE;


public class MainActivity extends AppCompatActivity{
    private RecyclerView recyclerView;
    private MoreAdapter adapter;
    List<MoreList> webLists;
    ReviewInfo reviewInfo;
    ReviewManager manager;
    private static final int MY_REQUEST_CODE = 17326;
    private RecyclerView recFake;
    private FakeAdapter adapterFake;
    List<Item> fakeLists;
    private LinearLayout laymore;
    private ConsentInformation consentInformation;
    private ConsentForm consentForm;
    public static InterstitialAd mInterstitialAd;
    public static AdRequest adRequest ;
    public static com.facebook.ads.InterstitialAd interstitialAdfb;
    public static AppLovinInterstitialAdDialog interstitialAdlovin;
    public static AppLovinAd loadedAd;
    public StartAppAd startAppAd = new StartAppAd(MainActivity.this);
    public static Activity fa;
    RelativeLayout mainLayout;
    private RelativeLayout layAds;
    private AdView adView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        {
            fa = this;
        }
        Review();


        Button bt_chat = (Button) findViewById(R.id.chatnow);
        bt_chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MulaiActivity.class);
                startActivity(intent);



            }
        });


        if (STATUS_APP.equals("1")) {
            String str = LINK_REDIRECT;
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse(str)));
            finish();
        }
        mainLayout = (RelativeLayout) findViewById(R.id.mainLayout);
        layAds = findViewById(R.id.layAds);
        switch (SELECT_BANNER) {
            case "ADMOB":
                if (Settings.BANNER_APA_NATIVE.equals("NATIVE")){
                    nativeadmob();
                } else {
                    adView = new AdView(this);
                    adView.setAdUnitId(ADMOB_BANNER);
                    layAds.addView(adView);
                    loadBanner();
                }
                break;
            case "APPLOVIN":
                AdSettings.setDataProcessingOptions(new String[]{});
                AppLovinSdk.getInstance(MainActivity.this).setMediationProvider(AppLovinMediationProvider.MAX);
                AppLovinSdk sdk = AppLovinSdk.getInstance(MainActivity.this);
                sdk.getSettings().setMuted(!sdk.getSettings().isMuted());
                MaxAdView adView;
                adView = new MaxAdView(APPLOVIN_BANNER, (Activity) MainActivity.this);
                //AppLovinAdView adView = new AppLovinAdView(AppLovinAdSize.BANNER, context);
                final boolean isTablet = AppLovinSdkUtils.isTablet(MainActivity.this);
                final int heightPx = AppLovinSdkUtils.dpToPx(MainActivity.this, isTablet ? 90 : 50);
                adView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, heightPx));
                mainLayout.addView(adView);
                adView.loadAd();
                break;
            case "STARTAPP":
                Banner3D startAppBanner = new Banner3D(MainActivity.this);
                RelativeLayout.LayoutParams bannerParameters =
                        new RelativeLayout.LayoutParams(
                                RelativeLayout.LayoutParams.WRAP_CONTENT,
                                RelativeLayout.LayoutParams.WRAP_CONTENT);
                bannerParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);
                mainLayout.addView(startAppBanner, bannerParameters);
                break;
            case "MOPUB":
                Map<String, String> facebookBanner = new HashMap<>();
                facebookBanner.put("native_banner", "true");
                SdkConfiguration.Builder configBuilder = new SdkConfiguration.Builder(BANNER_MOPUB);
                configBuilder.withMediatedNetworkConfiguration(FacebookBanner.class.getName(), facebookBanner);
                MoPubView moPubView;
                moPubView = new MoPubView(this);
                moPubView.setAdUnitId(BANNER_MOPUB);
                mainLayout.addView(moPubView);
                moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_50);
                moPubView.loadAd();
                break;
        }





        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[] {Manifest.permission.CAMERA}, 1);
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            if (!android.provider.Settings.canDrawOverlays(this)) {
                checkPermission();

            }
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            int LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_PHONE;
            WindowManager.LayoutParams mWindowParams = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                    LAYOUT_FLAG, // Overlay over the other apps.
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE    // This flag will enable the back key press.
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, // make the window to deliver the focus to the BG window.
                    PixelFormat.TRANSPARENT);
        }

        recyclerView = (RecyclerView)findViewById(R.id.recmore);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager HorizontalLayout = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL,
                false);
        recyclerView.setLayoutManager(HorizontalLayout);
        webLists = new ArrayList<>();
        laymore = findViewById(R.id.laymore);

        final Button tbmore = findViewById(R.id.tbmore);

        tbmore.setBackground(getResources().getDrawable(R.drawable.ic_baseline_keyboard_arrow_down_24));
        tbmore.setTag("gray");
        tbmore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tag = tbmore.getTag().toString();
                if(tag.equalsIgnoreCase("gray"))
                {
                    tbmore.setTag("red");
                    tbmore.setBackground(getResources().getDrawable(R.drawable.ic_baseline_keyboard_arrow_up_24));
                    laymore.setVisibility(View.VISIBLE);
                }
                else
                {
                    tbmore.setTag("gray");
                    tbmore.setBackground(getResources().getDrawable(R.drawable.ic_baseline_keyboard_arrow_down_24));
                    laymore.setVisibility(View.GONE);
                }

            }
        });

        recFake = (RecyclerView) findViewById(R.id.recfake);
        recFake.setHasFixedSize(true);
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(this, 3);
        recFake.setLayoutManager(mLayoutManager);
        fakeLists = new ArrayList<>();
        if (ON_OFF_DATA.equals("1")){
            if (checkConnectivity()){
                loadUrlDataFake();
                loadUrlDataMore();
            }
        } else {
            loadUrlDataMore();
            dataFake();
        }
    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_share) {
            String shareLink = "https://play.google.com/store/apps/details?id="
                    + BuildConfig.APPLICATION_ID;
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT,
                    getResources().getString(R.string.shareit)+" "
                            + shareLink);
            sendIntent.setType("text/plain");
            startActivity(sendIntent);
            return true;
        } else if (id == R.id.menu_rate) {
            String str = "https://play.google.com/store/apps/details?id="
                    + BuildConfig.APPLICATION_ID;
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse(str)));
            finish();
            return true;
        }else if (id == R.id.menu_update) {
            checkUpdate();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public String loadJSONFromAsset() {
        String json = null;
        try {
            InputStream is = getAssets().open("fake_call.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    public void datamore(){
        try {
            JSONObject jsonObject = new JSONObject(loadJSONFromAsset());
            JSONArray jsonArray = jsonObject.getJSONArray("More");
            // Extract data from json and store into ArrayList as class objects
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonData = jsonArray.getJSONObject(i);
                MoreList dataUrl = new MoreList();
                dataUrl.id = jsonData.getInt("id");
                dataUrl.name = jsonData.getString("title");
                dataUrl.image_url = jsonData.getString("image");
                dataUrl.link_url = jsonData.getString("link");
                webLists.add(dataUrl);
            }

            adapter = new MoreAdapter(webLists, MainActivity.this);
            recyclerView.setAdapter(adapter);

        } catch (JSONException e) {
            Toast.makeText(MainActivity.this, e.toString(), Toast.LENGTH_LONG).show();
        }
    }

    public void dataFake(){
        try {
            JSONObject jsonObject = new JSONObject(loadJSONFromAsset());
            JSONArray jsonArray = jsonObject.getJSONArray("Item");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonData = jsonArray.getJSONObject(i);
                Item dataUrl = new Item();
                dataUrl.Id = jsonData.getInt("id");
                dataUrl.namefake = jsonData.getString("name");
                dataUrl.image_url = jsonData.getString("image_url");
                dataUrl.viode_url = jsonData.getString("video_url");
                dataUrl.voice_url = jsonData.getString("voice_url");
                fakeLists.add(dataUrl);
            }
            adapterFake = new FakeAdapter(fakeLists, MainActivity.this);
            recFake.setAdapter(adapterFake);

        } catch (JSONException e) {
            Toast.makeText(MainActivity.this, e.toString(), Toast.LENGTH_LONG).show();
        }
    }

    private boolean checkConnectivity() {
        ConnectivityManager connectivityManager = (ConnectivityManager) MainActivity.this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = connectivityManager.getActiveNetworkInfo();
        if ((info == null || !info.isConnected() || !info.isAvailable())) {
            return false;
        } else {
            return true;
        }
    }




    private void loadUrlDataFake() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URL_DATA, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray array = jsonObject.getJSONArray("Item");
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonData = array.getJSONObject(i);
                        Item dataUrl = new Item();
                        dataUrl.Id = jsonData.getInt("id");
                        dataUrl.namefake = jsonData.getString("name");
                        dataUrl.image_url = jsonData.getString("image_url");
                        dataUrl.viode_url = jsonData.getString("video_url");
                        dataUrl.voice_url = jsonData.getString("voice_url");
                        fakeLists.add(dataUrl);
                    }
                    adapterFake = new FakeAdapter(fakeLists, MainActivity.this);
                    recFake.setAdapter(adapterFake);

                } catch (JSONException e) {

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
        requestQueue.add(stringRequest);
    }

    private void loadUrlDataMore() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URL_DATA, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray array = jsonObject.getJSONArray("More");
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonData = array.getJSONObject(i);
                        MoreList dataUrl = new MoreList();
                        dataUrl.id = jsonData.getInt("id");
                        dataUrl.name = jsonData.getString("title");
                        dataUrl.image_url = jsonData.getString("image");
                        dataUrl.link_url = jsonData.getString("link");
                        webLists.add(dataUrl);
                    }
                    adapter = new MoreAdapter(webLists, MainActivity.this);
                    recyclerView.setAdapter(adapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
        requestQueue.add(stringRequest);
    }
    public static int ACTION_MANAGE_OVERLAY_PERMISSION_REQUEST_CODE = 5469;
    @TargetApi(Build.VERSION_CODES.M)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ACTION_MANAGE_OVERLAY_PERMISSION_REQUEST_CODE) {
            if (!android.provider.Settings.canDrawOverlays(this)) {
                checkPermission();
            } else {

            }
        }

        if (requestCode == MY_REQUEST_CODE){
            switch (resultCode){
                case Activity.RESULT_OK:
                    if(resultCode != RESULT_OK){
                        Toast.makeText(this,"RESULT_OK" +resultCode, Toast.LENGTH_LONG).show();
                        Log.d("RESULT_OK  :",""+resultCode);
                    }
                    break;
                case Activity.RESULT_CANCELED:
                    if (resultCode != RESULT_CANCELED){
                        Toast.makeText(this,"RESULT_CANCELED" +resultCode, Toast.LENGTH_LONG).show();
                        Log.d("RESULT_CANCELED  :",""+resultCode);
                    }
                    break;
                case RESULT_IN_APP_UPDATE_FAILED:
                    if (resultCode != RESULT_IN_APP_UPDATE_FAILED){
                        Toast.makeText(this,"RESULT_IN_APP_UPDATE_FAILED" +resultCode, Toast.LENGTH_LONG).show();
                        Log.d("RESULT_IN_APP_FAILED:",""+resultCode);
                    }
            }
        }
    }

    public void checkPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!android.provider.Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, ACTION_MANAGE_OVERLAY_PERMISSION_REQUEST_CODE);
            }
        }
    }

     /*
    In app review
     */

    private void Review(){
        manager = ReviewManagerFactory.create(this);
        manager.requestReviewFlow().addOnCompleteListener(new OnCompleteListener<ReviewInfo>() {
            @Override
            public void onComplete(@NonNull Task<ReviewInfo> task) {
                if(task.isSuccessful()){
                    reviewInfo = task.getResult();
                    manager.launchReviewFlow(MainActivity.this, reviewInfo).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(Exception e) {
                            //Toast.makeText(MainActivity.this, "Rating Failed", Toast.LENGTH_SHORT).show();
                        }
                    }).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            // Toast.makeText(MainActivity.this, "Review Completed, Thank You!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(Exception e) {
                Toast.makeText(MainActivity.this, "In-App Request Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /*
       In App Update
        */
    AppUpdateManager appUpdateManager;
    com.google.android.play.core.tasks.Task<AppUpdateInfo> appUpdateInfoTask;
    private void checkUpdate(){
        appUpdateManager = AppUpdateManagerFactory.create(this);
        appUpdateManager.registerListener(listener);

        appUpdateInfoTask = appUpdateManager.getAppUpdateInfo();
        appUpdateInfoTask.addOnSuccessListener(new OnSuccessListener<AppUpdateInfo>() {
            @SuppressLint("WrongConstant")
            @Override
            public void onSuccess(AppUpdateInfo appUpdateInfo) {
                Log.d("appUpdateInfo :", "packageName :"+appUpdateInfo.packageName()+ ", "+ "availableVersionCode :"+ appUpdateInfo.availableVersionCode() +", "+"updateAvailability :"+ appUpdateInfo.updateAvailability() +", "+ "installStatus :" + appUpdateInfo.installStatus() );

                if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                        && appUpdateInfo.isUpdateTypeAllowed(FLEXIBLE)){
                    requestUpdate(appUpdateInfo);
                    Log.d("UpdateAvailable","update is there ");
                }
                else if (appUpdateInfo.updateAvailability() == 3){
                    Log.d("Update","3");
                    notifyUser();
                }
                else
                {
                    Toast.makeText(MainActivity.this, "No Update Available", Toast.LENGTH_SHORT).show();
                    Log.d("NoUpdateAvailable","update is not there ");
                }
            }
        });
    }
    private void requestUpdate(AppUpdateInfo appUpdateInfo){
        try {
            appUpdateManager.startUpdateFlowForResult(appUpdateInfo, AppUpdateType.FLEXIBLE, MainActivity.this,MY_REQUEST_CODE);
            resume();
        } catch (IntentSender.SendIntentException e) {
            e.printStackTrace();
        }
    }

    InstallStateUpdatedListener listener = new InstallStateUpdatedListener() {
        @Override
        public void onStateUpdate(InstallState installState) {
            if (installState.installStatus() == InstallStatus.DOWNLOADED){
                Log.d("InstallDownloded","InstallStatus sucsses");
                notifyUser();
            }
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void notifyUser() {
        Snackbar snackbar =
                Snackbar.make(findViewById(R.id.frame_container),
                        "An update has just been downloaded.",
                        Snackbar.LENGTH_INDEFINITE);
        snackbar.setAction("RESTART", new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                appUpdateManager.completeUpdate();
            }
        });
        snackbar.setActionTextColor(
                getResources().getColor(R.color.browser_actions_bg_grey));
        snackbar.show();
    }

    private void resume(){
        appUpdateManager.getAppUpdateInfo().addOnSuccessListener(new OnSuccessListener<AppUpdateInfo>() {
            @Override
            public void onSuccess(AppUpdateInfo appUpdateInfo) {
                if (appUpdateInfo.installStatus() == InstallStatus.DOWNLOADED){
                    notifyUser();
                }

            }
        });
    }









    private NativeAd nativeAd;
    private void nativeadmob() {
        refreshAd();
    }

    private void populateNativeAdView(NativeAd nativeAd, NativeAdView adView) {
        adView.setMediaView((MediaView) adView.findViewById(R.id.ad_media));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));
        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        adView.getMediaView().setMediaContent(nativeAd.getMediaContent());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getPrice() == null) {
            adView.getPriceView().setVisibility(View.INVISIBLE);
        } else {
            adView.getPriceView().setVisibility(View.VISIBLE);
            ((TextView) adView.getPriceView()).setText(nativeAd.getPrice());
        }

        if (nativeAd.getStore() == null) {
            adView.getStoreView().setVisibility(View.INVISIBLE);
        } else {
            adView.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) adView.getStoreView()).setText(nativeAd.getStore());
        }

        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.INVISIBLE);
        } else {
            ((TextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.VISIBLE);
        }
        adView.setNativeAd(nativeAd);
    }

    private void refreshAd() {

        AdLoader.Builder builder = new AdLoader.Builder(this, ADMOB_NATIVE_BANNER);

        builder.forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {
            @Override
            public void onNativeAdLoaded(@NonNull com.google.android.gms.ads.nativead.NativeAd nativeAds) {

                if (nativeAd != null) {
                    nativeAd.destroy();
                }

                nativeAd = nativeAds;
                FrameLayout frameLayout =
                        findViewById(R.id.fl_adplaceholder);
                NativeAdView adView = (NativeAdView) getLayoutInflater()
                        .inflate(R.layout.admob_native, null);
                populateNativeAdView(nativeAds, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });

        VideoOptions videoOptions = new VideoOptions.Builder()
                .build();

        com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader =
                builder
                        .withAdListener(
                                new AdListener() {
                                    @Override
                                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                                        if (BACKUP_MODE.equals("YES")){

                                            switch (SELECT_BACKUP_ADS) {
                                                case "STARTAPP":
                                                    Banner3D startAppBanner = new Banner3D(MainActivity.this);
                                                    RelativeLayout.LayoutParams bannerParameters =
                                                            new RelativeLayout.LayoutParams(
                                                                    RelativeLayout.LayoutParams.WRAP_CONTENT,
                                                                    RelativeLayout.LayoutParams.WRAP_CONTENT);
                                                    bannerParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);
                                                    mainLayout.addView(startAppBanner, bannerParameters);
                                                    startAppAd.loadAd (new AdEventListener() {
                                                        @Override
                                                        public void onReceiveAd(com.startapp.sdk.adsbase.Ad ad) {

                                                        }

                                                        @Override
                                                        public void onFailedToReceiveAd(Ad ad) {
                                                        }
                                                    });
                                                    break;
                                                case "APPLOVIN":
                                                    MaxAdView adView;
                                                    adView = new MaxAdView(APPLOVIN_BANNER, (Activity) MainActivity.this);
                                                    //AppLovinAdView adView = new AppLovinAdView(AppLovinAdSize.BANNER, context);
                                                    final boolean isTablet = AppLovinSdkUtils.isTablet(MainActivity.this);
                                                    final int heightPx = AppLovinSdkUtils.dpToPx(MainActivity.this, isTablet ? 90 : 50);
                                                    adView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, heightPx));
                                                    mainLayout.addView(adView);
                                                    adView.loadAd();
                                                    break;
                                                case "MOPUB":
                                                    MoPubView moPubView;
                                                    moPubView = new MoPubView(MainActivity.this);
                                                    moPubView.setAdUnitId(BANNER_MOPUB);
                                                    mainLayout.addView(moPubView);
                                                    moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_50);
                                                    moPubView.setBannerAdListener((MoPubView.BannerAdListener) MainActivity.this);
                                                    // Sent when the banner has failed to retrieve an ad. You can use the MoPubErrorCode value to diagnose the cause of failure.
                                                    break;
                                            }
                                        }
                                    }
                                })
                        .build();
        adLoader.loadAd(MulaiActivity.request);

    }








    private void loadBanner() {
        AdSize adSize = getAdSize();
        adView.setAdSize(adSize);
        adView.loadAd(MulaiActivity.request);
        adView.setAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                if (BACKUP_MODE.equals("YES")){

                    switch (SELECT_BACKUP_ADS) {
                        case "STARTAPP":
                            Banner3D startAppBanner = new Banner3D(MainActivity.this);
                            RelativeLayout.LayoutParams bannerParameters =
                                    new RelativeLayout.LayoutParams(
                                            RelativeLayout.LayoutParams.WRAP_CONTENT,
                                            RelativeLayout.LayoutParams.WRAP_CONTENT);
                            bannerParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);
                            mainLayout.addView(startAppBanner, bannerParameters);
                            startAppAd.loadAd (new AdEventListener() {
                                @Override
                                public void onReceiveAd(Ad ad) {

                                }

                                @Override
                                public void onFailedToReceiveAd(Ad ad) {
                                }
                            });
                            break;
                        case "APPLOVIN":
                            MaxAdView adView;
                            adView = new MaxAdView(APPLOVIN_BANNER, (Activity) MainActivity.this);
                            //AppLovinAdView adView = new AppLovinAdView(AppLovinAdSize.BANNER, context);
                            final boolean isTablet = AppLovinSdkUtils.isTablet(MainActivity.this);
                            final int heightPx = AppLovinSdkUtils.dpToPx(MainActivity.this, isTablet ? 90 : 50);
                            adView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, heightPx));
                            mainLayout.addView(adView);
                            adView.loadAd();
                            break;
                        case "MOPUB":
                            Map<String, String> facebookBanner = new HashMap<>();
                            facebookBanner.put("native_banner", "true");
                            SdkConfiguration.Builder configBuilder = new SdkConfiguration.Builder(BANNER_MOPUB);
                            configBuilder.withMediatedNetworkConfiguration(FacebookBanner.class.getName(), facebookBanner);
                            MoPubView moPubView;
                            moPubView = new MoPubView(MainActivity.this);
                            moPubView.setAdUnitId(BANNER_MOPUB);
                            mainLayout.addView(moPubView);
                            moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_50);
                            moPubView.loadAd();
                            // Sent when the banner has failed to retrieve an ad. You can use the MoPubErrorCode value to diagnose the cause of failure.
                            break;
                    }
                }
            }
        });


    }
    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }


}

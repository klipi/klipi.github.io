package com.aliendroid.skincraft.model;

public class Skin {

    public int id;
    public String nama_skin;
    public String skin_url;
    public String view_skin;

    public Skin() {  }

    public String getNama_skin() {
        return nama_skin;
    }

    public String getSkin_url() {
        return skin_url;
    }

    public String getView_skin() {
        return view_skin;
    }

    public Skin(int no, String nm, String sk, String vs) {
        this.id=no;
        this.nama_skin = nm ;
        this.skin_url = sk;
        this.view_skin = vs;
    }


}

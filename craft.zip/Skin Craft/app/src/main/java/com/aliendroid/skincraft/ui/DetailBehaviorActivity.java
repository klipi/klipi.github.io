package com.aliendroid.skincraft.ui;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.aliendroid.skincraft.R;
import com.aliendroid.skincraft.adapter.AddonsAdapter;
import com.aliendroid.skincraft.adapter.MapsAdapter;
import com.aliendroid.skincraft.config.Settings;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.NativeAdBase;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.google.ads.mediation.facebook.FacebookAdapter;
import com.google.ads.mediation.facebook.FacebookExtras;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.mopub.mobileads.MoPubInterstitial;
import com.mopub.mobileads.MoPubView;
import com.squareup.picasso.Picasso;
import com.startapp.sdk.ads.banner.Banner;
import com.startapp.sdk.adsbase.StartAppAd;
import com.startapp.sdk.adsbase.adlisteners.AdEventListener;
import com.startapp.sdk.adsbase.adlisteners.VideoListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.services.banners.BannerView;
import com.unity3d.services.banners.UnityBannerSize;


import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

import static com.aliendroid.skincraft.config.Settings.ADMOB_INTER;
import static com.aliendroid.skincraft.config.Settings.ADMOB_NATIVE_BANNER;
import static com.aliendroid.skincraft.config.Settings.BACKUP_MODE;
import static com.aliendroid.skincraft.config.Settings.BANNER_MOPUB;

import static com.aliendroid.skincraft.config.Settings.FAN_INTER;
import static com.aliendroid.skincraft.config.Settings.FAN_NATIVE_BANNER;
import static com.aliendroid.skincraft.config.Settings.SELECT_ADS;
import static com.aliendroid.skincraft.config.Settings.Unity_BANNER;
import static com.aliendroid.skincraft.config.Settings.Unity_INTER;

public class DetailBehaviorActivity extends AppCompatActivity implements NativeAdListener {
    private int position = 0;
    File dirDown, root, dirDowB, dirDowR;
    private final int TIMEOUT_CONNECTION = 15000;
    private final int TIMEOUT_SOCKET = 30000;
    protected static final String TAG = DetailBehaviorActivity.class.getSimpleName();
    private ProgressDialog mProgressDialog;
    private WebView mWebView;
    private FrameLayout adContainerView;
    private AdView adView;

    private com.facebook.ads.AdView bannerAdView;
    private RelativeLayout bannerAdContainer;

    public StartAppAd startAppAd = new StartAppAd (this);
    public static InterstitialAd mInterstitialAd;
    private com.facebook.ads.InterstitialAd interstitialAdfb;
    public static MoPubInterstitial mInterstitial;

    public void onSaveInstanceState(@NonNull Bundle saveInsBundleState) {
        super.onSaveInstanceState(saveInsBundleState);
        saveInsBundleState.putInt("position", position);

    }
    @Override
    protected void onCreate(Bundle saveInsBundleState) {
        super.onCreate(saveInsBundleState);
        setContentView(R.layout.activity_detail_skin_add_map);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            position = extras.getInt("position");
        } else {
            if (saveInsBundleState != null) {
                position = saveInsBundleState.getInt("position");
            } else {
                position = 1;
            }
        }

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            root = Environment.getExternalStorageDirectory();
        }else {
            root = Environment.getExternalStorageDirectory();
        }
        dirDowB  = new File(root.getAbsolutePath()
                + "/games/com.mojang/behavior_packs/");
        if(!dirDowB.exists()){
            dirDowB.mkdirs();
        }

        dirDowR  = new File(root.getAbsolutePath()
                + "/games/com.mojang/resource_packs/");
        if(!dirDowR.exists()){
            dirDowR.mkdirs();
        }

        dirDown = new File(root.getAbsolutePath()
                + "/"+this.getResources().getString(R.string.app_name)+"/");
        if(!dirDown.exists()){
            dirDown.mkdirs();
        }

        if (Settings.SELECT_ADS.equals("ADMOB")){
            nativeadmob();
            loadinteradmob();
        } else if (SELECT_ADS.equals("FACEBOOK")){
            nativbanner();
            loadfan();
        } else if (SELECT_ADS.equals("STARTAPP")){
            bannerstartapp();
        } else if (SELECT_ADS.equals("MOPUB")){
            bannermopub();
            loadmopub();
        }else if (SELECT_ADS.equals("UNITY")){
            bannerunity();
        }


        Button tb_down=findViewById(R.id.tb_download);
        tb_down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveFile(AddonsAdapter.mFilteredList.get(position).getAdd_url(),"/"+AddonsAdapter.mFilteredList.get(position).getNama_add()+".zip");
            }
        });


        Button tb_instal=findViewById(R.id.tb_install);
        tb_instal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                internya();
                saveFileB(AddonsAdapter.mFilteredList.get(position).getAddB_url(),"/"+AddonsAdapter.mFilteredList.get(position).getNama_add()+".mcpack");
                saveFileR(AddonsAdapter.mFilteredList.get(position).getAddR_url(),"/"+AddonsAdapter.mFilteredList.get(position).getNama_add()+"..mcpack");

            }
        });

        TextView txt_9 = findViewById(R.id.textView9);
        TextView txt_judul = findViewById(R.id.txt_judul);
        txt_judul.setText(AddonsAdapter.mFilteredList.get(position).getNama_add());
        mWebView = findViewById(R.id.webview);
        mWebView.getSettings().setBuiltInZoomControls(true);
        mWebView.getSettings().setDisplayZoomControls(false);
        mWebView.loadUrl(AddonsAdapter.mFilteredList.get(position).getDes_add());
        ImageView gambrH = findViewById(R.id.imap);
        Picasso.get()
                .load(AddonsAdapter.mFilteredList.get(position).getView_add())
                .into(gambrH);
    }





    private void saveFileB(final String download_link, final String name) {
        final ProgressDialog progressDialog = new ProgressDialog(DetailBehaviorActivity.this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();
        new Thread(new Runnable() {
            public void run(){

                try
                {
                    URL url = new URL(download_link);
                    URLConnection ucon = url.openConnection();
                    ucon.setReadTimeout(TIMEOUT_CONNECTION);
                    ucon.setConnectTimeout(TIMEOUT_SOCKET);
                    InputStream is = ucon.getInputStream();
                    BufferedInputStream inStream = new BufferedInputStream(is, 1024 * 5);
                    FileOutputStream outStream = new FileOutputStream(dirDowB+name);
                    byte[] buff = new byte[5 * 1024];
                    int len;
                    while ((len = inStream.read(buff)) != -1) {
                        outStream.write(buff,0,len);
                    }
                    outStream.flush();
                    outStream.close();
                    inStream.close();
                    ((Activity) DetailBehaviorActivity.this).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            progressDialog.dismiss();
                            exitapp();
                            refreshAndroidGallery(Uri.fromFile(new File(dirDowB+name)));
                        }
                    });

                }catch (Exception e){
                    int y;
                }
            }
        }).start();

    }

    private void saveFileR(final String download_link, final String name) {
        final ProgressDialog progressDialog = new ProgressDialog(DetailBehaviorActivity.this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();
        new Thread(new Runnable() {
            public void run(){

                try
                {
                    URL url = new URL(download_link);
                    URLConnection ucon = url.openConnection();
                    ucon.setReadTimeout(TIMEOUT_CONNECTION);
                    ucon.setConnectTimeout(TIMEOUT_SOCKET);
                    InputStream is = ucon.getInputStream();
                    BufferedInputStream inStream = new BufferedInputStream(is, 1024 * 5);
                    FileOutputStream outStream = new FileOutputStream(dirDowR+name);
                    byte[] buff = new byte[5 * 1024];
                    int len;
                    while ((len = inStream.read(buff)) != -1) {
                        outStream.write(buff,0,len);
                    }
                    outStream.flush();
                    outStream.close();
                    inStream.close();
                    ((Activity) DetailBehaviorActivity.this).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            progressDialog.dismiss();
                            exitapp();
                            refreshAndroidGallery(Uri.fromFile(new File(dirDowR+name)));
                        }
                    });

                }catch (Exception e){
                    int y;
                }
            }
        }).start();

    }

    private void saveFile(final String download_link, final String name) {
        final ProgressDialog progressDialog = new ProgressDialog(DetailBehaviorActivity.this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();
        new Thread(new Runnable() {
            public void run(){

                try
                {
                    URL url = new URL(download_link);
                    URLConnection ucon = url.openConnection();
                    ucon.setReadTimeout(TIMEOUT_CONNECTION);
                    ucon.setConnectTimeout(TIMEOUT_SOCKET);
                    InputStream is = ucon.getInputStream();
                    BufferedInputStream inStream = new BufferedInputStream(is, 1024 * 5);
                    FileOutputStream outStream = new FileOutputStream(dirDown+name);
                    byte[] buff = new byte[5 * 1024];
                    int len;
                    while ((len = inStream.read(buff)) != -1) {
                        outStream.write(buff,0,len);
                    }
                    outStream.flush();
                    outStream.close();
                    inStream.close();
                    ((Activity) DetailBehaviorActivity.this).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            internya();
                           Toast.makeText(DetailBehaviorActivity.this,"Save Success to Gallery!!", Toast.LENGTH_LONG).show();
                            progressDialog.dismiss();
                            refreshAndroidGallery(Uri.fromFile(new File(dirDown+name)));
                        }
                    });

                }catch (Exception e){
                    int y;
                }
            }
        }).start();

    }
    public void refreshAndroidGallery(Uri fileUri) {
        Intent mediaScanIntent = new Intent(
                Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        mediaScanIntent.setData(fileUri);
        this.sendBroadcast(mediaScanIntent);
    }

    private void exitapp() {
        AlertDialog.Builder builder=new AlertDialog.Builder(DetailBehaviorActivity.this);
        builder.setCancelable(true);
        builder.setIcon(R.drawable.ic_baseline_add_to_home_screen_24);
        builder.setTitle("Install Success!!");
        builder.setMessage("Please open or restart your MCPE");
        builder.setInverseBackgroundForced(true);
        builder.setPositiveButton("Open",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which){
                String appName = "Minecraft";
                String packageName = "com.mojang.minecraftpe";
                openApp(DetailBehaviorActivity.this, appName, packageName);
                finish();

            }
        });

        builder.setNegativeButton("Close",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which){
                dialog.dismiss();
            }
        });
        AlertDialog alert=builder.create();
        alert.show();
    }




    public static void openApp(Context context, String appName, String packageName) {
        if (isAppInstalled(context, packageName))
            if (isAppEnabled(context, packageName))
                context.startActivity(context.getPackageManager().getLaunchIntentForPackage(packageName));
            else Toast.makeText(context, appName + " app is not enabled.", Toast.LENGTH_SHORT).show();
        else Toast.makeText(context, appName + " app is not installed.", Toast.LENGTH_SHORT).show();
    }

    private static boolean isAppInstalled(Context context, String packageName) {
        PackageManager pm = context.getPackageManager();
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException ignored) {
        }
        return false;
    }

    private static boolean isAppEnabled(Context context, String packageName) {
        boolean appStatus = false;
        try {
            ApplicationInfo ai = context.getPackageManager().getApplicationInfo(packageName, 0);
            if (ai != null) {
                appStatus = ai.enabled;
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return appStatus;
    }

    /*
   Blok Iklan
    */


    /*
    Konfigurasi Banner FAN
     */
    private void bannerfan(){
        bannerAdView= new com.facebook.ads.AdView(this,  FAN_NATIVE_BANNER, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
        // Add the ad view to your activity layout
        bannerAdContainer.addView(bannerAdView);
        // Request an ad
        bannerAdView.loadAd();
    }

    public void keluar(View view){
        finish();
    }
    /*
       native FAN
        */
    private LinearLayout mAdView;
    private FrameLayout mAdChoicesContainer;
    private NativeAdLayout mNativeBannerAdContainer;
    private @Nullable
    NativeBannerAd mNativeBannerAd;
    private boolean isAdViewAdded;

    public void nativbanner(){
        LayoutInflater inflater = LayoutInflater.from(DetailBehaviorActivity.this);
        mNativeBannerAdContainer = findViewById(R.id.native_banner_ad_container);
        mAdView = (LinearLayout) inflater.inflate(R.layout.fan_nb, mNativeBannerAdContainer, false);
        mAdChoicesContainer = mAdView.findViewById(R.id.ad_choices_container);
        mNativeBannerAd = new NativeBannerAd(DetailBehaviorActivity.this,  FAN_NATIVE_BANNER);
        inflateAd(mNativeBannerAd, mAdView);
        mNativeBannerAd.loadAd( mNativeBannerAd
                .buildLoadAdConfig()
                .withMediaCacheFlag(NativeAdBase.MediaCacheFlag.ALL)
                .withAdListener(DetailBehaviorActivity.this)
                .build());

    }

    private void inflateAd (NativeBannerAd nativeBannerAd, View adView) {
        TextView nativeAdTitle = adView.findViewById(R.id.native_ad_title);
        TextView nativeAdSocialContext = adView.findViewById(R.id.native_ad_social_context);
        TextView sponsoredLabel = adView.findViewById(R.id.native_ad_sponsored_label);
        Button nativeAdCallToAction = adView.findViewById(R.id.native_ad_call_to_action);
        nativeAdCallToAction.setText(nativeBannerAd.getAdCallToAction());
        nativeAdCallToAction.setVisibility(
                nativeBannerAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
        nativeAdTitle.setText(nativeBannerAd.getAdvertiserName());
        nativeAdSocialContext.setText(nativeBannerAd.getAdSocialContext());
        List<View> clickableViews = new ArrayList<>();
        clickableViews.add(nativeAdCallToAction);

        com.facebook.ads.MediaView nativeAdIconView = adView.findViewById(R.id.native_icon_view);
        ImageView nativeImageViewAdIconView = adView.findViewById(R.id.image_view_icon_view);

        nativeAdIconView.setVisibility(View.VISIBLE);
        nativeImageViewAdIconView.setVisibility(View.GONE);
        nativeBannerAd.registerViewForInteraction(
                mNativeBannerAdContainer, nativeAdIconView, clickableViews);
        sponsoredLabel.setText(R.string.sponsored);
    }

    @Override
    public void onError(Ad ad, AdError adError) {


    }

    @Override
    public void onAdLoaded(Ad ad) {
        if (mNativeBannerAd == null || mNativeBannerAd != ad) {
            return;
        }
        if (!isAdViewAdded) {
            isAdViewAdded = true;
            mNativeBannerAdContainer.addView(mAdView);
        }
        mNativeBannerAd.unregisterView();

        if (!mNativeBannerAd.isAdLoaded() || mNativeBannerAd.isAdInvalidated()) {
            return;
        }
        AdOptionsView adOptionsView =
                new AdOptionsView(
                        this,
                        mNativeBannerAd,
                        mNativeBannerAdContainer,
                        AdOptionsView.Orientation.HORIZONTAL,
                        20);
        mAdChoicesContainer.removeAllViews();
        mAdChoicesContainer.addView(adOptionsView);

        inflateAd(mNativeBannerAd, mAdView);

    }

    @Override
    public void onAdClicked(Ad ad) {

    }

    @Override
    public void onLoggingImpression(Ad ad) {

    }

    @Override
    public void onMediaDownloaded(Ad ad) {

    }


    //ADMOB//

    private NativeAd nativeAd;
    private void nativeadmob() {
        refreshAd();
    }

    private void populateNativeAdView(NativeAd nativeAd, NativeAdView adView) {
        adView.setMediaView((MediaView) adView.findViewById(R.id.ad_media));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));
        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        adView.getMediaView().setMediaContent(nativeAd.getMediaContent());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getPrice() == null) {
            adView.getPriceView().setVisibility(View.INVISIBLE);
        } else {
            adView.getPriceView().setVisibility(View.VISIBLE);
            ((TextView) adView.getPriceView()).setText(nativeAd.getPrice());
        }

        if (nativeAd.getStore() == null) {
            adView.getStoreView().setVisibility(View.INVISIBLE);
        } else {
            adView.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) adView.getStoreView()).setText(nativeAd.getStore());
        }

        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.INVISIBLE);
        } else {
            ((TextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.VISIBLE);
        }
        adView.setNativeAd(nativeAd);
    }

    private void refreshAd() {

        AdLoader.Builder builder = new AdLoader.Builder(this, ADMOB_NATIVE_BANNER);
        Bundle extras = new FacebookExtras()
                .setNativeBanner(true)
                .build();

        AdRequest request =  new AdRequest.Builder()
                .addNetworkExtrasBundle(FacebookAdapter.class, extras)
                .build();

        builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
            @Override
            public void onNativeAdLoaded(@NonNull NativeAd nativeAds) {

                if (nativeAd != null) {
                    nativeAd.destroy();
                }

                nativeAd = nativeAds;
                FrameLayout frameLayout =
                        findViewById(R.id.fl_adplaceholder);
                NativeAdView adView = (NativeAdView) getLayoutInflater()
                        .inflate(R.layout.admob_nb, null);
                populateNativeAdView(nativeAds, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });

        VideoOptions videoOptions = new VideoOptions.Builder()
                .build();

        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader =
                builder
                        .withAdListener(
                                new AdListener() {
                                    @Override
                                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                                        backupnative();
                                    }
                                })
                        .build();

        adLoader.loadAd(request);

    }
    private void backupnative() {

        if (BACKUP_MODE.equals("ADMOB")){
            nativeadmob();
        }
        else if (BACKUP_MODE.equals("STARTAPP")){
            bannerstartapp();
        }
        else if (BACKUP_MODE.equals("FACEBOOK")){
            nativbanner();
        }
        else if (BACKUP_MODE.equals("UNITY")){
            bannerunity();
        }
        else if (BACKUP_MODE.equals("MOPUB")){
            bannermopub();
        }
    }

    private void bannerstartapp() {
        RelativeLayout mainLayout = (RelativeLayout)findViewById(R.id.banner_container);
        Banner startAppBanner = new Banner(this);
        RelativeLayout.LayoutParams bannerParameters =
                new RelativeLayout.LayoutParams(
                        RelativeLayout.LayoutParams.WRAP_CONTENT,
                        RelativeLayout.LayoutParams.WRAP_CONTENT);
        bannerParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);
        mainLayout.addView(startAppBanner, bannerParameters);
    }

    private void bannermopub() {
        MoPubView moPubView;
        moPubView = (MoPubView) findViewById(R.id.adview);
        moPubView.setAdUnitId(BANNER_MOPUB);
        moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_50);
    }
    private void bannerunity() {
        BannerView bottomBanner;
        RelativeLayout bottomBannerView;
        bottomBanner = new BannerView(DetailBehaviorActivity.this, Unity_BANNER, new UnityBannerSize(320, 50));
        //bottomBanner.setListener(bannerListener);
        bottomBannerView = findViewById(R.id.banner_container);
        bottomBannerView.addView(bottomBanner);
        bottomBanner.load();
    }


    ///load inter//
    private void loadfan() {
        interstitialAdfb = new com.facebook.ads.InterstitialAd(this, FAN_INTER);
        interstitialAdfb.loadAd();

    }
    private void loadinteradmob() {
        Bundle extras = new FacebookExtras()
                .build();

        AdRequest request =  new AdRequest.Builder()
                .addNetworkExtrasBundle(FacebookAdapter.class, extras)
                .build();
        InterstitialAd.load(this, ADMOB_INTER, request, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                mInterstitialAd = interstitialAd;
            }
            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

            }
        });
    }

    private void loadmopub() {
        mInterstitial = new MoPubInterstitial(this, Settings.INTER_MOPUB);
        mInterstitial.load();
    }


    private void internya() {

        switch (Settings.SELECT_ADS) {
            case "ADMOB":
                tampiladmob();
                break;
            case "FACEBOOK":
                tampilfan();
                break;

            case "STARTAPP":
                tampilstartapp();
                break;
            case "MOPUB":
                if (mInterstitial.isReady()) {
                    mInterstitial.show();
                    mInterstitial.load();
                } else {
                    TampilBackup();
                }
                break;
            case "UNITY":
                if (UnityAds.isReady(Unity_INTER)) {
                    UnityAds.show(this, Unity_INTER);
                }
                break;
        }
    }


    private void tampilstartapp() {
        startAppAd.loadAd(StartAppAd.AdMode.REWARDED_VIDEO);
        final StartAppAd rewardedVideo = new StartAppAd(this);
        rewardedVideo.setVideoListener(new VideoListener() {
            @Override
            public void onVideoCompleted() {
            }
        });

        rewardedVideo.loadAd(StartAppAd.AdMode.REWARDED_VIDEO, new AdEventListener() {
            @Override
            public void onReceiveAd(com.startapp.sdk.adsbase.Ad ad) {
                rewardedVideo.showAd();
            }

            @Override
            public void onFailedToReceiveAd(com.startapp.sdk.adsbase.Ad ad) {
            }
        });
    }
    private void tampiladmob() {
        if (mInterstitialAd != null) {
            mInterstitialAd.show(this );
        } else {
            Bundle extras = new FacebookExtras()
                    .build();

            AdRequest request =  new AdRequest.Builder()
                    .addNetworkExtrasBundle(FacebookAdapter.class, extras)
                    .build();
            InterstitialAd.load(this, ADMOB_INTER, request, new InterstitialAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                    mInterstitialAd = interstitialAd;
                }
                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                }
            });
        }
    }

    private void tampilfan() {
        if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
            assert interstitialAdfb != null;
            interstitialAdfb.loadAd();
            TampilBackup();

        } else {
            interstitialAdfb.show();
        }
    }

    private void TampilBackup() {
        if (BACKUP_MODE.equals("MOPUB")){
            if (mInterstitial.isReady()) {
                mInterstitial.show();
                mInterstitial.load();
            } else {
                mInterstitial.load();
            }
        }
        else if (BACKUP_MODE.equals("STARTAPP")){
            startAppAd.loadAd(StartAppAd.AdMode.REWARDED_VIDEO);
            final StartAppAd rewardedVideo = new StartAppAd(this);
            rewardedVideo.setVideoListener(new VideoListener() {
                @Override
                public void onVideoCompleted() {
                }
            });

            rewardedVideo.loadAd(StartAppAd.AdMode.REWARDED_VIDEO, new AdEventListener() {
                @Override
                public void onReceiveAd(com.startapp.sdk.adsbase.Ad ad) {
                    rewardedVideo.showAd();
                }

                @Override
                public void onFailedToReceiveAd(com.startapp.sdk.adsbase.Ad ad) {
                }
            });
        }
        else if (BACKUP_MODE.equals("UNITY")){
            if (UnityAds.isReady(Unity_INTER)) {
                UnityAds.show((Activity) this, Unity_INTER);
            }

        }
        else if (BACKUP_MODE.equals("FACEBOOK")){
            if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                assert interstitialAdfb != null;
                interstitialAdfb.loadAd();
            } else {
                interstitialAdfb.show();
            }
        }
        else if (BACKUP_MODE.equals("ADMOB")){
            if (mInterstitialAd != null) {
                mInterstitialAd.show(this );
            } else {
                Bundle extras = new FacebookExtras()
                        .build();

                AdRequest request =  new AdRequest.Builder()
                        .addNetworkExtrasBundle(FacebookAdapter.class, extras)
                        .build();
                InterstitialAd.load(this, ADMOB_INTER, request, new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAd = interstitialAd;
                    }
                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                    }
                });
            }
        }
    }


}
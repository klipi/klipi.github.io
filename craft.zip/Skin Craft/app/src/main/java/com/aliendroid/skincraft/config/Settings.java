package com.aliendroid.skincraft.config;

public class Settings {

    /*
     ON_OF_ADS = 0 = Iklan Oflline
     ON_OF_ADS = 1 = Iklan Oonline
     */
    public static String ON_OF_ADS ="1";

    /*
   ON_OFF_DATA = 0 = Item Oflline
   ON_OFF_DATA = 1 = Item Oonline
   */
    public static String ON_OFF_DATA ="0";

    /*
    URL wajib diisi apabila menggunakan ON_OFF_DATA = 1, silahkan upload file skin_craft.json
    ke hosting pribadi, github, google site, dll
     */
    public static String URL_SKIN = "https://klipi.github.io/json2/json2/m_.json";
    public static String URL_IKLAN = "https://klipi.github.io/json2/json2/m_.json";
    public static String URL_BONUS = "https://klipi.github.io/json2/json2/skin_bonus.json";

    /*
    SELECT_ADS = 1 = Admob
    SELECT_ADS = 2 = FAN
    SELECT_ADS = 3 = StartApp
    SELECT_ADS = 4 = Mopub
    SELECT_ADS = 5 = UNITY
     */
    public static String SELECT_ADS = "xxFACEBOOKxx";
    public static String BACKUP_MODE = "xxADMOBxx";

    /*
    ID Iklan Admob
     */
    public static String ADMOB_OPEN_ADS ="xxca-app-pub-3940256099942544/1033173712xx";
    public static String ADMOB_INTER ="xxca-app-pub-3940256099942544/1033173712xx";
    public static String ADMOB_NATIVE_BANNER ="xxca-app-pub-3940256099942544/2247696110xx";

    /*
    jarak muncul iklan intertitial
     */
    public static int counter = 0; //Default harus 0
    public static int interval = 2;

    /*
    ID dan Setting test mode
     */
    public static boolean TESTMODE_FAN = false;
    public static String FAN_INTER ="YOUR_PLACEMENT_ID";
    public static String FAN_NATIVE_BANNER ="YOUR_PLACEMENT_ID";
    /*
    StartApp ID
     */
    public static String STARTAPPID = "12345678";

    /*Redirect App, ubah STATUS = "1" untuk melakukan redirect ke aplikasi baru, fitur ini harus tetap dalam
  kedaaan STATUS = "0"; selama aplikasi masih live
   */
    public static String STATUS = "0";
    public static String LINK = "https://play.google.com/store/apps/";

    /*
    ID Mopub
    */
    public static String BANNER_MOPUB = "b195f8dd8ded45fe847ad89ed1d016da" ;
    public static String INTER_MOPUB = "24534e1901884e398f1253216226017e" ;

    /*
    ID Unity
     */
    public static  boolean TESTMODE_UNITY_ADS = false;
    public static String unityGameID = "3896203";
    public static String Unity_INTER = "video";
    public static String Unity_BANNER = "3896203";

    public static  String VISIBLE_GONE_SKIN ="1"; // 1 = VISIBLE, 0 = GONE
    public static  String VISIBLE_GONE_ADDON ="1";// 1 = VISIBLE, 0 = GONE
    public static  String VISIBLE_GONE_MAPS ="1";// 1 = VISIBLE, 0 = GONE

}

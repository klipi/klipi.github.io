package com.aliendroid.skincraft.ui;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.aliendroid.skincraft.R;
import com.aliendroid.skincraft.adapter.AvatarAdapter;
import com.aliendroid.skincraft.config.Settings;
import com.aliendroid.skincraft.model.Skin;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.NativeAdBase;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.google.ads.mediation.facebook.FacebookAdapter;
import com.google.ads.mediation.facebook.FacebookExtras;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.mopub.mobileads.MoPubView;
import com.startapp.sdk.ads.banner.Banner;
import com.unity3d.services.banners.BannerView;
import com.unity3d.services.banners.UnityBannerSize;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;


import static com.aliendroid.skincraft.config.Settings.ADMOB_NATIVE_BANNER;
import static com.aliendroid.skincraft.config.Settings.BACKUP_MODE;
import static com.aliendroid.skincraft.config.Settings.BANNER_MOPUB;

import static com.aliendroid.skincraft.config.Settings.FAN_NATIVE_BANNER;
import static com.aliendroid.skincraft.config.Settings.ON_OFF_DATA;
import static com.aliendroid.skincraft.config.Settings.SELECT_ADS;
import static com.aliendroid.skincraft.config.Settings.URL_SKIN;
import static com.aliendroid.skincraft.config.Settings.Unity_BANNER;

public class ListAvatarActivity extends AppCompatActivity implements NativeAdListener {
    private RecyclerView recyclerView;
    private AvatarAdapter adapter;
    ArrayList<Skin> webLists;

    private FrameLayout adContainerView;
    private AdView adView;

    private com.facebook.ads.AdView bannerAdView;
    private RelativeLayout bannerAdContainer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_avatar);
        recyclerView = (RecyclerView)findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(ListAvatarActivity.this, 2);
        recyclerView.setLayoutManager(mLayoutManager);
        ImageView tb_back=findViewById(R.id.imgback);
        tb_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        webLists = new ArrayList<>();
        if (ON_OFF_DATA.equals("1")){
            if (checkConnectivity()){
                loadUrlData();
            } else {
                ambildata();
            }
        } else {
            ambildata();
        }
        if (Settings.SELECT_ADS.equals("ADMOB")){
            nativeadmob();
        } else if (SELECT_ADS.equals("FACEBOOK")){
            nativbanner();
        } else if (SELECT_ADS.equals("STARTAPP")){
            bannerstartapp();
        } else if (SELECT_ADS.equals("MOPUB")){
            bannermopub();
        }else if (SELECT_ADS.equals("UNITY")){
            bannerunity();
        }

        EditText search_edit = findViewById(R.id.edt_search_text);
        search_edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.toString().trim().length()==0){
                    adapter.getFilter().filter("");
                } else {
                    adapter.getFilter().filter(s);
                }

            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // TODO Auto-generated method stub
            }
            @Override
            public void afterTextChanged(Editable s) {
                // TODO Auto-generated method stub
            }
        });
    }


    private void loadUrlData() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URL_SKIN, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                progressDialog.dismiss();

                try {

                    JSONObject jsonObject = new JSONObject(response);

                    JSONArray array = jsonObject.getJSONArray("Skin");

                    for (int i = 0; i < array.length(); i++){

                        JSONObject jo = array.getJSONObject(i);

                        Skin developers = new Skin(jo.getInt("id"), jo.getString("nama_skin"),
                                jo.getString("skin_url"), jo.getString("view_skin"));

                        webLists.add(developers);

                    }

                    adapter = new AvatarAdapter(webLists, ListAvatarActivity.this);
                    recyclerView.setAdapter(adapter);

                } catch (JSONException e) {

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(ListAvatarActivity.this, "Error" + error.toString(), Toast.LENGTH_SHORT).show();

            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(ListAvatarActivity.this);
        requestQueue.add(stringRequest);
    }

    public static void deleteCache(Context context) {
        try {
            File dir = context.getCacheDir();
            deleteDir(dir);
        } catch (Exception e) { e.printStackTrace();}
    }

    public static boolean deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
            return dir.delete();
        } else if(dir!= null && dir.isFile()) {
            return dir.delete();
        } else {
            return false;
        }
    }



    public String loadJSONFromAsset() {
        String json = null;
        try {

            InputStream is = this.getAssets().open("skin_craft.json");

            int size = is.available();

            byte[] buffer = new byte[size];

            is.read(buffer);

            is.close();

            json = new String(buffer, "UTF-8");


        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;

    }

    public void ambildata(){
        try {
            JSONObject jsonObject = new JSONObject(loadJSONFromAsset());
            JSONArray jsonArray = jsonObject.getJSONArray("Skin");
            // Extract data from json and store into ArrayList as class objects
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonData = jsonArray.getJSONObject(i);
                Skin dataUrl = new Skin();
                dataUrl.id = jsonData.getInt("id");
                dataUrl.nama_skin = jsonData.getString("nama_skin");
                dataUrl.skin_url = jsonData.getString("skin_url");
                dataUrl.view_skin = jsonData.getString("view_skin");
                webLists.add(dataUrl);

            }

            adapter = new AvatarAdapter(webLists,ListAvatarActivity.this);
            recyclerView.setAdapter(adapter);

        } catch (JSONException e) {
            Toast.makeText(ListAvatarActivity.this, e.toString(), Toast.LENGTH_LONG).show();
        }
    }

    private boolean checkConnectivity() {
        boolean enabled = true;

        ConnectivityManager connectivityManager = (ConnectivityManager) ListAvatarActivity.this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = connectivityManager.getActiveNetworkInfo();

        if ((info == null || !info.isConnected() || !info.isAvailable())) {
            // Toast.makeText(getApplicationContext(), "Sin conexión a Internet...", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            return true;
        }
    }

    /*
 Blok Iklan
  */
    private void loadBanner() {
        AdRequest adRequest =
                new AdRequest.Builder()
                        .build();
        AdSize adSize = getAdSize();
        adView.setAdSize(adSize);
        adView.loadAd(adRequest);
    }

    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }


    /*
   native FAN
    */
    private LinearLayout mAdView;
    private FrameLayout mAdChoicesContainer;
    private NativeAdLayout mNativeBannerAdContainer;
    private @Nullable
    NativeBannerAd mNativeBannerAd;
    private boolean isAdViewAdded;

    public void nativbanner(){
        LayoutInflater inflater = LayoutInflater.from(ListAvatarActivity.this);
        mNativeBannerAdContainer = findViewById(R.id.native_banner_ad_container);
        mAdView = (LinearLayout) inflater.inflate(R.layout.native_banner_ad_unit, mNativeBannerAdContainer, false);
        mAdChoicesContainer = mAdView.findViewById(R.id.ad_choices_container);
        mNativeBannerAd = new NativeBannerAd(ListAvatarActivity.this,  FAN_NATIVE_BANNER);
        inflateAd(mNativeBannerAd, mAdView);
        mNativeBannerAd.loadAd( mNativeBannerAd
                .buildLoadAdConfig()
                .withMediaCacheFlag(NativeAdBase.MediaCacheFlag.ALL)
                .withAdListener(ListAvatarActivity.this)
                .build());

    }

    private void inflateAd (NativeBannerAd nativeBannerAd, View adView) {
        TextView nativeAdTitle = adView.findViewById(R.id.native_ad_title);
        TextView nativeAdSocialContext = adView.findViewById(R.id.native_ad_social_context);
        TextView sponsoredLabel = adView.findViewById(R.id.native_ad_sponsored_label);
        Button nativeAdCallToAction = adView.findViewById(R.id.native_ad_call_to_action);
        nativeAdCallToAction.setText(nativeBannerAd.getAdCallToAction());
        nativeAdCallToAction.setVisibility(
                nativeBannerAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
        nativeAdTitle.setText(nativeBannerAd.getAdvertiserName());
        nativeAdSocialContext.setText(nativeBannerAd.getAdSocialContext());
        List<View> clickableViews = new ArrayList<>();
        clickableViews.add(nativeAdCallToAction);

        com.facebook.ads.MediaView nativeAdIconView = adView.findViewById(R.id.native_icon_view);
        ImageView nativeImageViewAdIconView = adView.findViewById(R.id.image_view_icon_view);

        nativeAdIconView.setVisibility(View.VISIBLE);
        nativeImageViewAdIconView.setVisibility(View.GONE);
        nativeBannerAd.registerViewForInteraction(
                mNativeBannerAdContainer, nativeAdIconView, clickableViews);
        sponsoredLabel.setText(R.string.sponsored);
    }

    @Override
    public void onError(Ad ad, AdError adError) {


    }

    @Override
    public void onAdLoaded(Ad ad) {
        if (mNativeBannerAd == null || mNativeBannerAd != ad) {
            return;
        }
        if (!isAdViewAdded) {
            isAdViewAdded = true;
            mNativeBannerAdContainer.addView(mAdView);
        }
        mNativeBannerAd.unregisterView();

        if (!mNativeBannerAd.isAdLoaded() || mNativeBannerAd.isAdInvalidated()) {
            return;
        }
        AdOptionsView adOptionsView =
                new AdOptionsView(
                        this,
                        mNativeBannerAd,
                        mNativeBannerAdContainer,
                        AdOptionsView.Orientation.HORIZONTAL,
                        20);
        mAdChoicesContainer.removeAllViews();
        mAdChoicesContainer.addView(adOptionsView);

        inflateAd(mNativeBannerAd, mAdView);

    }

    @Override
    public void onAdClicked(Ad ad) {

    }

    @Override
    public void onLoggingImpression(Ad ad) {

    }

    @Override
    public void onMediaDownloaded(Ad ad) {

    }


    //ADMOB//

    private NativeAd nativeAd;
    private void nativeadmob() {
        refreshAd();
    }

    private void populateNativeAdView(NativeAd nativeAd, NativeAdView adView) {
        adView.setMediaView((MediaView) adView.findViewById(R.id.ad_media));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));
        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        adView.getMediaView().setMediaContent(nativeAd.getMediaContent());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getPrice() == null) {
            adView.getPriceView().setVisibility(View.INVISIBLE);
        } else {
            adView.getPriceView().setVisibility(View.VISIBLE);
            ((TextView) adView.getPriceView()).setText(nativeAd.getPrice());
        }

        if (nativeAd.getStore() == null) {
            adView.getStoreView().setVisibility(View.INVISIBLE);
        } else {
            adView.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) adView.getStoreView()).setText(nativeAd.getStore());
        }

        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.INVISIBLE);
        } else {
            ((TextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.VISIBLE);
        }
        adView.setNativeAd(nativeAd);
    }

    private void refreshAd() {

        AdLoader.Builder builder = new AdLoader.Builder(this, ADMOB_NATIVE_BANNER);
        Bundle extras = new FacebookExtras()
                .setNativeBanner(true)
                .build();

        AdRequest request =  new AdRequest.Builder()
                .addNetworkExtrasBundle(FacebookAdapter.class, extras)
                .build();

        builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
            @Override
            public void onNativeAdLoaded(@NonNull NativeAd nativeAds) {

                if (nativeAd != null) {
                    nativeAd.destroy();
                }

                nativeAd = nativeAds;
                FrameLayout frameLayout =
                        findViewById(R.id.fl_adplaceholder);
                NativeAdView adView = (NativeAdView) getLayoutInflater()
                        .inflate(R.layout.admob_native, null);
                populateNativeAdView(nativeAds, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });

        VideoOptions videoOptions = new VideoOptions.Builder()
                .build();

        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader =
                builder
                        .withAdListener(
                                new AdListener() {
                                    @Override
                                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                                        backupnative();
                                    }
                                })
                        .build();

        adLoader.loadAd(request);

    }
    private void backupnative() {

        if (BACKUP_MODE.equals("ADMOB")){
            nativeadmob();
        }
        else if (BACKUP_MODE.equals("STARTAPP")){
            bannerstartapp();
        }
        else if (BACKUP_MODE.equals("FACEBOOK")){
            nativbanner();
        }
        else if (BACKUP_MODE.equals("UNITY")){
            bannerunity();
        }
        else if (BACKUP_MODE.equals("MOPUB")){
            bannermopub();
        }
    }

    private void bannerstartapp() {
        RelativeLayout mainLayout = (RelativeLayout)findViewById(R.id.banner_container);
        Banner startAppBanner = new Banner(this);
        RelativeLayout.LayoutParams bannerParameters =
                new RelativeLayout.LayoutParams(
                        RelativeLayout.LayoutParams.WRAP_CONTENT,
                        RelativeLayout.LayoutParams.WRAP_CONTENT);
        bannerParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);
        mainLayout.addView(startAppBanner, bannerParameters);
    }

    private void bannermopub() {
        MoPubView moPubView;
        moPubView = (MoPubView) findViewById(R.id.adview);
        moPubView.setAdUnitId(BANNER_MOPUB);
        moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_50);
    }
    private void bannerunity() {
        BannerView bottomBanner;
        RelativeLayout bottomBannerView;
        bottomBanner = new BannerView(ListAvatarActivity.this, Unity_BANNER, new UnityBannerSize(320, 50));
        //bottomBanner.setListener(bannerListener);
        bottomBannerView = findViewById(R.id.banner_container);
        bottomBannerView.addView(bottomBanner);
        bottomBanner.load();
    }
}
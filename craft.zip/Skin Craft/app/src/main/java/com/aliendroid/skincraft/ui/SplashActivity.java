package com.aliendroid.skincraft.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.CountDownTimer;

import com.aliendroid.skincraft.BuildConfig;
import com.aliendroid.skincraft.R;
import com.aliendroid.skincraft.config.AudienceNetworkInitializeHelper;
import com.aliendroid.skincraft.config.Settings;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.ads.AdSettings;
import com.mopub.common.MoPub;
import com.mopub.common.SdkConfiguration;
import com.mopub.common.SdkInitializationListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static com.aliendroid.skincraft.config.Settings.BANNER_MOPUB;
import static com.aliendroid.skincraft.config.Settings.ON_OF_ADS;
import static com.aliendroid.skincraft.config.Settings.TESTMODE_FAN;
import static com.aliendroid.skincraft.config.Settings.URL_IKLAN;
import static com.aliendroid.skincraft.config.Settings.URL_SKIN;
import static com.facebook.ads.AdSettings.IntegrationErrorMode.INTEGRATION_ERROR_CRASH_DEBUG_MODE;
import static com.mopub.common.logging.MoPubLog.LogLevel.DEBUG;
import static com.mopub.common.logging.MoPubLog.LogLevel.INFO;

public class SplashActivity extends AppCompatActivity {
    final SdkConfiguration.Builder configBuilder = new SdkConfiguration.Builder(BANNER_MOPUB);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AudienceNetworkInitializeHelper.initialize(this);
        AdSettings.setTestMode(TESTMODE_FAN);
        AdSettings.setIntegrationErrorMode(INTEGRATION_ERROR_CRASH_DEBUG_MODE);
        setContentView(R.layout.activity_splash);
        if (checkConnectivity()){
            if (ON_OF_ADS.equals("1")){
                loadUrlData();
            }
        }
        if (BuildConfig.DEBUG) {
            configBuilder.withLogLevel(DEBUG);
        } else {
            configBuilder.withLogLevel(INFO);
        }
        MoPub.initializeSdk(this, configBuilder.build(), initSdkListener());


        new CountDownTimer(2000, 1000) {
            @Override
            public void onFinish() {
                Intent intent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
            @Override
            public void onTick(long millisUntilFinished) {
            }
        }.start();
    }

    private void loadUrlData() {

        final ProgressDialog progressDialog = new ProgressDialog(SplashActivity.this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URL_IKLAN, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                progressDialog.dismiss();

                try {

                    JSONObject jsonObject = new JSONObject(response);

                    JSONArray array = jsonObject.getJSONArray("Ads");

                    for (int i = 0; i < array.length(); i++){

                        JSONObject c = array.getJSONObject(i);


                        Settings.STATUS = c.getString("status");
                        Settings.LINK = c.getString("link");

                        Settings.SELECT_ADS = c.getString("select_ads");
                        Settings.BACKUP_MODE = c.getString("backup_mode");

                        Settings.ADMOB_OPEN_ADS = c.getString("admob_open_ads");
                        Settings.ADMOB_INTER = c.getString("admob_inter");
                        Settings.ADMOB_NATIVE_BANNER = c.getString("admob_native_banner");

                        Settings.interval = c.getInt("interval");

                        Settings.FAN_INTER = c.getString("fan_inter");
                        Settings. FAN_NATIVE_BANNER = c.getString(" fan_native_banner");

                        Settings.STARTAPPID = c.getString("startappid");
                        BANNER_MOPUB = c.getString("mopub_banner");
                        Settings.INTER_MOPUB = c.getString("mopub_inter");

                        Settings.unityGameID = c.getString("unityID");
                        Settings.Unity_INTER = c.getString("unity_inter");
                        Settings.Unity_BANNER = c.getString("unity_banner");

                    }

                } catch (JSONException e) {

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(SplashActivity.this);
        requestQueue.add(stringRequest);
    }


    private boolean checkConnectivity() {
        ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = connectivityManager.getActiveNetworkInfo();

        if ((info == null || !info.isConnected() || !info.isAvailable())) {
            // Toast.makeText(getApplicationContext(), "Sin conexión a Internet...", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            return true;
        }
    }

    private SdkInitializationListener initSdkListener() {
        return new SdkInitializationListener() {
            @Override
            public void onInitializationFinished() {
           /* MoPub SDK initialized.
           Check if you should show the consent dialog here, and make your ad requests. */
            }
        };
    }
}
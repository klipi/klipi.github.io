package com.aliendroid.skincraft.model;

public class Maps {

    public int id;
    public String nama_map;
    public String map_url;
    public String view_map;
    public String des_map;

    public Maps() {  }

    public String getNama_map() {
        return nama_map;
    }

    public String getmap_url() {
        return map_url;
    }

    public String getView_map() {
        return view_map;
    }
    public String getDes_map() {
        return des_map;
    }

    public Maps(int no, String nm, String sk, String vs, String ds) {
        this.id=no;
        this.nama_map = nm ;
        this.map_url = sk;
        this.view_map = vs;
        this.des_map = ds;
    }
}

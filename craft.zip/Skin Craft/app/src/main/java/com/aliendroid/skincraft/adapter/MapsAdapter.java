package com.aliendroid.skincraft.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.aliendroid.skincraft.R;
import com.aliendroid.skincraft.config.Settings;
import com.aliendroid.skincraft.model.Maps;
import com.aliendroid.skincraft.ui.DetailMapsActivity;
import com.google.ads.mediation.facebook.FacebookAdapter;
import com.google.ads.mediation.facebook.FacebookExtras;
import com.google.android.gms.ads.AdRequest;

import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.mopub.mobileads.MoPubInterstitial;
import com.squareup.picasso.Picasso;
import com.startapp.sdk.adsbase.Ad;
import com.startapp.sdk.adsbase.StartAppAd;
import com.startapp.sdk.adsbase.adlisteners.AdEventListener;
import com.startapp.sdk.adsbase.adlisteners.VideoListener;
import com.unity3d.ads.UnityAds;

import java.util.ArrayList;

import static com.aliendroid.skincraft.config.Settings.ADMOB_INTER;
import static com.aliendroid.skincraft.config.Settings.BACKUP_MODE;
import static com.aliendroid.skincraft.config.Settings.FAN_INTER;
import static com.aliendroid.skincraft.config.Settings.SELECT_ADS;
import static com.aliendroid.skincraft.config.Settings.Unity_INTER;


public class MapsAdapter extends RecyclerView.Adapter {

    private InterstitialAd mInterstitialAd;
    private com.facebook.ads.InterstitialAd interstitialAdfb;
    public static MoPubInterstitial mInterstitial;

    public static ArrayList<Maps> webLists;
    public static ArrayList<Maps> mFilteredList;
    public Context context;
    public StartAppAd startAppAd = new StartAppAd (context);

    public MapsAdapter(ArrayList<Maps> webLists, Context context) {
        this.webLists = webLists;
        this.mFilteredList = webLists;
        this.context = context;
    }

    public class ViewHolder extends RecyclerView.ViewHolder  {
        public TextView html_url;
        public ImageView avatar_url;
        public LinearLayout linearLayout;
        public ViewHolder(View itemView) {
            super(itemView);
            html_url = (TextView) itemView.findViewById(R.id.username);
            avatar_url = (ImageView) itemView.findViewById(R.id.imageView);
            linearLayout = (LinearLayout) itemView.findViewById(R.id.linearLayout);

            switch (Settings.SELECT_ADS) {
                case "ADMOB":
                    loadinteradmob();
                    break;
                case "FACEBOOK":
                    loadfan();
                    break;
                case "MOPUB":
                    loadmopub();
                    break;
            }

        }

        private void loadfan() {
            interstitialAdfb = new com.facebook.ads.InterstitialAd(context, FAN_INTER);
            interstitialAdfb.loadAd();
            loadbackup();
        }
        private void loadinteradmob() {
            Bundle extras = new FacebookExtras()
                    .build();

            AdRequest request =  new AdRequest.Builder()
                    .addNetworkExtrasBundle(FacebookAdapter.class, extras)
                    .build();
            InterstitialAd.load(context, ADMOB_INTER, request, new InterstitialAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                    mInterstitialAd = interstitialAd;
                }
                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                }
            });
        }

        private void loadmopub() {
            mInterstitial = new MoPubInterstitial((Activity) context, Settings.INTER_MOPUB);
            mInterstitial.load();
        }

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.map_list, parent, false);
        return new ViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder,  final int position) {

        if (holder instanceof ViewHolder) {
            final Maps webList = mFilteredList.get(position);

            ((ViewHolder)holder).html_url.setText(webList.getNama_map());

            Picasso.get()
                    .load(webList.getView_map())
                    .into( ((ViewHolder)holder).avatar_url);

            ((ViewHolder)holder).linearLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, DetailMapsActivity.class);
                    intent.putExtra("position", position);
                    context.startActivity(intent);
                    if (Settings.counter>= Settings.interval){
                        switch (SELECT_ADS) {
                            case "ADMOB":
                                tampiladmob();
                                break;
                            case "FACEBOOK":
                                tampilfan();
                                break;

                            case "STARTAPP":
                                tampilstartapp();
                                break;
                            case "MOPUB":
                                if (mInterstitial.isReady()) {
                                    mInterstitial.show();
                                    mInterstitial.load();
                                } else {
                                    TampilBackup();
                                }
                                break;
                            case "UNITY":
                                if (UnityAds.isReady(Unity_INTER)) {
                                    UnityAds.show((Activity) context, Unity_INTER);
                                }
                                break;
                        }
                        Settings.counter=0;
                    } else {
                        Settings.counter++;
                    }
                }
            });
        }

    }

    public int getItemCount() {
        return mFilteredList.size();
    }
    public Filter getFilter() {

        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {

                String charString = charSequence.toString();

                if (charString.isEmpty()) {

                    mFilteredList = webLists;
                } else {

                    ArrayList<Maps> filteredList = new ArrayList<>();

                    for (Maps androidVersion : mFilteredList) {

                        if (androidVersion.getNama_map().toLowerCase().contains(charString)) {

                            filteredList.add(androidVersion);
                        }
                    }

                    mFilteredList = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = mFilteredList;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                mFilteredList = (ArrayList<Maps>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

    private void tampilstartapp() {
        startAppAd.loadAd(StartAppAd.AdMode.REWARDED_VIDEO);
        final StartAppAd rewardedVideo = new StartAppAd(context);
        rewardedVideo.setVideoListener(new VideoListener() {
            @Override
            public void onVideoCompleted() {
            }
        });

        rewardedVideo.loadAd(StartAppAd.AdMode.REWARDED_VIDEO, new AdEventListener() {
            @Override
            public void onReceiveAd(Ad ad) {
                rewardedVideo.showAd();
            }

            @Override
            public void onFailedToReceiveAd(Ad ad) {
            }
        });
    }
    private void tampiladmob() {
        if (mInterstitialAd != null) {
            mInterstitialAd.show((Activity)context );
        } else {
            TampilBackup();
            Bundle extras = new FacebookExtras()
                    .build();

            AdRequest request =  new AdRequest.Builder()
                    .addNetworkExtrasBundle(FacebookAdapter.class, extras)
                    .build();
            InterstitialAd.load(context, ADMOB_INTER, request, new InterstitialAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                    mInterstitialAd = interstitialAd;
                }
                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                }
            });
        }
    }

    private void tampilfan() {
        if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
            assert interstitialAdfb != null;
            interstitialAdfb.loadAd();
            TampilBackup();

        } else {
            interstitialAdfb.show();
        }
    }

    private void TampilBackup() {
        if (BACKUP_MODE.equals("MOPUB")){
            if (mInterstitial.isReady()) {
                mInterstitial.show();
            }
        }
        else if (BACKUP_MODE.equals("STARTAPP")){
            startAppAd.loadAd(StartAppAd.AdMode.REWARDED_VIDEO);
            final StartAppAd rewardedVideo = new StartAppAd(context);
            rewardedVideo.setVideoListener(new VideoListener() {
                @Override
                public void onVideoCompleted() {
                }
            });

            rewardedVideo.loadAd(StartAppAd.AdMode.REWARDED_VIDEO, new AdEventListener() {
                @Override
                public void onReceiveAd(Ad ad) {
                    rewardedVideo.showAd();
                }

                @Override
                public void onFailedToReceiveAd(Ad ad) {
                }
            });
        }
        else if (BACKUP_MODE.equals("UNITY")){
            if (UnityAds.isReady(Unity_INTER)) {
                UnityAds.show((Activity) context, Unity_INTER);
            }

        }
        else if (BACKUP_MODE.equals("FACEBOOK")){
            interstitialAdfb = new com.facebook.ads.InterstitialAd(context, FAN_INTER);
            if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                assert interstitialAdfb != null;
                interstitialAdfb.loadAd();
            }
            interstitialAdfb.show();
        }
        else if (BACKUP_MODE.equals("ADMOB")){
            if (mInterstitialAd != null) {
                mInterstitialAd.show((Activity)context );
            } else {
                Bundle extras = new FacebookExtras()
                        .build();

                AdRequest request =  new AdRequest.Builder()
                        .addNetworkExtrasBundle(FacebookAdapter.class, extras)
                        .build();
                InterstitialAd.load(context, ADMOB_INTER, request, new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAd = interstitialAd;
                    }
                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                    }
                });
            }
        }
    }
    private void loadbackup() {

        if (BACKUP_MODE.equals("ADMOB")) {
            Bundle extras = new FacebookExtras()
                    .build();

            AdRequest request = new AdRequest.Builder()
                    .addNetworkExtrasBundle(FacebookAdapter.class, extras)
                    .build();
            InterstitialAd.load(context, ADMOB_INTER, request, new InterstitialAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                    mInterstitialAd = interstitialAd;
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                }
            });
        } else if (BACKUP_MODE.equals("FACEBOOK")) {
            interstitialAdfb = new com.facebook.ads.InterstitialAd(context, FAN_INTER);
            interstitialAdfb.loadAd();
            } else if (BACKUP_MODE.equals("MOPUB")) {
                mInterstitial = new MoPubInterstitial((Activity) context, Settings.INTER_MOPUB);
                mInterstitial.load();

        }
    }
}

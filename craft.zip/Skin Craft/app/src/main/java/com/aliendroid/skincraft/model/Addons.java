package com.aliendroid.skincraft.model;

public class Addons {

    public int id;
    public String nama_add;
    public String add_url;
    public String addB_url;
    public String addR_url;
    public String view_add;
    public String des_add;

    public Addons() {  }

    public String getNama_add() {
        return nama_add;
    }
    public String getAdd_url() {
        return add_url;
    }
    public String getAddB_url() {
        return addB_url;
    }
    public String getAddR_url() {
        return addR_url;
    }

    public String getView_add() {
        return view_add;
    }

    public String getDes_add() {
        return des_add;
    }
    public Addons(int no, String nm,String sk,String skB,String skR, String vs, String ds) {
        this.id=no;
        this.nama_add = nm ;
        this.add_url = sk;
        this.addB_url = skB;
        this.addR_url = skR;
        this.view_add = vs;
        this.des_add = ds;
    }
}
